using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace RIS.Interop.FIDTest
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            FIDTest _TestObj = new RIS.Interop.FIDTest.FIDTest();
            
            //Application.Run(new RIS.Interop.FIDTest.FIDTest());
        }
    }
}