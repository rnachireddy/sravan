﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RIS.Interop.Messages;
using System.Xml;

namespace RIS.Interop.Test
{
    class SimulateFIDMessage
    {
        public SimulateFIDMessage()
        {
            HP_TestSuperFIDElement();
        }

        public void HP_TestSuperFIDElement()
        {
            FIDMessage FM;
            SuperFIDElement SF;
            string Xml1;
            string Xml2;
            byte[] Bytes1;
            byte[] Bytes2;
            byte[] BinaryElement;
            XmlDocument XmlDoc;

            FM = new FIDMessage();
            XmlDoc = new XmlDocument();

            //The FID message that we will build here is like this:
            //<FIDMessage>
            //  <FD_ACCTNUM Value="123" /> 
            //  <FD_ACCTNUMLEN Value="3" /> 
            //  <FD_PUMPPARMS Value="[0][0], [1][0], [2][0], [3][0], [4][0]" />
            //  <SFD_CARWASH NumberOfChildren="3">
            //      <FD_AUTHMSG Value="Test" /> 
            //      <FD_AUTHTYPE Value="1" /> 
            //      <SFD_CHANGE NumberOfChildren="2">
            //          <FD_COUNT Value="1" /> 
            //          <FD_COUPONTYPE Value="Vendor" /> 
            //      </SFD_CHANGE>
            //  </SFD_CARWASH>
            //</FIDMessage>
            //add Non binaries and Binaries elements.
            FM.AddChild(new FIDElement(FIDInfo.FD_ACCTNUM, "123"));
            FM.AddChild(new FIDElement(FIDInfo.FD_ACCTNUMLEN, 3));
            BinaryElement = new byte[5];
            FM.AddChild(new FIDElement(FIDInfo.FD_PUMPPARMS, BinaryElement));

            //create super fid with children.
            SF = new SuperFIDElement(FIDInfo.SFD_CARWASH);
            SF.AddChild(new FIDElement(FIDInfo.FD_AUTHMSG, "Test"));
            SF.AddChild(new FIDElement(FIDInfo.FD_AUTHTYPE, 1));
            //create super FID as a child.
            SF.AddChild(new SuperFIDElement(FIDInfo.SFD_CHANGE));
            SF.GetSuperFIDElements(FIDInfo.SFD_CHANGE)[0].AddChild(new FIDElement(FIDInfo.FD_COUNT, 1));
            SF.GetSuperFIDElements(FIDInfo.SFD_CHANGE)[0].AddChild(new FIDElement(FIDInfo.FD_COUPONTYPE, "Vendor"));
            FM.AddChild(SF);

            //create XML that represent the FID message.
            Xml1 = FM.ToString();
            XmlDoc.LoadXml(Xml1); //if the load will fail the test will fail.

            //create byte[] that represent the FID message.
            Bytes1 = FM.ToBytes();
            //clear!!!
            FM.Dispose();

            //check that the byte[] is OK.
            Assert.AreEqual(((int)43), ((int)Bytes1.Length), "Failed to create Byte[] message");

            //check that the Xml1 is OK.
            Assert.AreEqual(((int)341), ((int)Xml1.Length), "Failed to create Xml message");

            //build new FID message from byte1 and see that we get the exact resault.
            FM = new FIDMessage(Bytes1);

            //create XML that represent the FID message.
            Xml2 = FM.ToString();
            XmlDoc.LoadXml(Xml2); //if the load will fail the test will fail.

            //create byte[] that represent the FID message.
            Bytes2 = FM.ToBytes();
            //clear!!!
            FM.Dispose();

            Assert.AreEqual(Xml1, Xml2, "Failed to build FID message from byte[]. Xml is diffrent");
            Assert.AreEqual(Bytes1.Length.ToString(), Bytes2.Length.ToString(), "Failed to build FID message from byte[]. byte[] is diffrent");

            //add and delete elements.
            SF.AddChild(new FIDElement(FIDInfo.FD_COUPONID, "CouponID"));
            SF.AddChild(new SuperFIDElement(FIDInfo.SFD_CTINFO));
            SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].AddChild(new FIDElement(FIDInfo.FD_COUNT, 1));
            SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].AddChild(new FIDElement(FIDInfo.FD_COUPONTYPE, "Vendor"));
            //delete FD_COUPONID FID Element.
            SF.DeleteChild(SF.GetFIDElements(FIDInfo.FD_COUPONID)[0]);
            //delete SFD_CTINFO\FD_COUNT FID element.
            SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].DeleteChild(SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].GetFIDElements(FIDInfo.FD_COUNT)[0]);
            //Delete super FID SFD_CTINFO.
            SF.DeleteChild(SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0]);
        }
    }
}
