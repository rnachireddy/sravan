using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RIS.Interop.Messages;
using System.Xml;


namespace RIS.Interop.Test
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class FIDParserUnitTest
    {
        #region TestUnit methodes.
        public FIDParserUnitTest()
        {
            //
            // TODO: Add constructor logic here
            //
            System.Diagnostics.Debugger.Launch();
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion
        #endregion

        #region Happy path.
        [TestMethod]
        [Description("HP_TestSuperFIDElement")]
        public void HP_TestSuperFIDElement()
        {
            FIDMessage FM;
            SuperFIDElement SF;
            string Xml1;
            string Xml2;
            byte[] Bytes1;
            byte[] Bytes2;
            byte[] BinaryElement;
            XmlDocument XmlDoc;

            FM = new FIDMessage();
            XmlDoc = new XmlDocument();

            //The FID message that we will build here is like this:
            //<FIDMessage>
            //  <FD_ACCTNUM Value="123" /> 
            //  <FD_ACCTNUMLEN Value="3" /> 
            //  <FD_PUMPPARMS Value="[0][0], [1][0], [2][0], [3][0], [4][0]" />
            //  <SFD_CARWASH NumberOfChildren="3">
            //      <FD_AUTHMSG Value="Test" /> 
            //      <FD_AUTHTYPE Value="1" /> 
            //      <SFD_CHANGE NumberOfChildren="2">
            //          <FD_COUNT Value="1" /> 
            //          <FD_COUPONTYPE Value="Vendor" /> 
            //      </SFD_CHANGE>
            //  </SFD_CARWASH>
            //</FIDMessage>
            //add Non binaries and Binaries elements.
            FM.AddChild(new FIDElement(FIDInfo.FD_ACCTNUM, "123"));
            FM.AddChild(new FIDElement(FIDInfo.FD_ACCTNUMLEN, 3));
            BinaryElement = new byte[5];
            FM.AddChild(new FIDElement(FIDInfo.FD_PUMPPARMS, BinaryElement));

            //create super fid with children.
            SF = new SuperFIDElement(FIDInfo.SFD_CARWASH);
            SF.AddChild(new FIDElement(FIDInfo.FD_AUTHMSG, "Test"));
            SF.AddChild(new FIDElement(FIDInfo.FD_AUTHTYPE, 1));
            //create super FID as a child.
            SF.AddChild(new SuperFIDElement(FIDInfo.SFD_CHANGE));
            SF.GetSuperFIDElements(FIDInfo.SFD_CHANGE)[0].AddChild(new FIDElement(FIDInfo.FD_COUNT, 1));
            SF.GetSuperFIDElements(FIDInfo.SFD_CHANGE)[0].AddChild(new FIDElement(FIDInfo.FD_COUPONTYPE, "Vendor"));
            FM.AddChild(SF);
           
            //create XML that represent the FID message.
            Xml1 = FM.ToString();
            XmlDoc.LoadXml(Xml1); //if the load will fail the test will fail.
            
            //create byte[] that represent the FID message.
            Bytes1 = FM.ToBytes();
            //clear!!!
            FM.Dispose();

            //check that the byte[] is OK.
            Assert.AreEqual(((int)43), ((int)Bytes1.Length), "Failed to create Byte[] message");

            //check that the Xml1 is OK.
            Assert.AreEqual(((int)341), ((int)Xml1.Length), "Failed to create Xml message");

            //build new FID message from byte1 and see that we get the exact resault.
            FM = new FIDMessage(Bytes1);

            //create XML that represent the FID message.
            Xml2 = FM.ToString();
            XmlDoc.LoadXml(Xml2); //if the load will fail the test will fail.

            //create byte[] that represent the FID message.
            Bytes2 = FM.ToBytes();
            //clear!!!
            FM.Dispose();

            Assert.AreEqual(Xml1, Xml2, "Failed to build FID message from byte[]. Xml is diffrent");
            Assert.AreEqual(Bytes1.Length.ToString(), Bytes2.Length.ToString(), "Failed to build FID message from byte[]. byte[] is diffrent");

            //add and delete elements.
            SF.AddChild(new FIDElement(FIDInfo.FD_COUPONID, "CouponID"));
            SF.AddChild(new SuperFIDElement(FIDInfo.SFD_CTINFO));
            SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].AddChild(new FIDElement(FIDInfo.FD_COUNT, 1));
            SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].AddChild(new FIDElement(FIDInfo.FD_COUPONTYPE, "Vendor"));
            //delete FD_COUPONID FID Element.
            SF.DeleteChild(SF.GetFIDElements(FIDInfo.FD_COUPONID)[0]);
            //delete SFD_CTINFO\FD_COUNT FID element.
            SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].DeleteChild(SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0].GetFIDElements(FIDInfo.FD_COUNT)[0]);
            //Delete super FID SFD_CTINFO.
            SF.DeleteChild(SF.GetSuperFIDElements(FIDInfo.SFD_CTINFO)[0]);
        }
        #endregion

        #region Non Happy path.
        [TestMethod]
        [Description("NHP_TestFIDElementTooBigNonBinary")]
        [ExpectedException(typeof(FIDElementTooLongException))]
        public void NHP_TestFIDElementTooBigNonBinary()
        {
            FIDElement Element;
            string Value;

            //create a string with length bigger than 1024. We suppose to get FIDElementTooLongException.
            Value = string.Empty;
            Value = Value.PadRight(1025, 'z');
            Element = new FIDElement(FIDInfo.SFD_CTINFO, Value);

            Element.ToBytes();
            //if we are here, we failed!!!
            Assert.Fail("Failed because FIDElement.ToBytes() did not throw FIDElementTooLongException when Value len is over 1024.");
        }

        [TestMethod]
        [Description("NHP_TestFIDElementTooBigBinary")]
        [ExpectedException(typeof(FIDElementTooLongException))]
        public void NHP_TestFIDElementTooBigBinary()
        {
            FIDElement Element;

            //now test with binary FID
            Element = new FIDElement(FIDInfo.FD_PUMPPARMS, new byte[1025]);
            Element.ToBytes();
            //if we are here, we failed!!!
            Assert.Fail("Failed because FIDElement.ToBytes() did not throw FIDElementTooLongException when Value len is over 1024.");
        }

        [TestMethod]
        [Description("NHP_TestSuperFIDElementTooBig")]
        [ExpectedException(typeof(FIDElementTooLongException))]
        public void NHP_TestSuperFIDElementTooBig()
        {
            SuperFIDElement Element;
            string Value;

            //create a some element that their total length is over 1024. We suppose to get FIDElementTooLongException.
            Value = string.Empty;
            Element = new SuperFIDElement(FIDInfo.SFD_CTINFO);
            Element.AddChild(new FIDElement(FIDInfo.SFD_DEVCTRL, Value.PadRight(1000, 'f')));
            Element.AddChild(new FIDElement(FIDInfo.SFD_DEVCTRL, Value.PadRight(19, 'f')));
            Element.AddChild(new FIDElement(FIDInfo.FD_PUMPPARMS, new byte[10]));

            Element.ToBytes();
            //if we are here, we failed!!!
            Assert.Fail("Failed because SuperFIDElement.ToBytes() did not throw FIDElementTooLongException when Value len is over 1024.");
        }

        [TestMethod]
        [Description("NHP_TestFIDElementIntValueNotLegal")]
        [ExpectedException(typeof(FIDException))]
        public void NHP_TestFIDElementIntValueNotLegal()
        {
            FIDElement Element;
            int Value;

            Element = new FIDElement(FIDInfo.SFD_FEE, "test");
            Value = Element.IntValue;

            //if we are here, we failed!!!
            Assert.Fail("Failed because FIDElement.IntValue did not throw FIDException when the value of hte FID Element is not numeric.");
        }

        [TestMethod]
        [Description("NHP_TestBinaryFIDElementValueString")]
        [ExpectedException(typeof(FIDException))]
        public void NHP_TestBinaryFIDElementStringValue()
        {
            FIDElement Element;
            string Value;

            Element = new FIDElement(FIDInfo.FD_PUMPPARMS, new byte[10]);
            Value = Element.StringValue;
            
            //if we are here, we failed!!!
            Assert.Fail("Failed because FIDElement.StringValue did not throw FIDException when the value of the FID Element is binary.");
        }

        [TestMethod]
        [Description("NHP_TestBinaryFIDElementIntString")]
        [ExpectedException(typeof(FIDException))]
        public void NHP_TestBinaryFIDElementIntValue()
        {
            FIDElement Element;
            int Value;

            Element = new FIDElement(FIDInfo.FD_PUMPPARMS, BitConverter.GetBytes(123));
            Value = Element.IntValue;

            //if we are here, we failed!!!
            Assert.Fail("Failed because FIDElement.IntValue did not throw FIDException when the value of the FID Element is binary.");
        }

        [TestMethod]
        [Description("NHP_TestNonBinaryFIDElementBinaryString")]
        [ExpectedException(typeof(FIDException))]
        public void NHP_TestNonBinaryFIDElementBinaryString()
        {
            FIDElement Element;
            byte[] Value;

            Value = new byte[10];
            Element = new FIDElement(FIDInfo.SFD_FEE, "test");
            Value = Element.BinaryValue;

            //if we are here, we failed!!!
            Assert.Fail("Failed because FIDElement.BinaryValue did not throw FIDException when the value of the FID Element is non binary.");
        }
        #endregion
    }
}
