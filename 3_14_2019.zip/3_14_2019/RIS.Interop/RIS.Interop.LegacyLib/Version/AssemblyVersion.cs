using System;
using System.Reflection;
using System.Runtime.CompilerServices;

//
// Version information for an assembly consists of the following four values:
//
//      Major Version test
//      Minor Version 
//      Build Number
//      Revision
////
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
//
//
//
[assembly: AssemblyVersion("4.0.10.704")]
