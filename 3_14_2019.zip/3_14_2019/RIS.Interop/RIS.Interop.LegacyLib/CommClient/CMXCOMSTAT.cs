using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RIS.Interop.Communication
{
    /// <summary>
    /// Hold connection status.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public class CMXCOMSTAT
    {
        /// <summary>
        /// Last error code.
        /// </summary>
        public int mError;
        /// <summary>
        /// Internal messages buffer size.
        /// </summary>
        public int mMaxDataLen;
        /// <summary>
        /// Last app Seq number.
        /// </summary>
        public byte mSeqNo;
    }
}
