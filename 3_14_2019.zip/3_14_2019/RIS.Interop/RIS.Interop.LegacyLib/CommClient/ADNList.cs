using System;
using System.Collections.Generic;
using System.Text;

namespace RIS.Interop.Communication
{
    public enum ADNList : byte
    {
        ADN_POS = 5,
        ADN_VIRTUALPOS = 6, // Virtual POS Service
        ADN_PUMPSERVICE = 7, // Pump Communication Services (PCS) for Fuel Rewards
        ADN_SOCKINT = 13,
        ADN_TOD = 29,
        ADN_FLWR10 = 50,
        ADN_FLRD10 = 51,
        ADN_FLWR11 = 52,
        ADN_FLRD11 = 53,
        ADN_FLWR12 = 54,
        ADN_FLRD12 = 55,
        ADN_FLXLT1 = 60,
        ADN_FLXLT2 = 61,
        ADN_FLXLT3 = 62,
        ADN_FLXLT4 = 63,
        ADN_FLXLT5 = 64,
        ADN_FLXLT6 = 65,
        ADN_FLXLT7 = 66,
        ADN_FLXLT8 = 67, 
        ADN_FLXLT9 = 68, 
        ADN_FLXLT10 = 69,
        ADN_FLWR1 = 70,
        ADN_FLRD1 = 71,
        ADN_FLWR2 = 72,
        ADN_FLRD2 = 73,
        ADN_FLWR3 = 74,
        ADN_FLRD3 = 75,
        ADN_FLWR4 = 76,
        ADN_FLRD4 = 77,
        ADN_FLWR5 = 78,
        ADN_FLRD5 = 79,
        ADN_FLWR6 = 80,
        ADN_FLRD6 = 81,
        ADN_FLWR7 = 82,
        ADN_FLRD7 = 83,
        ADN_FLWR8 = 84,
        ADN_FLRD8 = 85,
        ADN_SECMGR = 87,
        ADN_FLWR9 = 88,
        ADN_FLRD9 = 89,
        ADN_NTFYSRV = 90,
        ADN_NTFYSRVLOC = 91,
        ADN_CMOSMGR = 99,
        ADN_3RDPARTYPOS = 101, // third party POS
        ADN_3RDPARTYBO = 102,  // third party BackOffice SERVER
        ADN_3RDPARTYAPI = 103, // third party API 
        ADN_FUELPRICECHECK = 104,
        ADN_3RDPARTYAPIIN = 105,	// third party API, inbound, XML to Fids
        ADN_3RDPARTYAPIOUT = 106,	// third party API, outbound, Fids to XML
        ADN_MSMQ_BRIDGE = 110,
        ADN_PETROL = 180,
        ADN_FUELADM	= 181,
        ADN_ICR = 182, 
        ADN_POSSRV = 185,
        ADN_CARWASH = 186,
        ADN_SAFESRVIN = 187,	//	Safe Server - Outbound to Safe from ISP/Mgr - FIDs to XML	//	M1
        ADN_SAFESRVOUT = 188,	//	Safe Server - Inbound from Safe to ISP/Mgr - XML to FIDs	//	M1
        ADN_SAFEDIAGUTIL = 189,	//	Safe Diagnostics Utility									//	M1
        ADN_ATGPOLL = 190,
        ADN_INSTALLUTIL = 197,	//	SW Install Utility								//	M1
        ADN_MGRCOMUTIL = 198,	//	Manager Communication Utility								//	M1
        ADN_ROLLBACK_UTIL = 199,
        ADN_SCAN = 200,	// Scan
        ADN_CONFIGSRV = 200,	// Configuration Server (Remote)
        ADN_POSFS = 201,
        ADN_EMAILNS = 202,
        ADN_GEMCOM = 203,
        ADN_INVSRV = 204,
        ADN_MORDER = 205,
        ADN_JMSCOMTEST = 206,
        ADN_DGE_CONTROLLER = 210,
        ADN_REALTIME_SERVICE = 210,
        ADN_BACKOFFICE_RIS = 215,
        ADN_POSLOG = 222,
        ADN_HW = 235,
        ADN_IM = 236, //	Network Input Manager
        ADN_NETWORK_CRD_PRM_UPD = 238,	//	Network Card Parameter Update Manager
        ADN_NETWORK_INT_MGR = 239,	//	Network Integration Manager
        ADN_NETWORK = 240,			//	Network Main
        ADN_NETWORK_XLAT_MGR = 241,	//	Network Translation Manager
        ADN_NETWORK_PEPSTM = 242, //    M2 Network PEPS Translation Manager
        ADN_NETWORK_CHECKS = 243,	//	Network Checks
        ADN_NETWORK_SEPH = 244, //    M2 Network 7-Eleven Payment Host
        ADN_NID_MIN = 240, //min network ADN number
        ADN_NID_MAX = 244, //max network ADN number
        ADN_DCAPT = 250,
        ADN_METERREAD = 251,
        ADN_DPARSE = 252,
        ADN_2PARSE = 253,
        ADN_TRANSRV = 254,	// Transaction Server (Remote)
    }
}
