using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Security;

//
// Modification history:
// PRC 11/21/2013 - changed DllImport due to exception issue - PInvokeStackImbalance C# call to unmanaged C++ function 
//

namespace RIS.Interop.Communication
{
    [SuppressUnmanagedCodeSecurity]
    public class ComMgrClientProxy
    {
        #region Fields
        #region General Fields
        /// <summary>
        /// Max communication buffer size.
        /// </summary>
        public const int COM_MAX_DATA_SZ = 12000;
        public const byte FLG_COM_RESPONSE = 0x01;
        public const byte FLG_COM_AUX = 0x02;
        public const byte FLG_COM_NOACK = 0x04;
        public const byte FLG_COM_REJECT = 0x08;
        #endregion

        #region Error Codes
        /// <summary>
        /// There is no any error. Everything is OK.
        /// </summary>
        public const int E_COM_OK = 0;
        /// <summary>
        /// General error when communication failed.
        /// </summary>
        public const int E_COM_FAIL = 1;
        /// <summary>
        /// There is no new message in the named pipe.
        /// </summary>
        public const int E_COM_NOMSG = 2;
        /// <summary>
        /// Destination is offline.
        /// </summary>
        public const int E_COM_DSTOFFLINE = 3;
        /// <summary>
        /// Communication manager is offline.
        /// </summary>
        public const int E_COM_MGROFFLINE = 4;
        /// <summary>
        /// Not used.
        /// </summary>
        public const int E_COM_SYSFAILED = 5;
        /// <summary>
        /// Signal \ Alert has arrived.
        /// </summary>
        public const int E_COM_INTERRUPT = 6;
        /// <summary>
        /// Component is already connected to MGR.
        /// </summary>
        public const int E_COM_ALREADY_OPEN = 7;
        #endregion
        #endregion

        #region CsUtilLib.dll functions
        /// <summary>
        /// initialize communications module
        /// </summary>
        /// <remarks>
        /// Initializes the communications module. Registers given aAdn
        /// with the MGR process and sets up the communications
        /// control structure. Allocates buffers for sending and receiving of messages. aTrm and aAdn define processes address 
        /// within the Cserve system. aTrm must be set to 0 for processes on the ISP and is provided only for symetry 
        /// (ComReqSend routine requires destination terminal number).
        /// </remarks>
        /// <param name="aTrm">Client Terminal number. - will be zero.</param>
        /// <param name="aAdn">Client process\application number.</param>
        /// <param name="aForce">Boolean flag which when set causes ComInit to perform mgr_Close/mgr_Open internally if it finds that the MGR has the aAdn already registered.</param>
        /// <returns>
        /// 0 - success
        /// -1 - failed to connect with the MGR, ComGetError( ) will return one of the following values:
        /// E_COM_ALREADY_OPEN
        /// E_COM_MGROFFLINE
        /// </returns>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComInit", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern Int32 ComInit(Byte aTrm, byte aAdn, Int32 aForce);

        /// <summary>
        /// Close the communications module.
        /// </summary>
        /// <remarks>Closes the communications module. Needs to be called to close connection to the MGR process.</remarks>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComExit", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern void ComExit();
        
        /// <summary>
        /// Return error for the failed command.
        /// </summary>
        /// <remarks>Returns error code set by the last Com routine that failed</remarks>
        /// <returns>Error code number.</returns>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComGetError", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern int ComGetError();

        /// <summary>
        /// Send request message.
        /// </summary>
        /// <remarks>
        /// Formats request message and sends it to the specified 
        /// destination (aDstTrm,aDstAdn). The only supported value 
        /// for the aFlags parameter is FLG_COM_NOACK which 
        /// indicates to the receiving end, that the acknowledge is not 
        /// needed. aCmd is used to format GNP_BT_FUN buffer. Buffer 
        /// defined by apData and aDataLen is used to format the 
        /// GNP_BT_DATA buffer.
        /// </remarks>
        /// <param name="aFlags">The only supported value for the aFlags parameter is FLG_COM_NOACK which indicates to the receiving end, that the acknowledge is not needed.</param>
        /// <param name="aDstTrm">Destination terminal number.</param>
        /// <param name="aDstAdn">Destination process\application number.</param>
        /// <param name="aCmd">Used to format GNP_BT_FUN buffer.</param>
        /// <param name="apBuf">Message buffer.</param>
        /// <param name="aBufLen">Message buffer len.</param>
        /// <returns>
        /// 0 - success
        /// -1 - failure, ComGetError will return one of the following return codes:
        /// E_COM_DSTOFFLINE
        /// E_COM_MGROFFLINE
        /// </returns>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComReqSend", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern int ComReqSend(byte aFlags, byte aDstTrm, byte aDstAdn, UInt16 aCmd, byte[] apBuf, Int32 aBufLen);

        /// <summary>
        /// Sends response message.
        /// </summary>
        /// <remarks>
        /// Formats response message and sends it to the originator of 
        /// the request (apReqAddr). Value passed in aStatus is used 
        /// to format the GNP_BT_STATUS buffer. If aDataLen is 
        /// greater then zero then the data pointed to by apData is 
        /// used to format the GNP_BT_DATA buffer. apReqAddr 
        /// points to the COMADDR structure of the request to which 
        /// the response is generated. ComRspSend flips source and 
        /// destination addresses internally.
        /// </remarks>
        /// <param name="apAddr">
        /// apReqAddr points to the COMADDR structure of the
        /// request to which the response is generated.
        /// </param>
        /// <param name="aStatus">Used to format the GNP_BT_STATUS buffer.</param>
        /// <param name="apBuf">Message buffer.</param>
        /// <param name="aBufLen">Message buffer len.</param>
        /// <returns>
        /// 0 - success
        /// -1 - failure, ComGetError will return one of the following 
        /// values:
        /// E_COM_DSTOFFLINE
        /// E_COM_MGROFFLINE
        /// </returns>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComRspSend", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern Int32 ComRspSend(COMADDR apAddr, UInt16 aStatus, byte[] apBuf, Int32 aBufLen);

        /// <summary>
        /// Receive message from the communications channel.
        /// </summary>
        /// <remarks>
        /// Wait up to aTimeout seconds for a message. Use buffer 
        /// pointed to by apAddr to store message header 
        /// information and buffer pointed to by apData and of size 
        /// aDataLen with data from the data buffer in the message. 
        /// If aTimeout is less or equal to zero then do not block in 
        /// msgrcv. Return length of the data buffer found or -1 if no 
        /// message received or error occurred.
        /// </remarks>
        /// <param name="apAddr">Store message header information.</param>
        /// <param name="apBuf">Message buffer.</param>
        /// <param name="aBufLen">Message buffer len.</param>
        /// <param name="aTimeout">Wait time in seconds for a new messge</param>
        /// <returns>
        /// 0 - message received but no data buffer found
        /// &gt; > 0 - length of the data buffer found
        /// -1 - no message or error occurred, ComGetError() will 
        /// return one of the following return codes:
        /// E_COM_NOMSG
        /// E_COM_MGROFFLINE
        /// E_COM_INTERRUPT
        /// </returns>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComReceive", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern Int32 ComReceive(COMADDR apAddr, byte[] apBuf, Int32 aBufLen, Int32 aTimeout);

        /// <summary>
        /// Get communication status.
        /// </summary>
        /// <param name="apComStat">Holds communication status fields.</param>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "ComGetStatus", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern Int32 ComGetStatus(CMXCOMSTAT apComStat);

        /// <summary>
        /// Get last signal number and zero it.
        /// </summary>
        //[DllImport("CsUtilLib.dll")]
        [DllImport("CsUtilLib.dll", EntryPoint = "GetLastSignalNumber", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi, ExactSpelling = true)]
        public static extern Int32 GetLastSignalNumber();
        #endregion
    }
}
