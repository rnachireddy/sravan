using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RIS.Interop.Communication
{
    /// <remarks>
    /// COMADDR is a data structure where selected GNP header 
    /// members are stored. It also contains placeholders for non-
    /// data GNP buffers (GNP_BT_FUN/GNP_BT_STATUS-
    /// mCmdStat and GNP_BT_VAST-mAux). Flags byte in the 
    /// COMADDR structure is a collection of bits that are taken 
    /// from different places in the GNP header and represent 
    /// information such as whether the message is a request or 
    /// response, whether an acknowledge needs to be sent back 
    /// and whether the.message contained the GNP_BT_VAST 
    /// buffer (mAux will have a copy of it).
    /// </remarks>
    [StructLayout(LayoutKind.Sequential)]
    public class COMADDR
    {
        /// <remarks>collection of bits indicating things like whether the message is a request or response (FLG_COM_RESPONSE), whether message level acknowledge needs to be sent back (FLG_COM_NOACK) or whether the GNP vast buffer is present (FLG_COM_AUX).</remarks>
        public byte mFlags;
        public byte mSeqNo;
        /// <remarks>
        /// Represent source and destination terminal numbers. The following numbering scheme is used:
        /// Terminal 0	- ISP
        /// Terminal 1	- POS#1
        /// ....................................................
        /// Terminal 32	- POS#32
        /// </remarks>
        public Byte mSrcTrm;
        /// <remarks>Represent GNP source and destination process numbers (ADNs in our jargon)</remarks>
        public byte mSrcAdn;
        /// <remarks>
        /// Represent source and destination terminal numbers. The following numbering scheme is used:
        /// Terminal 0	- ISP
        /// Terminal 1	- POS#1
        /// ....................................................
        /// Terminal 32	- POS#32
        /// </remarks>
        public byte mDstTrm;
        /// <remarks>Represent GNP source and destination process numbers (ADNs in our jargon)</remarks>
        public byte mDstAdn;
        /// <remarks>Stores the contents of the command (GNP_BT_FUN) or status (GNP_BT_STATUS) GNP buffer depending on whether FLG_COM_RESPONSE bit is set in the mFlags byte. Value stored in the GNP buffer is assumed to be in the high/low byte format.</remarks>
        public UInt16 mCmdStat;
        /// <remarks>Stores the contents of the vast (GNP_BT_VAST ) GNP buffer if is present in the message. The presence is indicated by bit FLG_COM_AUX set in the mFlags byte. Value stored in the GNP buffer is assumed to be in the high/low byte format.</remarks>
        public UInt16 mAux;
    }
}
