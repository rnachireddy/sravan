using System;
using System.Collections.Generic;
using System.Text;

namespace RIS.Interop.Messages
{
    /// <summary>
    /// Holds all FID identifiers.
    /// </summary>
    public enum FIDInfo
    {
        /// <summary>
        /// Min value of FID.
        /// </summary>
        ///SFD_MIN_FID = 1,
        /// <summary>
        /// PLU SuperFID.
        /// </summary>
        SFD_PLU = 1,                          
        /// <summary>
        /// Department Sale SuperFID.
        /// </summary>
        SFD_DEPT = 2,              
        /// <summary>
        /// CarWash Sale SuperFID.
        /// </summary>
        SFD_CARWASH  = 3,                 
        /// <summary>
        /// Fuel Sale SuperFID.
        /// </summary>
        SFD_FUEL = 4,                    
        /// <summary>
        /// Prepay Sale.
        /// </summary>
        SFD_PREPAY = 5,                           
        /// <summary>
        /// Tax Super FID.
        /// </summary>
        SFD_TAX = 7,                         
        /// <summary>
        /// Prompting SuperFID.
        /// </summary>
        SFD_PROMPT = 8,                    
        /// <summary>
        /// Media SuperFID.
        /// </summary>
        SFD_MEDIA = 9,                        
        /// <summary>
        /// Cash Acceptor Refund info.
        /// </summary>
        SFD_CAREFUND = 10,             
        /// <summary>
        /// Info for a Payout.
        /// </summary>
        SFD_PAIDOUT = 11,                     
        /// <summary>
        /// Info for a Payin.
        /// </summary>
        SFD_PAIDIN = 12,                      
        /// <summary>
        /// Info for Cashback Trans.
        /// </summary>
        SFD_CASHBACK = 13,               
        /// <summary>
        /// Info for Check Cashing.
        /// </summary>
        SFD_CSHCHECK = 14,                
        /// <summary>
        /// Info for Floating Funds.
        /// </summary>
        SFD_FLOAT = 15,               
        /// <summary>
        /// Records a Safe Drop.
        /// </summary>
        SFD_SAFEDROP = 16,                   
        /// <summary>
        /// Fields for POS Cash Drawer Balance R.
        /// </summary>
        SFD_CSHDRAWR = 17,  
        /// <summary>
        /// Fields for POS Audit Rpt.
        /// </summary>
        SFD_AUDIT = 18,              
        /// <summary>
        /// Fields for POS Revenue Rpt.
        /// </summary>
        SFD_REVENUE = 19,            
        /// <summary>
        /// All info for Rpt fields.
        /// </summary>
        SFD_RPTITEM = 20,               
        /// <summary>
        /// List of receipts available for print.
        /// </summary>
        SFD_RCPTSUM = 21,  
        /// <summary>
        /// Product Restriction SuperFID.
        /// </summary>
        SFD_PRODCHK = 22,  
        /// <summary>
        /// Card Type Info superFID (PDL).
        /// </summary>
        SFD_CTINFO = 23,         
        /// <summary>
        /// Total Amount + Tax SuperFids.
        /// </summary>
        SFD_TOTAL = 24,          
        /// <summary>
        /// Prompt Data.
        /// </summary>
        SFD_PROMPTDAT = 25,                           
        /// <summary>
        /// Change.
        /// </summary>
        SFD_CHANGE = 26,                                
        /// <summary>
        /// Store Profile.
        /// </summary>
        SFD_STOREPROF = 27,                         
        /// <summary>
        /// System Parameters.
        /// </summary>
        SFD_SYSPARMS = 28,                     
        /// <summary>
        /// Terminal Configuration.
        /// </summary>
        SFD_TERMCFG = 29,                
        /// <summary>
        /// Media Info.
        /// </summary>
        SFD_MEDIAINFO = 30,                            
        /// <summary>
        /// Employee Info.
        /// </summary>
        SFD_EMPINFO = 31,                         
        /// <summary>
        /// Citgo Award.
        /// </summary>
        SFD_AWARD = 32,                           
        /// <summary>
        /// Department Info.
        /// </summary>
        SFD_DEPTINFO = 33,                       
        /// <summary>
        /// Event Record.
        /// </summary>
        SFD_EVENT = 34,                          
        /// <summary>
        /// Tax Info.
        /// </summary>
        SFD_TAXINFO = 35,                              
        /// <summary>
        /// POS Key Function (Security).
        /// </summary>
        SFD_POSFUN = 36,           
        /// <summary>
        /// Item Restriction Info.
        /// </summary>
        SFD_ITEMREST = 37,                 
        /// <summary>
        /// Paid In Reason.
        /// </summary>
        SFD_PAIDININFO = 38,                        
        /// <summary>
        /// Paid Out Reason.
        /// </summary>
        SFD_PAIDOUTINFO = 39,                       
        /// <summary>
        /// Unit Descriptor.
        /// </summary>
        SFD_UNITDESC = 40,                       
        /// <summary>
        /// Fuel Dispenser Config.
        /// </summary>
        SFD_FLDISPCFG = 41,                 
        /// <summary>
        /// Fuel Dispenser Hose.
        /// </summary>
        SFD_FLDISPHOSE = 42,                   
        /// <summary>
        /// Fuel Product Info.
        /// </summary>
        SFD_FLPROD = 43,                     
        /// <summary>
        /// Fuel Parameters.
        /// </summary>
        SFD_FLPARMS = 44,                       
        /// <summary>
        /// Fuel Price Info.
        /// </summary>
        SFD_FLPRICE = 45,                       
        /// <summary>
        /// Fuel Dispenser Operation.
        /// </summary>
        SFD_FLDISPOPER = 46,              
        /// <summary>
        /// Item Info.
        /// </summary>
        SFD_ITEMINFO = 47,                             
        /// <summary>
        /// Item Size Info.
        /// </summary>
        SFD_ITEMSZINFO = 48,                        
        /// <summary>
        /// Linked Item Info.
        /// </summary>
        SFD_LNKITEM = 49,                      
        /// <summary>
        /// ICR denial message.
        /// </summary>
        SFD_ICRDENIAL = 50,                    
        /// <summary>
        /// Fuel Meter Read Data.
        /// </summary>
        SFD_METERREAD = 51,                  
        /// <summary>
        /// Tax deductions for food stamps.
        /// </summary>
        SFD_TAXDEDUCT = 52,        
        /// <summary>
        /// Mix Match Info.
        /// </summary>
        SFD_MIXMATCH = 53,                        
        /// <summary>
        /// Promotional message.
        /// </summary>
        SFD_PROMO = 54,                   
        /// <summary>
        /// Drivers License Info.
        /// </summary>
	    SFD_DRVLIC = 55,                  
        /// <summary>
        /// Used with Drivers License Info.
        /// </summary>
	    SFD_FIELDINFO = 56,        
        /// <summary>
        /// Miscellaneous totals from POS to EJ.
        /// </summary>
	    SFD_MISCTOTAL = 57,   
        /// <summary>
        /// Mix Match Group.
        /// </summary>
        SFD_MIXMATCHGRP = 58,                     
        /// <summary>
        /// Flag Info.
        /// </summary>
        SFD_FLAGINFO = 59,                             
        /// <summary>
        /// Internet Card.
        /// </summary>
        SFD_ICARD = 60,                          
        /// <summary>
        /// Money Order.
        /// </summary>
        SFD_MONEYORDER = 61,                           
        /// <summary>
        /// PPU Change Status Modification.
        /// </summary>
        SFD_PPUSTATMOD = 62,  
        /// <summary>
        /// Fees.
        /// </summary>
        SFD_FEE	= 63,                                  
        /// <summary>
        /// Check Authorization Message.
        /// </summary>
        SFD_CHECKAUTHCFGMSG = 64,      
        /// <summary>
        /// Promotion Products Codes.
        /// </summary>
        SFD_MIXMATCHCD = 65,  			
        /// <summary>
        /// Promotion Detail Data.
        /// </summary>
        SFD_MIXMATCHSEQ = 66,  			
        /// <summary>
        /// Device Control Configuration Data.
        /// </summary>
        SFD_DEVCTRL = 67,	  
        /// <summary>
        /// ICR Pumps Controlled.
        /// </summary>
        SFD_PMPSCTRLD = 68,	 				
        /// <summary>
        /// ICR Display Messages.
        /// </summary>
        SFD_ICRDISPMSGS	= 69,	 				
        /// <summary>
        /// ICR Receipt Messages.
        /// </summary>
        SFD_ICRRCPTMSGS	= 70,	 				
        /// <summary>
        /// Pump Parameters.
        /// </summary>
        SFD_PUMPPARMS = 71,	 					
        /// <summary>
        /// ICR/IPR Configuration.
        /// </summary>
        SFD_ICRINFO = 72,	 			
        /// <summary>
        /// Electronic Signature Capture.
        /// </summary>
        SFD_SIGNATURE = 73,	 		
        /// <summary>
        /// Receipt Line Capture.
        /// </summary>
        SFD_RCPTLINE = 74,	 				
        /// <summary>
        /// used by IntMan and TranMan for BinMgt.
        /// </summary>
        SFD_BINCARD = 75,	  
        /// <summary>
        /// Coupon Setup	M1.
        /// </summary>
        SFD_COUPON = 76,  					
        /// <summary>
        /// Coupon Value Codes Setup  M1.
        /// </summary>
        SFD_COUPONVALUECODES = 77,    
        /// <summary>
        /// Coupon Sale Detail M1.
        /// </summary>
        SFD_COUPONSEQ = 78,	
        /// <summary>
        /// Safe Function M2.
        /// </summary>
 		SFD_SAFEACTION = 79,
	    /// <summary>
        /// Safe Configuration Parameters M2.
        /// </summary>
        SFD_SAFEPARMS = 80,	
    	/// <summary>
        /// Employee Safe Security Parameters M2.
        /// </summary>
        SFD_SAFESECPARMS = 81 ,
        /// <summary>
        /// Carwash Package data.
        /// </summary>
        SFD_ICARDAWARD = 82,
        /// <summary>
        /// Carwash Package data.
        /// </summary>
        SFD_CWPACKAGE = 83,
        /// <summary>
        /// Carwash Discount data
        /// </summary>
        SFD_CWDISCOUNT = 84,
        /// <summary>
        /// Carwash Manual Discount Reason code Info
        /// </summary>
        SFD_CWMANDSCRSN	= 85,
        /// <summary>
        /// Carwash PPU or PPG Discount data
        /// </summary>
        SFD_PPUDISC = 86,
        /// <summary>
        /// Gripps Control pop property for generic prompts
        /// </summary>
        SFD_GENPROMPT = 87,
        /// <summary>
        /// Carwash Package general info like CW Parameters
        /// </summary>
        SFD_CWPACKAGEINFO = 88,
        /// <summary>
        /// Carwash Discount Info
        /// </summary>
        SFD_CWDISCOUNTINFO = 89,
        /// <summary>
        /// Automated price sign config M15
        /// </summary>
        SFD_PRICESIGN = 90,
        /// <summary>
        /// Price sign entry config M15
        /// </summary>
        SFD_PRICESIGNENTRY = 91,
        /// <summary>
        /// Fuel - Tank Information
        /// </summary>
        SFD_TANKINFO = 92,
        /// <summary>
        /// Super Fid for meal tax rules
        /// </summary>
        SFD_MEALTAXRULES = 93,	
        /// <summary>
        /// Super Fid for meal tax details - sub structure values
        /// </summary>
        SFD_MEALTAXDETAIL = 94,	
        /// <summary>
        /// Generic Prompt response from POS
        /// </summary>
        SFD_GENPROMPTDAT = 95,
        /// <summary>
        /// Network Receipt Data
        /// </summary>
        SFD_HOSTMSGS = 96,     
		/// <summary>
        /// Super for NWSite Config Info - Store Profile - EDHDI.
		/// </summary>
		SFD_NWSITE = 97,     
		/// <summary>
        /// FCN_STATUS - Configuration Info - EDHDI.
		/// </summary>
		SFD_FCNSTATUSINFO = 98,      
		/// <summary>
        /// FCN_STATUS - Configuration Info - EDHDI.
		/// </summary>
        SFD_FCNSTATUS = 99,
        /// <summary>
        /// ASI Excise tax
        /// </summary>
        SFD_EXCISETAX = 100,
		/// <summary>
        /// DGE message metricse.
		/// </summary>		
        SFD_DGE_MSG = 101,
		/// <summary>
        /// DGE Offer.
		/// </summary>		
        SFD_DGE_OFFER = 102,
		/// <summary>
        /// DGE Member Info.
		/// </summary>		
        SFD_DGE_MEMBER = 103,
		/// <summary>
        /// DGE Configuration.
		/// </summary>		
        SFD_DGE_CONFIG = 104,
        /// <summary>
        /// DGE Metrics.
		/// </summary>		
        SFD_DGE_METRIC = 105,
        /// <summary>
        /// P2P Timing metrics timing metrics
        /// </summary>
        SFD_TXN_METRIC = 106,
        /// <summary>
        /// EMV data
        /// </summary>
        SFD_EMVDATA = 107,
        /// <summary>
        /// EMV AID configuration
        /// </summary>
        SFD_AID_CONFIG = 108,
        /// <summary>
        /// EMV POS configuration
        /// </summary>
        SFD_POS_CONFIG = 109,
        /// <summary>
        /// First purchase requirement for coupon
        /// /</summary>
        SFD_FIRST_COUPON_REQ = 110,
        /// <summary>
        /// Second purchase requirement for coupon
        /// </summary>
        SFD_SECOND_COUPON_REQ = 111,
        /// <summary>
        /// Third purchase requirement for coupon
        /// </summary>
        SFD_THIRD_COUPON_REQ = 112,
        /// <summary>
        /// FID if a coupon tax is manufacturer tax reimbursed
        /// </summary>
        SFD_MFRPAYSTAX_CONFIG = 113,
        /// <summary>
        /// FID for GS1 product Application Identifier info.
        /// </summary>
        SFD_PRODUCTAI_CONFIG = 114,
        /// <summary>
        /// FID for GS1 Metrics. Adding new sfd for GS1 timing metrics. Eventually this will should replace old SFD_DGE_METRIC
        /// </summary>
        SFD_ESL_METRIC = 115,
        /// <summary>
        /// Line Item EDH - GT Phase1 Salman
        /// </summary>
        SFD_LINEITEM = 116,
        /// <summary>
        /// GT  EDH PiPad Type
        /// </summary>
        SFD_EDH_PINPAD_CONFIG = 117,
        /// <summary>
        /// More Signaure Data for mx 915
        /// </summary>
        SFD_MORE_SIGNATURE_DATA = 118,
        /// <summary>
        /// 7RP used for additional data from arbitration
        /// </summary>
        /// SFD_DGE_EXTDATA = 116,
        /// <summary>
        /// Transaction Device Type.
		/// </summary>		


        /// <summary>
        /// PPHTH Added Discount for Prepaid cards
        /// </summary>
        SFD_DISCOUNT = 119,

		FD_DEVTYPE = 256,               
        /// <summary>
        /// Transaction Device #.
        /// </summary>
        FD_DEVNUM = 257,                  
        /// <summary>
        /// Transaction Sequence #.
        /// </summary>
        FD_TRANSEQ = 258,                
        /// <summary>
        /// Original Seq # of Tran for tracking.
        /// </summary>
        FD_ORIGSEQ = 259,   
        /// <summary>
        /// Transaction Date.
        /// </summary>
        FD_TRANDATE = 260,                      
        /// <summary>
        /// Transaction Time.
        /// </summary>
        FD_TRANTIME = 261,                      
        /// <summary>
        /// Operator Number.
        /// </summary>
        FD_OPERATOR = 262,     
        /// <summary>
        /// Transaction Code.
        /// </summary>              
        FD_TRANCODE = 263,                      
        /// <summary>
        /// Transaction Response.
        /// </summary>
        FD_TRANRC = 264,                  
        /// <summary>
        /// Transaction Flags.
        /// </summary>
        FD_TRANFLAG = 265,                     
        /// <summary>
        /// Current shift # for tran to be record.
        /// </summary>
        FD_SHIFTNUM = 266,  
        /// <summary>
        /// Current Day # for tran to be recorded.
        /// </summary>
        FD_DAYNUM = 267,  
        /// <summary>
        /// Source Adn # for sender.
        /// </summary>
        FD_SRCADN = 268,               
        /// <summary>
        /// ISP node = 0; POS node = Term #.
        /// </summary>
        FD_SRCNODE = 269,       
        /// <summary>
        /// Command Code.
        /// </summary>
        FD_CMD = 270,                          
        /// <summary>
        /// Result Code.
        /// </summary>
        FD_CMDRC = 271,                           
        /// <summary>
        /// Customer's driver id.
        /// </summary>
        FD_DRIVERLIC = 272,                  
        /// <summary>
        /// Social Security Number.
        /// </summary>
        FD_SOCIALSEC = 273,                
        /// <summary>
        /// Display text index.
        /// </summary>
        FD_DISPINDEX = 274,                    
        /// <summary>
        /// Transaction Total Amount.
        /// </summary>
        FD_TRANTOTAL = 276,              
        /// <summary>
        /// Comm Key to be Downloaded.
        /// </summary>
        FD_COMMKEY = 277,             
        /// <summary>
        /// Item flags.
        /// </summary>
        FD_LITEMFLAG = 278,                            
        /// <summary>
        /// Dept Number of item.
        /// </summary>
        FD_DEPTNUM = 279,                   
        /// <summary>
        /// PLU Number (7 digits - bcd).
        /// </summary>
        FD_PLUNUM = 280,           
        /// <summary>
        /// Discount rate for item.
        /// </summary>
        FD_DISCRATE = 281,                
        /// <summary>
        /// Discount amount for item.
        /// </summary>
        FD_DISCAMT = 282,              
        /// <summary>
        /// PLU Size.
        /// </summary>
        FD_SIZE = 283,                              
        /// <summary>
        /// Purchase Quantity.
        /// </summary>
        FD_QTY = 284,                     
        /// <summary>
        /// Total Amount for Product.
        /// </summary>
        FD_AMOUNT = 285,              
        /// <summary>
        /// Carwash code for customer.
        /// </summary>
        FD_CWCODE = 286,             
        /// <summary>
        /// Number of days carwash is good for.
        /// </summary>
        FD_CWDAYS = 287,    
        /// <summary>
        /// Type of carwash purchased.
        /// </summary>
        FD_CWTYPE = 288,             
        /// <summary>
        /// Product Number.
        /// </summary>
        FD_PRODUCT = 289,                        
        /// <summary>
        /// Purchase PPU.
        /// </summary>
        FD_PPU = 290,                          
        /// <summary>
        /// Pump Number.
        /// </summary>
        FD_PUMP = 291,                           
        /// <summary>
        /// Creepage amount at pump.
        /// </summary>
        FD_CREEPAGE = 292,               
        /// <summary>
        /// Prepay amount.
        /// </summary>
        FD_PREPAY = 293,                         
        /// <summary>
        /// Service Level.
        /// </summary>
        FD_SERVTIER = 294,                         
        /// <summary>
        /// Purchase Volume.
        /// </summary>
        FD_VOLUME = 295,                       
        /// <summary>
        /// Index.
        /// </summary>
        FD_INDEX = 296,                                 
        /// <summary>
        /// Foreign currency amt in CDB rpt.
        /// </summary>
        FD_FOREIGN = 297,       
        /// <summary>
        /// Internal Product Number.
        /// </summary>
        FD_PRODCODE = 298,               
        /// <summary>
        /// Item Restriction Status.
        /// </summary>
        FD_STATUS = 299,               
        /// <summary>
        /// Reason codes for paidouts and paidin.
        /// </summary>
        FD_REASNCODE = 300,  
        /// <summary>
        /// Media Type.
        /// </summary>
        FD_MEDIATYPE = 301,                            
        /// <summary>
        /// Account Number.
        /// </summary>
        FD_ACCTNUM = 302,                        
        /// <summary>
        /// Expiration Date.
        /// </summary>
        FD_EXPDATE = 303,                       
        /// <summary>
        /// Fleet Vehicle Number.
        /// </summary>
        FD_VEHICLE = 304,                  
        /// <summary>
        /// Drivers Licence Number.
        /// </summary>
        FD_DRIVER = 305,                
        /// <summary>
        /// Customer's odometer reading.
        /// </summary>
        FD_ODOMETER = 306,           
        /// <summary>
        /// Media number.
        /// </summary>
        FD_MEDIANUM = 307,                          
        /// <summary>
        /// Approval Number.
        /// </summary>
        FD_AUTHNUM = 308,                       
        /// <summary>
        /// Entry method for media.
        /// </summary>
        FD_ENTRYTYPE = 309,                
        /// <summary>
        /// Charges to add to sale for media.
        /// </summary>
        FD_FEE = 310,      
        /// <summary>
        /// Nid adn for authorization.
        /// </summary>
        FD_NIDADN = 311,             
        /// <summary>
        /// Track I Data.
        /// </summary>
        FD_TRACK1 = 312,                          
        /// <summary>
        /// Track II Data.
        /// </summary>
        FD_TRACK2 = 313,                         
        /// <summary>
        /// Pin entry.
        /// </summary>
        FD_PINBLOCK = 314,                             
        /// <summary>
        /// Canmax Card Definition.
        /// </summary>
        FD_CARDTYPE = 315,                
        /// <summary>
        /// Tax Table.
        /// </summary>
        FD_TAXTABLE = 316,                             
        /// <summary>
        /// Message to display in electronic jou.
        /// </summary>
        FD_COMMENT = 317,  
        /// <summary>
        /// IM to NID timeout.
        /// </summary>
        FD_TIMEOUT = 318,                     
        /// <summary>
        /// Track I Customer Name.
        /// </summary>
        FD_CUSTNAME = 319,                 
        /// <summary>
        /// Data to be matched by prompt entry.
        /// </summary>
        FD_ENTERVAL = 320,    
        /// <summary>
        /// PPU after media discount.
        /// </summary>
        FD_NEWPPU = 321,              
        /// <summary>
        /// Amount of the media discount.
        /// </summary>
        FD_MEDIADISC = 322,          
        /// <summary>
        /// $ Amount of the fuel pumped.
        /// </summary>
        FD_AMTPUMPED = 323,           
        /// <summary>
        /// Prepay media number.
        /// </summary>
        FD_PPMEDIA = 324,                   
        /// <summary>
        /// Network/Host Sequence Number.
        /// </summary>
        FD_NIDSEQ = 325,          
        /// <summary>
        /// Block Number withing multi-block msg.
        /// </summary>
        FD_BLKNUM = 326,  
        /// <summary>
        /// Last/End Block.
        /// </summary>
        FD_LSTBLK = 327,                        
        /// <summary>
        /// Nid task identifier.
        /// </summary>
        FD_NIDID = 328,                   
        /// <summary>
        /// Nid task status flag.
        /// </summary>
        FD_NIDSTATUS = 329,                  
        /// <summary>
        /// Preauth Amount Nid sends to the Host.
        /// </summary>
        FD_NIDATHAMT = 330,  
        /// <summary>
        /// Card allowed from ICR.
        /// </summary>
        FD_FLGICR = 331,                 
        /// <summary>
        /// Card allowed from POS.
        /// </summary>
        FD_FLGPOS = 332,                 
        /// <summary>
        /// Fallback allowed from ICR.
        /// </summary>
        FD_FLGICRFAL = 333,             
        /// <summary>
        /// Fallback allowed from POS.
        /// </summary>
        FD_FLGPOSFAL = 334,             
        /// <summary>
        /// Instant on allowed.
        /// </summary>
        FD_FLGINSTNT = 335,                    
        /// <summary>
        /// Floor limit.
        /// </summary>
        FD_FLOORLMT = 336,                           
        /// <summary>
        /// Fallback limit.
        /// </summary>
        FD_FALLBKLMT = 337,                        
        /// <summary>
        /// Pump shut amount.
        /// </summary>
        FD_SHUTAMT = 338,                      
        /// <summary>
        /// Masked account number.
        /// </summary>
        FD_MASKACCT = 339,                 
        /// <summary>
        /// Price Level.
        /// </summary>
        FD_PRICELVL = 340,                           
        /// <summary>
        /// Display message.
        /// </summary>
        FD_DISPMSG = 341,                       
        /// <summary>
        /// Cash Drawer Report.
        /// </summary>
        FD_CSHDRAWER = 342,                    
        /// <summary>
        /// Audit Report.
        /// </summary>
        FD_AUDIT = 343,                          
        /// <summary>
        /// ICR Ticket Flag.
        /// </summary>
        FD_FLGICRTCK = 344,                       
        /// <summary>
        /// Generic Count.
        /// </summary>
        FD_COUNT = 345,                          
        /// <summary>
        /// Print Account Number on ICR receipt.
        /// </summary>
        FD_ACCTRCPT = 346,   
        /// <summary>
        /// Card Type Enabled (0/1).
        /// </summary>
        FD_CTENABLE = 347,               
        /// <summary>
        /// State Code.
        /// </summary>
        FD_STATECODE = 348,                            
        /// <summary>
        /// Nid specific response data.
        /// </summary>
        FD_AUTHCODE1 = 349,            
        /// <summary>
        /// Nid specific response data.
        /// </summary>
        FD_AUTHCODE2 = 350,            
        /// <summary>
        /// Nid Batch Number (000-999).
        /// </summary>
        FD_NIDBATCH = 351,            
        /// <summary>
        /// Nid Reference Number (0000-9999).
        /// </summary>
        FD_NIDREFNUM = 352,      
        /// <summary>
        /// Rouding.
        /// </summary>
        FD_ROUNDING = 353,                               
        /// <summary>
        /// Original Device Type - completion.
        /// </summary>
        FD_ODEVTYPE = 354,     
        /// <summary>
        /// Original Device Number - completion.
        /// </summary>
        FD_ODEVNUM = 355,   
        /// <summary>
        /// Velocity Check Enabled.
        /// </summary>
        FD_FLGVEL = 356,                
        /// <summary>
        /// Authorization Type.
        /// </summary>
        FD_AUTHTYPE = 357,                    
        /// <summary>
        /// Price markup/markdown.
        /// </summary>
        FD_MARKUP = 358,                 
        /// <summary>
        /// Default item size.
        /// </summary>
        FD_DEFSIZE = 359,                     
        /// <summary>
        /// Network User Data.
        /// </summary>
        FD_USERDATA = 360,                     
        /// <summary>
        /// Original Batch#.
        /// </summary>
        FD_ORIGBATCH = 361,                       
        /// <summary>
        /// Original Ref#.
        /// </summary>
        FD_ORIGREF = 362,
        /// <summary>
        /// Original Transaction Date.
        /// </summary>
        FD_ORIGDATE = 363,             
        /// <summary>
        /// Authorization Time.
        /// </summary>
        FD_AUTHTIME = 364,                    
        /// <summary>
        /// Report ID.
        /// </summary>
        FD_RPTID = 365,                             
        /// <summary>
        /// Customer Reference# - NID.
        /// </summary>
        FD_CUSTREFNUM = 366,             
        /// <summary>
        /// Retry.
        /// </summary>
        FD_RETRY = 367,                                 
        /// <summary>
        /// Command Context.
        /// </summary>
        FD_CMDCTX = 368,                       
        /// <summary>
        /// Store Name.
        /// </summary>
        FD_STORENAME = 369,                            
        /// <summary>
        /// Store Address.
        /// </summary>
        FD_STOREADDR = 370,                         
        /// <summary>
        /// City.
        /// </summary>
        FD_CITY = 371,                                  
        /// <summary>
        /// Zip Code.
        /// </summary>
        FD_ZIPCODE = 372,                              
        /// <summary>
        /// Phone Number.
        /// </summary>
        FD_PHONENUM = 373,                          
        /// <summary>
        /// Store Number.
        /// </summary>
        FD_STORENUM = 374,                          
        /// <summary>
        /// Tax ID 1.
        /// </summary>
        FD_TAXID1 = 375,                              
        /// <summary>
        /// Tax ID 2.
        /// </summary>
        FD_TAXID2 = 376,                              
        /// <summary>
        /// Receipt Header 1.
        /// </summary>
        FD_HEADER1 = 377,                      
        /// <summary>
        /// Receipt Header 2.
        /// </summary>
        FD_HEADER2 = 378,                      
        /// <summary>
        /// Receipt Header 3.
        /// </summary>
        FD_HEADER3 = 379,                      
        /// <summary>
        /// Receipt Header 4.
        /// </summary>
        FD_HEADER4 = 380,                      
        /// <summary>
        /// Receipt Footer 1.
        /// </summary>
        FD_FOOTER1 = 381,                      
        /// <summary>
        /// Receipt Footer 2.
        /// </summary>
        FD_FOOTER2 = 382,                      
        /// <summary>
        /// Check Validation Message.
        /// </summary>
        FD_VALIDATION = 383,              
        /// <summary>
        /// Terminal Count.
        /// </summary>
        FD_TERMCNT = 384,                        
        /// <summary>
        /// Date Format.
        /// </summary>
        FD_DATEFMT = 385,                           
        /// <summary>
        /// Discount Halo.
        /// </summary>
        FD_DISCHALO = 386,                         
        /// <summary>
        /// Quantity Halo.
        /// </summary>
        FD_QTYHALO = 387,                         
        /// <summary>
        /// Unit Halo.
        /// </summary>
        FD_UNITHALO = 389,                             
        /// <summary>
        /// Cash Back Halo.
        /// </summary>
        FD_CBHALO = 390,                        
        /// <summary>
        /// Login Retries Allowed.
        /// </summary>
        FD_LOGINRETRY = 391,                 
        /// <summary>
        /// Login Time Allowed.
        /// </summary>
        FD_LOGINTIME = 392,                    
        /// <summary>
        /// Login Lockout Time.
        /// </summary>
        FD_LOGINLKOUT = 393,                    
        /// <summary>
        /// Password Change Time.
        /// </summary>
        FD_PSWDCHNGE = 394,                  
        /// <summary>
        /// Password Digits.
        /// </summary>
        FD_PSWDDIGIT = 395,                       
        /// <summary>
        /// Alarm Safe Drop Amount.
        /// </summary>
        FD_ALRMDRPAMT = 396,                
        /// <summary>
        /// Force Safa Drop Amount.
        /// </summary>
        FD_FRCEDRPAMT = 397,                
        /// <summary>
        /// System Parameter Flags.
        /// </summary>
        FD_SYSPARMFLGS = 398,                
        /// <summary>
        /// Max Shifts per Day.
        /// </summary>
        FD_MAXSHIFTS = 399,
        /// <summary>
        /// Terminal Number.
        /// </summary>
        FD_TERMNUM = 400,
        /// <summary>
        /// Terminal Type.
        /// </summary>
        FD_TERMTYPE = 401,                         
        /// <summary>
        /// Scanner Port.
        /// </summary>
        FD_SCANPORT = 402,                          
        /// <summary>
        /// MSR Port.
        /// </summary>
        FD_MSRPORT = 403,                              
        /// <summary>
        /// Customer Display Port.
        /// </summary>
        FD_CDPORT = 404,                 
        /// <summary>
        /// PIN Pad Port.
        /// </summary>
        FD_PPPORT = 405,                          
        /// <summary>
        /// EOS Flags.
        /// </summary>
        FD_EOSFLGS = 406,                             
        /// <summary>
        /// EOD Flags.
        /// </summary>
        FD_EODFLGS = 407,                             
        /// <summary>
        /// Terminal Flags.
        /// </summary>
        FD_TERMFLGS = 408,                        
        /// <summary>
        /// Media Flags.
        /// </summary>
        FD_MEDIAFLGS = 409,                           
        /// <summary>
        /// LALO.
        /// </summary>
        FD_LALO = 410,                                  
        /// <summary>
        /// HALO.
        /// </summary>
        FD_HALO = 411,                                  
        /// <summary>
        /// Exchange Rate.
        /// </summary>
        FD_XCHNGERATE = 412,                         
        /// <summary>
        /// Change Media.
        /// </summary>
        FD_CHNGEMEDIA = 413,                          
        /// <summary>
        /// Employee Number.
        /// </summary>
        FD_EMPNUM = 414,                       
        /// <summary>
        /// Password.
        /// </summary>
        FD_PASSWORD = 415,                              
        /// <summary>
        /// Security Level.
        /// </summary>
        FD_SECLVL = 416,                        
        /// <summary>
        /// Employee Flags.
        /// </summary>
        FD_EMPFLGS = 417,                        
        /// <summary>
        /// POS Key Assignment.
        /// </summary>
        FD_KEYASSGN = 418,                    
        /// <summary>
        /// Preset Department Key.
        /// </summary>
        FD_PDEPTKEY = 419,                 
        /// <summary>
        /// Preset PLU Key.
        /// </summary>
        FD_PPLUKEY = 420,                        
        /// <summary>
        /// Award Promo Id.
        /// </summary>
        FD_PROMOID = 421,                        
        /// <summary>
        /// Award Audit Number.
        /// </summary>
        FD_AUDITNUM = 422,                    
        /// <summary>
        /// Award Message Line 1.
        /// </summary>
        FD_DISPMSG1 = 423,                  
        /// <summary>
        /// Award Message Line 2.
        /// </summary>
        FD_DISPMSG2 = 424,                  
        /// <summary>
        /// Award Message Line 3.
        /// </summary>
        FD_DISPMSG3 = 425,                  
        /// <summary>
        /// Award Message Line 4.
        /// </summary>
        FD_DISPMSG4 = 426,                  
        /// <summary>
        /// Award Message Line 5.
        /// </summary>
        FD_DISPMSG5 = 427,                  
        /// <summary>
        /// Award Message Line 6.
        /// </summary>
        FD_DISPMSG6 = 428,                  
        /// <summary>
        /// Award Message Line 7.
        /// </summary>
        FD_DISPMSG7 = 429,                  
        /// <summary>
        /// General Description/Name.
        /// </summary>
        FD_DESCRIPTION = 430,              
        /// <summary>
        /// Department Flags.
        /// </summary>
        FD_DEPTFLGS = 431,                      
        /// <summary>
        /// Tax Flags.
        /// </summary>
        FD_TAXFLGS = 432,                             
        /// <summary>
        /// Restriction Code.
        /// </summary>
        FD_RESTCODE = 433,                      
        /// <summary>
        /// Event Category.
        /// </summary>
        FD_EVTCAT = 434,  
        /// <summary>
        /// Event Source.
        /// </summary>
        FD_EVTSRC = 435,                          
        /// <summary>
        /// Event Id.
        /// </summary>
        FD_EVTID = 436,                              
        /// <summary>
        /// Event Data.
        /// </summary>
        FD_EVTDATA = 437,                            
        /// <summary>
        /// Hot/Warm Response.
        /// </summary>
        FD_HWRSP = 438,                     
        /// <summary>
        /// Card Id.
        /// </summary>
        FD_CARDID = 439,                               
        /// <summary>
        /// ???.
        /// </summary>
        FD_LOCALFLAG = 440,                                   
        /// <summary>
        /// ???.
        /// </summary>
        FD_OVERLIMIT = 441,                                   
        /// <summary>
        /// ???.
        /// </summary>
        FD_RESTCODES = 442,                                   
        /// <summary>
        /// Hose (Position Number).
        /// </summary>
        FD_HOSENUM = 443,                
        /// <summary>
        /// Primary Tank Number.
        /// </summary>
        FD_PRITANK = 444,                   
        /// <summary>
        /// Secondary Tank Number.
        /// </summary>
        FD_SECTANK = 445,                 
        /// <summary>
        /// Primary Tank Volume.
        /// </summary>
        FD_PRITANKVOL = 446,                   
        /// <summary>
        /// Secondary Tank Volume.
        /// </summary>
        FD_SECTANKVOL = 447,                 
        /// <summary>
        /// Fuel Price Table (cash/credit).
        /// </summary>
        FD_FLPRCETBL = 448,        
        /// <summary>
        /// Timestamp (YYYYMMDDHHMMSS).
        /// </summary>
        FD_TIMESTAMP = 449,            
        /// <summary>
        /// Priority.
        /// </summary>
        FD_PRIORITY = 450,                              
        /// <summary>
        /// Command Sequence.
        /// </summary>
        FD_CMDSEQ = 451,                      
        /// <summary>
        /// Tax Rate (precision 3 dec. digits).
        /// </summary>
        FD_TAXRATE = 452,    
        /// <summary>
        /// Tax Method.
        /// </summary>
        FD_TAXMETHOD = 453,                            
        /// <summary>
        /// Tax Breakpoint Amount.
        /// </summary>
        FD_TAXBRKPNT = 454,                 
        /// <summary>
        /// POS Key Function Code.
        /// </summary>
        FD_POSFUNCODE = 455,                 
        /// <summary>
        /// POS Key Function Flags.
        /// </summary>
        FD_POSFUNFLGS = 456,                
        /// <summary>
        /// Age.
        /// </summary>
        FD_AGE = 457,                                   
        /// <summary>
        /// ID Length.
        /// </summary>
        FD_IDLEN = 458,                             
        /// <summary>
        /// Unit Descriptor Size Group.
        /// </summary>
        FD_SIZEGRP = 459,            
        /// <summary>
        /// Price Multiple.
        /// </summary>
        FD_PRCEMLT = 460,                        
        /// <summary>
        /// Physical Dispenser Number.
        /// </summary>
        FD_PHDISPNUM = 461,             
        /// <summary>
        /// Adjacent Dispenser Number.
        /// </summary>
        FD_ADJDISPNUM = 462,             
        /// <summary>
        /// Controller Number.
        /// </summary>
        FD_CTRLNUM = 463,                     
        /// <summary>
        /// Volume Meter Digits.
        /// </summary>
        FD_VOLDIGIT = 464,                   
        /// <summary>
        /// Money Meter Digits.
        /// </summary>
        FD_MONDIGIT = 465,                    
        /// <summary>
        /// Wiring Type.
        /// </summary>
        FD_WIRETYPE = 466,                           
        /// <summary>
        /// Primary Product Id.
        /// </summary>
        FD_PRIPROD = 467,                    
        /// <summary>
        /// Secondary Product Id.
        /// </summary>
        FD_SECPROD = 468,                  
        /// <summary>
        /// Blend Ratio.
        /// </summary>
        FD_BLEND = 469,                           
        /// <summary>
        /// Fuel Parameter Flags.
        /// </summary>
        FD_FLPARMFLGS = 470,                  
        /// <summary>
        /// Environment Tax Rate.
        /// </summary>
        FD_ENVTAXRATE = 480,                  
        /// <summary>
        /// Fuel Price Group Id.
        /// </summary>
        FD_FLPRCEGRP = 481,                   
        /// <summary>
        /// Fuel Dispenser Operational Flags.
        /// </summary>
        FD_FLDISPFLGS = 482,      
        /// <summary>
        /// Item ID.
        /// </summary>
        FD_ITEMID = 483,                               
        /// <summary>
        /// Item Flags.
        /// </summary>
        FD_ITEMFLGS = 484,                            
        /// <summary>
        /// Mix/Match Code.
        /// </summary>
        FD_MMCODE = 485,                        
        /// <summary>
        /// Markup Type.
        /// </summary>
        FD_MUTYPE = 486,                           
        /// <summary>
        /// Item Price.
        /// </summary>
        FD_PRICE = 487,                            
        /// <summary>
        /// Item Old Price.
        /// </summary>
        FD_OLDPRICE = 488,                        
        /// <summary>
        /// Carry Status.
        /// </summary>
        FD_CARRYSTAT = 489,                          
        /// <summary>
        /// Inventory Adjustment Size Index.
        /// </summary>
        FD_INVADJSIZE = 490,       
        /// <summary>
        /// Item Size Flags.
        /// </summary>
        FD_ITEMSZFLGS = 491,                       
        /// <summary>
        /// Linked Item Id.
        /// </summary>
        FD_LNKITEMID = 492,                        
        /// <summary>
        /// Linked Item Size Index.
        /// </summary>
        FD_LNKSIZE = 493,                
        /// <summary>
        /// Total Volume.
        /// </summary>
        FD_TOTVOL = 494,                          
        /// <summary>
        /// Cash Price.
        /// </summary>
        FD_CASHPRC = 495,                            
        /// <summary>
        /// Credit Price.
        /// </summary>
        FD_CREDPRC = 496,                          
        /// <summary>
        /// Message Type.
        /// </summary>
        FD_MSGTYPE = 497,                          
        /// <summary>
        /// Controller Version.
        /// </summary>
        FD_CTRLVER = 498,                    
        /// <summary>
        /// Device Version.
        /// </summary>
        FD_DEVVER = 499,                        
        /// <summary>
        /// Lock Type.
        /// </summary>
        FD_LOCKTYPE = 500,                             
        /// <summary>
        /// Time.
        /// </summary>
        FD_TIME = 501,                                  
        /// <summary>
        /// Option Id.
        /// </summary>
        FD_OPTIONID = 502,                             
        /// <summary>
        /// Action (???).
        /// </summary>
        FD_ACTION = 503,                          
        /// <summary>
        /// Exception Id.
        /// </summary>
        FD_EXCEPTID = 504,                          
        /// <summary>
        /// Cron command approval flag.
        /// </summary>
        FD_APPROVE = 505,            
        /// <summary>
        /// Clear fuel sale after read flag.
        /// </summary>
        FD_CLRSALE = 506,       
        /// <summary>
        /// Cash Prepay Refund.
        /// </summary>
        FD_REFUND = 507,                    
        /// <summary>
        /// Prepay/Preset flag.
        /// </summary>
        FD_TYPEAUTH = 508,                    
        /// <summary>
        /// Fuel Sequence #.
        /// </summary>
        FD_FUELSEQ = 509,                       
        /// <summary>
        /// Pump/ICR Parameters.
        /// </summary>
        FD_PUMPPARMS = 510,                   
        /// <summary>
        /// Device Controller.
        /// </summary>
        FD_DEVCTRL = 511,                     
        /// <summary>
        /// ICR Info.
        /// </summary>
        FD_ICRINFO = 512,                              
        /// <summary>
        /// ICR Display Messages.
        /// </summary>
        FD_ICRDISPMSGS = 513,                  
        /// <summary>
        /// ICR Receipt Messages.
        /// </summary>
        FD_ICRRCPTMSGS = 514,                  
        /// <summary>
        /// Price Override Amount.
        /// </summary>
        FD_PRCOVERUP = 515,                 
        /// <summary>
        /// Transfer Pump.
        /// </summary>
        FD_TRANPUMP = 516,                         
        /// <summary>
        /// Original customer reference number.
        /// </summary>
        FD_ORIGCUSTREF = 517,    
        /// <summary>
        /// Fuel Meter Reading volume.
        /// </summary>
        FD_METERVOL	= 518,             
        /// <summary>
        /// Fuel Meter Reading hose state.
        /// </summary>
	    FD_HOSESTATE = 519,         
        /// <summary>
        /// Network terminal ID.
        /// </summary>
        FD_NIDTERMID = 520,                   
        /// <summary>
        /// Local network terminal ID.
        /// </summary>
        FD_NIDLOCALTERM = 521,            
        /// <summary>
        /// PLU Size Flags.
        /// </summary>
        FD_PLUSZFLGS = 522,                        
        /// <summary>
        /// The max amount of network authorization.
        /// </summary>
        FD_PREAUTHAMT = 523,   
        /// <summary>
        /// The data collect user data string for fleet cards.
        /// </summary>
        FD_USERDATA2 = 524,   
        /// <summary>
        /// Mix Match ID.
        /// </summary>
        FD_MIXMATCHID = 525,                          
        /// <summary>
        /// store profile flags.
        /// </summary>
	    FD_STOREPROFILEFLGS = 526,             
        /// <summary>
        /// Type of Field from DRVLIC.
        /// </summary>
        FD_FIELDTYPE = 527,	             
        /// <summary>
        /// Track No of field in DRVLIC.
        /// </summary>
	    FD_TRACKNO = 528,	           
        /// <summary>
        /// Position of field in Track in DRVLIC.
        /// </summary>
	    FD_POSITION	= 529,	  
        /// <summary>
        /// Length of field in DRVLIC.
        /// </summary>
	    FD_LENGTH =	530,	             
        /// <summary>
        /// Format of (date fields in DRVLIC).
        /// </summary>
        FD_FORMAT = 531,	     
        /// <summary>
        /// Item Restrictions Flag.
        /// </summary>
        FD_IRESTFLAG = 532,	                
        /// <summary>
        /// EOS or EOD flag broadcast to POS.
        /// </summary>
	    FD_EOSEOD = 533,	      
        /// <summary>
        /// Deposit Dept for CRV.
        /// </summary>
        FD_DEPOSITDEPT = 534,	                  
        /// <summary>
        /// Deposit Amt for CRV.
        /// </summary>
	    FD_DEPOSITAMT = 535,	                   
        /// <summary>
        /// Misc Total Type from POS to EJ.
        /// </summary>
        FD_TOTALTYPE = 536,	        
        /// <summary>
        /// Minimum Minutes allowed between EODs.
        /// </summary>
        FD_EODINTERVAL = 537,	                          
        /// <summary>
        /// Type of request.
        /// </summary>
        FD_REQTYPE = 538,                            
        /// <summary>
        /// Command File pathname.
        /// </summary>
        FD_CMDFILE = 539,                     
        /// <summary>
        /// Session number.
        /// </summary>
        FD_SESSIONNUM = 540,                            
        /// <summary>
        /// Payment method.
        /// </summary>
        FD_PAYMETHOD = 541,                            
        /// <summary>
        /// Mix Match Type.
        /// </summary>
        FD_MIXMATCHTYPE = 542,                            
        /// <summary>
        /// Limit per Transaction.
        /// </summary>
        FD_LIMIT = 543,                     
        /// <summary>
        /// Mix Match Group ID.
        /// </summary>
        FD_MIXMATCHGRP = 544, 	                    
        /// <summary>
        /// Group Flags.
        /// </summary>
        FD_GROUPFLAGS = 545,                               
        /// <summary>
        /// Mix Match Sequence (Bit Map).
        /// </summary>
        FD_MIXMATCHSEQ = 546,              
        /// <summary>
        /// FallBack Amt Credit.
        /// </summary>
        FD_FALLBACKCREDIT = 547,            
        /// <summary>
        /// Debit allowed Flag.
        /// </summary>
        FD_DEBITFLG = 548,  	        
        /// <summary>
        /// Manual Allowed Flag.
        /// </summary>
        FD_MANUALFLG = 549,            
        /// <summary>
        /// Prepaid Cards Allowed.
        /// </summary>
        FD_PREPAIDFLG = 550,          
        /// <summary>
        /// CashBack Allowed Flagh.
        /// </summary>
        FD_CASHBACK = 551,         
        /// <summary>
        /// Birth Date.
        /// </summary>
        FD_BIRTHDATE = 552,                     
        /// <summary>
        /// Account Type Code.
        /// </summary>
        FD_ACCTTYPE = 553,              
        /// <summary>
        /// Authorizing Party Name.
        /// </summary>
        FD_AUTHPARTYNAME = 554,         
        /// <summary>
        /// Authorization Trace ID.
        /// </summary>
        FD_AUTHTRACEID = 555,         
        /// <summary>
        /// Debit PreAuth Amount.
        /// </summary>
        FD_DEBITPREAMT = 556,           
        /// <summary>
        /// Prepaid PReAuth Amount.
        /// </summary>
        FD_PREPAIDPREAMT = 557,         
        /// <summary>
        /// Prepaid Icr Ticket.
        /// </summary>
        FD_PREPAIDICRTICKET = 558,	            
        /// <summary>
        /// Account Option.
        /// </summary>
        FD_ACCTOPT = 559,                 
        /// <summary>
        /// Zip Code Required Flag (0/1).
        /// </summary>
        FD_ZIPCODEFLAG = 560,    
        /// <summary>
        /// Printer Port.
        /// </summary>
        FD_PRTPORT = 561,                   
        /// <summary>
        /// Security Camera Port.
        /// </summary>
        FD_CAMERAPORT = 562,           
        /// <summary>
        /// Customer Display Welcome Message 1.
        /// </summary>
        FD_CSTDSPMSG1 = 563,   
        /// <summary>
        /// Customer Display Welcome Message 2.
        /// </summary>
        FD_CSTDSPMSG2 = 564,   
        /// <summary>
        /// Pin Pad Welcome Message 1.
        /// </summary>
        FD_PINPADMSG1 = 565,   
        /// <summary>
        /// Pip Pad Welcome Message 2.
        /// </summary>
        FD_PINPADMSG2 = 566,   
        /// <summary>
        /// Force EOS/EOD Message 1.
        /// </summary>
        FD_EOSEODMSG1 = 567,   
        /// <summary>
        /// Force EOS/EOD Message 2.
        /// </summary>
        FD_EOSEODMSG2 = 568,   
        /// <summary>
        /// Force EOS/EOD Message 3.
        /// </summary>
        FD_EOSEODMSG3 = 569,   
        /// <summary>
        /// Force EOS/EOD Message 4.
        /// </summary>
        FD_EOSEODMSG4 = 570,   
        /// <summary>
        /// Force EOS/EOD Message 5.
        /// </summary>
        FD_EOSEODMSG5 = 571,   
        /// <summary>
        /// Receipt Tax label.
        /// </summary>
        FD_RCPTLABEL = 572,   
        /// <summary>
        /// Customer Code.
        /// </summary>
        FD_CUSTOMER = 573,   
        /// <summary>
        /// Tax Amount.
        /// </summary>
        FD_TAXAMOUNT = 574,   
        /// <summary>
        /// Base retail price for markup/markdown.
        /// </summary>
	    FD_MARKUPBASE = 575,   
        /// <summary>
        /// Zip Code Manual Entry Required Flag (0/1).
        /// </summary>
        FD_ZIPCODEFLAG_ME = 576,   
        /// <summary>
        /// Threshold of quantity for promotion group.
        /// </summary>
        FD_GROUPQTY = 577,   
        /// <summary>
        /// POS auto logoff timeout (in minutes .
        /// </summary>
	    FD_SIGNOFF = 578,  
        /// <summary>
        /// Internet card fee department number.
        /// </summary>
        FD_FEEDEPT = 579,   
        /// <summary>
        /// Internet card system trace transaction number.
        /// </summary>
        FD_STTN	= 580,   
        /// <summary>
        /// Event  Company Number.
        /// </summary>
        FD_EVTCOMPANYNUM = 581,  
        /// <summary>
        /// Event  Store Number.
        /// </summary>
        FD_EVTSTORENUM = 582,  
        /// <summary>
        /// Company Number.
        /// </summary>
        FD_COMPANYNUM = 583,   
        /// <summary>
        /// Transaction Unique ID.
        /// </summary>
        FD_TRANSUID = 585,   
        /// <summary>
        /// PPU Change Warning Date.
        /// </summary>
        FD_WARNDATE = 586,   
        /// <summary>
        /// PPU Change Warning Time.
        /// </summary>
        FD_WARNTIME = 587,  
        /// <summary>
        /// PPU Change Effective Date.
        /// </summary>
        FD_EFCVDATE = 588,   
        /// <summary>
        /// PPU Change Effective Time.
        /// </summary>
        FD_EFCVTIME	= 589,  
        /// <summary>
        /// PPU Status.
        /// </summary>
        FD_PPUSTAT = 590,   
        /// <summary>
        /// Foreign Day Number.
        /// </summary>
        FD_FOREIGNDAYNUM = 591,   
        /// <summary>
        /// Network Unique Reference Number.
        /// </summary>
        FD_REFNUM = 592,   
        /// <summary>
        /// Fuel Product Description.
        /// </summary>
        FD_PRODDESC = 593,   
        /// <summary>
        /// Fuel Service Level Description.
        /// </summary>
        FD_SVCLVLDESC = 594,   
        /// <summary>
        /// Enables automated money order sales from POS.
        /// </summary>
        FD_MOFLG = 595,   
        /// <summary>
        /// Fid to handle money order and all other new breakpoint fees .
        /// </summary>
        FD_BREAKPOINT = 596,  
        /// <summary>
        /// Money order serial number.
        /// </summary>
        FD_SERIALNO	= 597,   
        /// <summary>
        /// software release version number.
        /// </summary>
        FD_RELEASE = 598,   
        /// <summary>
        /// bank account routing number.
        /// </summary>
        FD_ROUTINGNUM = 599,   
        /// <summary>
        /// check number.
        /// </summary>
	    FD_CHECKNUM = 600,   
        /// <summary>
        /// generic fid for any message.
        /// </summary>
        FD_MESSAGE = 601,	  			
        /// <summary>
        /// Message line number (check auth msg.
        /// </summary>
	    FD_LINENUM = 602,	  				
        /// <summary>
        /// message type code (check auth msg).
        /// </summary>
	    FD_MSGTYPECODE = 603,   
        /// <summary>
        /// nw: pdl debit shutoff amt.
        /// </summary>
        FD_DEBITSHUTAMT = 604,	  
        /// <summary>
        /// nw:  pdl prepaid shutoff amt.
        /// </summary>
        FD_PREPAIDSHUTAMT = 605,   			
        /// <summary>
        /// item product code.
        /// </summary>
        FD_ITEMPRODCD = 606,   
        /// <summary>
        /// promotion product code.
        /// </summary>
        FD_MIXMATCHCD = 607,   
        /// <summary>
        /// receipt control maximum transaction amount.
        /// </summary>
        FD_RCPTPRNTMAXAMT = 608,   
        /// <summary>
        /// Pos Items / department flags.
        /// </summary>
        FD_POSFLGS = 609,    
        /// <summary>
        /// GST data as string.
        /// </summary>
        FD_GST = 610,   
        /// <summary>
        /// Fuel total (GST).
        /// </summary>
        FD_FUELTOTAL = 611,   
        /// <summary>
        /// Controller Device ID.
        /// </summary>
        FD_CTLRDEV = 612,    
        /// <summary>
        /// Controller Vendor ID.
        /// </summary>
        FD_CTLRVENDOR = 613,   
        /// <summary>
        /// Controller Model ID.
        /// </summary>
        FD_CTLRMODEL = 614,   
        /// <summary>
        /// Controller Port Type.
        /// </summary>
        FD_CTLRPORTTYPE = 615,   
        /// <summary>
        /// Controller Port.
        /// </summary>
        FD_CTLRPORT = 616,   
        /// <summary>
        /// Logical Dispenser Number.
        /// </summary>
        FD_LOGDISPNUM = 617,   
        /// <summary>
        /// Keyboard Layout.
        /// </summary>
        FD_KEYBDLAYOUT = 618,   
        /// <summary>
        /// IPR flags.
        /// </summary>
        FD_IPRFLAGS = 619,   
        /// <summary>
        /// Printer Line Size.
        /// </summary>
        FD_PRTLNSIZE = 620,   
        /// <summary>
        /// Printer Minimum Receipt Length.
        /// </summary>
        FD_PRTMINLEN = 621,   
        /// <summary>
        /// Printer Extra Spacing.
        /// </summary>
        FD_PRTXTRASPC = 622,   
        /// <summary>
        /// Positive Action.
        /// </summary>
        FD_PSTVACTN = 623,   
        /// <summary>
        /// Debit Key Number.
        /// </summary>
        FD_DEBITKEYNUM = 624,    
        /// <summary>
        /// Display Type.
        /// </summary>
        FD_DISPLAYTYPE = 625,   
        /// <summary>
        /// Wiring Type.
        /// </summary>
        FD_WIRINGTYPE = 626,   
        /// <summary>
        /// Cash Acceptor Maximum Vault Bill Count.
        /// </summary>
        FD_CAMAXVLTBILLCNT = 627,    
        /// <summary>
        /// Cash Acceptor Maximum Sale Amount.
        /// </summary>
        FD_CAMAXSALEAMT = 628,   
        /// <summary>
        /// Cash Acceptor Maximum Sale Bill Count.
        /// </summary>
        FD_CAMAXSALEBILLCNT = 629,      
        /// <summary>
        /// Debit Controller Number.
        /// </summary>
        FD_DEBITCTLRNUM = 630,      
        /// <summary>
        /// Card Reader Type.
        /// </summary>
        FD_CARDRDRTYPE = 631,      
        /// <summary>
        /// Debit Security Type.
        /// </summary>
        FD_DEBITSCRTYTYPE = 632,      
        /// <summary>
        /// Number of Pumps Controlled.
        /// </summary>
        FD_NUMPMPSCTRLD = 633,      
        /// <summary>
        /// Greeting Message (IPR).
        /// </summary>
        FD_GREETMSG = 634,      
        /// <summary>
        /// Authorization Message (IPR).
        /// </summary>
        FD_AUTHMSG = 635,      
        /// <summary>
        /// Fueling Message (IPR).
        /// </summary>
        FD_FUELMSG = 636,      
        /// <summary>
        /// Printing Message (IPR).
        /// </summary>
        FD_PRINTMSG = 637,      
        /// <summary>
        /// Pump Sale Limit  (pump parameters).
        /// </summary>
        FD_PUMPSALELIMIT = 638,    
        /// <summary>
        /// Pump Slow Flow.
        /// </summary>
        FD_PUMPSLOWFLOW = 639,    
        /// <summary>
        /// POS Repeat Message Wait.
        /// </summary>
        FD_POSRPTMSGWAIT = 640,    
        /// <summary>
        /// Credit Deauthorization Time.
        /// </summary>
        FD_CREDITDAUTHTIME = 641,    
        /// <summary>
        /// Cash Deauthorization Time.
        /// </summary>
        FD_CASHDAUTHTIME = 642,    
        /// <summary>
        /// Pump Call Delay.
        /// </summary>
        FD_PUMPCALLDELAY = 643,    
        /// <summary>
        /// Instant On Delay.
        /// </summary>
        FD_INSTANTONDELAY = 644,    
        /// <summary>
        /// Pump Parameter Flags.
        /// </summary>
        FD_PUMPFLAGS = 645,    
        /// <summary>
        /// Pump Count.
        /// </summary>
        FD_PUMPCOUNT = 646,    
        /// <summary>
        /// ICR Count.
        /// </summary>
        FD_ICRCOUNT = 647,    
        /// <summary>
        /// Receipt Control.
        /// </summary>
        FD_RECEIPTCTRL = 648,    
        /// <summary>
        /// Network Debit Type.
        /// </summary>
        FD_NWDEBITTYPE = 649,    
        /// <summary>
        /// Magnetic Ink Character Recognition (check authorization).
        /// </summary>
        FD_MICR = 650,       
        /// <summary>
        /// Network Authorization Mode: preauth; postauth.
        /// </summary>
        FD_NWAUTHMODE = 651,       
        /// <summary>
        /// Root - Request for Store Profile.
        /// </summary>
        RFD_REQ_STORE_PROF = 652,	  
        /// <summary>
        /// Root - Response for Store Profile.
        /// </summary>
        RFD_RSP_STORE_PROF = 653,	  
        /// <summary>
        /// Root - Request for Fuel Params.
        /// </summary>
        RFD_REQ_FUEL_PARAMS = 654,	  
        /// <summary>
        /// Root - Response for Fuel Params.
        /// </summary>
        RFD_RSP_FUEL_PARAMS = 655,	  
        /// <summary>
        /// Root - Request for Fuel Display Config.
        /// </summary>
        RFD_REQ_FUEL_DISP_CFG = 656,	  
        /// <summary>
        /// Root - Response for Fuel Display Config.
        /// </summary>
        RFD_RSP_FUEL_DISP_CFG = 657,	  
        /// <summary>
        /// Root - Request for Display Operational Params.
        /// </summary>
        RFD_REQ_DISP_OP_PARAMS = 658,	  
        /// <summary>
        /// Root - Response for Display Operational Params.
        /// </summary>
        RFD_RSP_DISP_OP_PARAMS = 659,	  
        /// <summary>
        /// Root - Request for Fuel Products.
        /// </summary>
        RFD_REQ_FUEL_PRODUCT = 660,	  
        /// <summary>
        /// Root - Response for Fuel Products.
        /// </summary>
        RFD_RSP_FUEL_PRODUCT = 661,	  
        /// <summary>
        /// Root - Request for Fuel Price.
        /// </summary>
        RFD_REQ_FUEL_PRICE = 662,	  
        /// <summary>
        /// Root - Response for Fuel Price.
        /// </summary>
        RFD_RSP_FUEL_PRICE = 663,	  
        /// <summary>
        /// Root - Request for ICR Device.
        /// </summary>
        RFD_REQ_ICR_DEVICE = 664,	  
        /// <summary>
        /// Root - Response for ICR Device.
        /// </summary>
        RFD_RSP_ICR_DEVICE = 665,	  
        /// <summary>
        /// Root - Request for ICR Display Msgs.
        /// </summary>
        RFD_REQ_ICR_DISPLAY_MSG = 666,	  
        /// <summary>
        /// Root - Response for ICR Display Msgs.
        /// </summary>
        RFD_RSP_ICR_DISPLAY_MSG = 667,	  
        /// <summary>
        /// Root - Request for ICR Receipt Msg.
        /// </summary>
        RFD_REQ_ICR_RCPT_MSG = 668,	  
        /// <summary>
        /// Root - Response for ICR Receipt Msgs.
        /// </summary>
        RFD_RSP_ICR_RCPT_MSG = 669,	  
        /// <summary>
        /// Root - Request for ICR Params.
        /// </summary>
        RFD_REQ_PUMP_ICR_PARAMS = 670,	  
        /// <summary>
        /// Root - Response for ICR Params.
        /// </summary>
        RFD_RSP_PUMP_ICR_PARAMS = 671,	  
        /// <summary>
        /// Root - Request for Device Controller.
        /// </summary>
        RFD_REQ_DEV_CONTROLLER = 672,	  
        /// <summary>
        /// Root - Response for Device Controller.
        /// </summary>
        RFD_RSP_DEV_CONTROLLER = 673,	  
        /// <summary>
        /// Controller Number.
        /// </summary>
        FD_CTLRNUM = 674,	  
        /// <summary>
        /// .
        /// </summary>
        RFD_REQ_CAPTURE_SALE = 675,
        /// <summary>
        /// .
        /// </summary>
        RFD_RSP_CAPTURE_SALE = 676,
        /// <summary>
        /// .
        /// </summary>
        RFD_REQ_DAY_OPEN = 677,
        /// <summary>
        /// .
        /// </summary>
        RFD_RSP_DAY_OPEN = 678,
        /// <summary>
        /// .
        /// </summary>
        RFD_REQ_DAY_CLOSE = 679,
        /// <summary>
        /// .
        /// </summary>
        RFD_RSP_DAY_CLOSE = 680,
        /// <summary>
        /// .
        /// </summary>
        RFD_REQ_PPU_STAT_CHANGE = 681,
        /// <summary>
        /// .
        /// </summary>
        RFD_RSP_PPU_STAT_CHANGE = 682,
        /// <summary>
        /// .
        /// </summary>
        RFD_REQ_MAN_FUEL_PRICE = 683,
        /// <summary>
        /// .
        /// </summary>
        RFD_RSP_MAN_FUEL_PRICE = 684, 
        /// <summary>
        /// .
        /// </summary>
        RFD_RSP_FAIL = 685,
        /// <summary>
        /// Electronic Signature Capture.
        /// </summary>
        FD_SIGNATURE = 686,   
        /// <summary>
        /// Network company id.
        /// </summary>
        FD_NIDCOMPANYID = 687,   
        /// <summary>
        /// Sales amount that was taxed.
        /// </summary>
        FD_TAXABLEAMT = 688, 	  
        /// <summary>
        /// Stored Value Load Flags (sales).
        /// </summary>
        FD_SVLOADFLGS = 689,  
        /// <summary>
        /// Pin Pad Card Holders Agreement.
        /// </summary>
        FD_PINPADCRDHLDAGRM1 = 690,   
        /// <summary>
        /// Pin Pad Card Holders Agreement.
        /// </summary>
        FD_PINPADCRDHLDAGRM2 = 691,
        /// <summary>
        /// Pin Pad Card Holders Agreement.
        /// </summary>
        FD_PINPADCRDHLDAGRM3 = 692,
        /// <summary>
        /// Pin Pad Card Holders Agreement.
        /// </summary>
        FD_PINPADCRDHLDAGRM4 = 693,
        /// <summary>
        /// Pin Pad Card Holders Agreement.
        /// </summary>
        FD_PINPADCRDHLDAGRM5 = 694,
        /// <summary>
        /// Pin Pad Card Holders Agreement.
        /// </summary>
        FD_PINPADCRDHLDAGRM6 = 695,
        /// <summary>
        /// Host Item Id for Sale(MIF).
        /// </summary>
        FD_HOSTITEMIDSALE = 696,   
        /// <summary>
        /// Host Item Id for Fee (MIF).
        /// </summary>
        FD_HOSTITEMIDFEE = 697,   
        /// <summary>
        /// Start position of accnt # in trackII data.
        /// </summary>
        FD_ACCTNUMPOS = 698,   
        /// <summary>
        /// Length of accnt # in trackII data.
        /// </summary>
        FD_ACCTNUMLEN = 699,    
        /// <summary>
        /// Start position of expiration date in trackII data.
        /// </summary>
        FD_EXPDATEPOS = 700,   
        /// <summary>
        /// Length of expiration date in trackII data.
        /// </summary>
        FD_EXPDATELEN = 701,    
        /// <summary>
        /// ID NW needs to return to Ingenico in an ACK message.
        /// </summary>
        FD_ACKID = 702,    
        /// <summary>
        /// Stored Value Card Qty limit per transaction.
        /// </summary>
        FD_SVQTYHALO = 703,    
        /// <summary>
        /// Stored Value Card Dollar amount limit per transaction.
        /// </summary>
        FD_SVHALO = 704,    
        /// <summary>
        /// Signature Transaction Sequence number.
        /// </summary>
        FD_SIGTRANSEQ = 705,    
        /// <summary>
        /// Signature Transaction Device Type.
        /// </summary>
        FD_SIGDEVTYPE = 706,               
        /// <summary>
        /// Signature Transaction Device #.
        /// </summary>
        FD_SIGDEVNUM = 707,                  
        /// <summary>
        /// Signature Transaction Timestamp.
        /// </summary>
        FD_SIGTIMESTAMP = 708,                  
        /// <summary>
        /// Pin Prompt is required.
        /// </summary>
        FD_PINPROMPT = 709,                  
        /// <summary>
        /// Credit Total.
        /// </summary>
        FD_CREDITTOTAL = 710,                
        /// <summary>
        /// Cash Back Amount at Trans Hdr level (POS<->NW).
        /// </summary>
        FD_CASHBACKAMOUNT = 711,  	 
        /// <summary>
        /// Stored Value Card Fee Type, 2 char TL,SE,etc....
        /// </summary>
        FD_FEETYPE = 712,  	 
        /// <summary>
        /// SVC: Tender With Load (POS<->NW).
        /// </summary>
        FD_TENDERWITHLOADFLG = 713,	 	 
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE1 = 714,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE2 = 715,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE3 = 716,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE4 = 717,   
        /// <summary>
        /// Check Return Endorsement .
        /// </summary>
        FD_CHECKRTNENDORSE5 = 718,  
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE6	= 719,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE7 = 720,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE8 = 721,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE9 = 722,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE10 = 723,   
        /// <summary>
        /// Check Return Endorsement.
        /// </summary>
        FD_CHECKRTNENDORSE11 = 724,   
        /// <summary>
        /// 3rd Party Network Version.
        /// </summary>
        FD_PARAMVERSION	= 725,   
        /// <summary>
        /// Cost Amount.
        /// </summary>
        FD_COSTAMT = 726,  				
        /// <summary>
        /// Invoice Number.
        /// </summary>
	    FD_INVOICENUM = 727,  			
        /// <summary>
        /// Card Balance as a string.
        /// </summary>
	    FD_BALANCE = 728,	  
        /// <summary>
        /// Vendor name.
        /// </summary>
	    FD_VENDORNAME = 729,	 				
        /// <summary>
        /// used by NW POS and ICR to keep track of transaction state.
        /// </summary>
        FD_NWSTATE = 730,	  
        /// <summary>
        /// used by NW for BinMgt - eg MC AX.
        /// </summary>
	    FD_CARDABBR = 731,	  
        /// <summary>
        /// used by NW for BinMgt - used for fleet cards that have FD_ACCTNUM without ISO prefix.
        /// </summary>
	    FD_FULLACCTNUM = 732,	  
        /// <summary>
        /// used by NW for BinMgt - track parse result.
        /// </summary>
	    FD_TRKPRSRES = 733,	  
        /// <summary>
        /// used by NW for BinMgt.
        /// </summary>
	    FD_TRKIND = 734,	  
        /// <summary>
        /// used by NW for BinMgt - Client Identifier from track.
        /// </summary>
	    FD_TRKCLIENTID = 735,	  
        /// <summary>
        /// used by NW for BinMgt - Prompt Code from track.
        /// </summary>
        FD_TRKPROMPTCODE = 736,
        /// <summary>
        /// used by NW for BinMgt - Product Restriction Code from track.
        /// </summary>	    			 	  
	    FD_TRKPRODRESTCODE = 737,	  
        /// <summary>
        /// used by NW for BinMgt - Service Code from track.
        /// </summary>
	    FD_TRKSERVICECODE = 738,	  
        /// <summary>
        /// used by NW for Checks.
        /// </summary>
        FD_CKSEQ = 739,	  
        /// <summary>
        /// used by NW for Host Timing.
        /// </summary>
        FD_HOST_SENT = 740,	  
        /// <summary>
        /// used by NW for Host Timing.
        /// </summary>
	    FD_HOST_RECEIVED = 741,	  
        /// <summary>
        /// used by NW for indicating offline or host id that processed this trans.
        /// </summary>
	    FD_HOST_IND = 742,	  
        /// <summary>
        /// used by NW for indicating Ingenico offline file usage.
        /// </summary>
        FD_OFFLINE_FILE_PERC = 743,	  
        /// <summary>
        /// used by NW for determining POS version.
        /// </summary>
        FD_POSINTERFACE = 744,	  
        /// <summary>
        /// used by NW / POS to indicate stored value card status.
        /// </summary>
        FD_SVCARDSTATUS = 745,	  
        /// <summary>
        /// used by NW for CVV2 Prompting.
        /// </summary>
        FD_SECURITY_CODE = 746,	  
        /// <summary>
        /// used by POS to check if a reboot is required.
        /// </summary>
        FD_POSVERSION = 747,	  
        /// <summary>
        /// used by POS to check if a reboot is required.
        /// </summary>
        FD_POSREBOOTTIMEOUT = 748,	  
        /// <summary>
        /// collect outstanding postpays with EOD meterreadings.
        /// </summary>
        FD_WAITPAYVOL = 749,	  
        /// <summary>
        /// Special Network flag indicating a rollback from the RB utility.
        /// </summary>
        FD_ROLLBACKSTATE = 750,	  
        /// <summary>
        /// Network Fleet: key code from track.
        /// </summary>
        FD_TRKKEYCODE = 751,	  
        /// <summary>
        /// Network Fleet: vehicle number from track.
        /// </summary>
        FD_TRKVEHICLE = 752,	  
        /// <summary>
        /// Network Fleet: Fleet Cust Ref No.
        /// </summary>
        FD_FLEETCUSTREF = 753,   
        /// <summary>
        /// Prepaid Phone Card: Product code from track.
        /// </summary>
        FD_TRKPRODCODE = 754,	  
        /// <summary>
        /// Prepaid Phone Card: Card status for balance inquiry.
        /// </summary>
	    FD_CARDSTATUS = 755,	  
        /// <summary>
        /// Prepaid Phone Card: Vendor ID for loads.
        /// </summary>
        FD_VENDORID = 756,	  
        /// <summary>
        /// Coupon Tax Method	M1.
        /// </summary>
        FD_CPTAXMETHOD = 757,							
        /// <summary>
        /// Coupon Sequence Number  M1.
        /// </summary>
	    FD_COUPONSEQ = 758, 				
        /// <summary>
        /// Coupon ID  M1.
        /// </summary>
	    FD_COUPONID	= 759,									
        /// <summary>
        /// Coupon Type  M1.
        /// </summary>
	    FD_COUPONTYPE = 760,									
        /// <summary>
        /// Coupon Flags  M1.
        /// </summary>
	    FD_COUPONFLGS = 761,								
        /// <summary>
        /// Value Code	M1.
        /// </summary>
	    FD_VALUECODE = 762,									
        /// <summary>
        /// Entry Method (Tokenized  M1).
        /// </summary>
	    FD_ENTRYMETHOD = 763,					
        /// <summary>
        /// Concatenated Promo Data for Scan  M2.
        /// </summary>
        FD_MIXMATCHDATA = 764,		    
        /// <summary>
        /// ISO Code Data - Initial use for Safe ISO Currency Code  M3.
        /// </summary>
        FD_ISOCODE = 765,	
        /// <summary>
        /// Various Safe Configuraiton Flags  M3.
        /// </summary>
        FD_SAFEFLGS = 766,
        /// <summary>
        /// Amount from the Safe  M3.
        /// </summary>
        FD_SAFEAMOUNT = 767,
        /// <summary>
        /// Envelope ID for Safe Drops  M3.
        /// </summary>
        FD_ENVELOPEID = 768,	
        /// <summary>
        /// Communication Status for the Safe  M3.
        /// </summary>
        FD_COMSTAT = 769,
        /// <summary>
        /// Small Ticket Acceptance Threshold - RF  M4.
        /// </summary>
        FD_STA_THRESHOLD = 770,	
        /// <summary>
        /// New Shift # for next Shift M3.
        /// </summary>
        FD_NEWSHIFTNUM = 771,
        /// <summary>
        /// New Day # for next Day M3.
        /// </summary>
        FD_NEWDAYNUM = 772,
        /// <summary>
        /// Employee Language for Safe  M3.
        /// </summary>
        FD_LANGUAGE = 773,
        /// <summary>
        /// Safe Security Level M3.
        /// </summary>
        FD_SAFESECLEVEL = 774,
        /// <summary>
        /// Task Name for MgrComUtil M3.
        /// </summary>
        FD_TASKNAME = 775,
        /// <summary>
        /// Small Ticket Acceptance Bypass indicator - RF M4.
        /// </summary>
        FD_STA_BYPASSED = 776,
        /// <summary>
        /// Bit Map for Voided/ErrorCorrected Coupons.
        /// </summary>
        FD_COUPONSEQVOID = 777,
        /// <summary>
        /// Commission Type for the Card Fees, from CPM - M5.
        /// </summary>
        FD_COMMISSIONTYPE = 778,
        /// <summary>
        /// SEI defined Card Vendor Id, from CPM - M5.
        /// </summary>
        FD_CARDVENDORID = 779,
        /// <summary>
        /// Masked account number in format number 2 as defined in CPM - M6.
        /// </summary> 
        FD_FILEMASKACCT = 780,
        /// <summary>
        /// Number multiple credit media in transaction (1, 2, etc.) - M8
        /// </summary> 
        FD_SPLITSEQ	= 781,
        /// <summary>
        /// Pinpad Cardholder's Agreement for multiple cards M8
        /// </summary>
        FD_PINPADMULTCRDHLDAGRM1 = 782,
        /// <summary>
        /// Pinpad Cardholder's Agreement for multiple cards M8
        /// </summary>
        FD_PINPADMULTCRDHLDAGRM2 = 783,
        /// <summary>
        /// Pinpad Cardholder's Agreement for multiple cards M8
        /// </summary>
        FD_PINPADMULTCRDHLDAGRM3 = 784, 
        /// <summary>
        /// Pinpad Cardholder's Agreement for multiple cards M8
        /// </summary>
        FD_PINPADMULTCRDHLDAGRM4 = 785,
        /// <summary>
        /// Pinpad Cardholder's Agreement for multiple cards M8
        /// </summary>
        FD_PINPADMULTCRDHLDAGRM5 = 786,
        /// <summary>
        /// Pinpad Cardholder's Agreement for multiple cards M8
        /// </summary>
        FD_PINPADMULTCRDHLDAGRM6 = 787,
        /// <summary>
        /// M9 Partial approval cancellation indicator
        /// </summary>
        FD_PARTIALAUTHCANCEL = 788,
        /// <summary>
        /// MTF Partial auth status
        /// </summary>
        FD_PARTIALAUTHSTATUS = 789,
        /// <summary>
        /// MTF delay for displaying transaction info on pinpad
        /// </summary>
        FD_PINPADFINALDELAY	= 790,
        /// <summary>
        /// M10 MTF Added for TDES
        /// </summary>
        FD_PINPAD_ENCRYPT_TYPE = 791,
        /// <summary>
        /// M11 MTF Added for Fraud 4A 
        /// </summary>
        FD_IDCHECKOK = 792,
        /// <summary>
        /// M11 MTF Added for Fraud 4A
        /// </summary>
        FD_LASTFOURDIGITS = 793,
        /// <summary>
        /// Federal Tax Label for receipts in Canada HST - M13
        /// </summary>
        FD_FEDTAXLABEL = 794,
        /// <summary>
        /// Fuel Tax Table for receipts in Canada HST - M13
        /// </summary>
        FD_FUELTAXTABLE	= 795,
        /// <summary>
        /// M14	AgeVer Type of encoding from drv lic
        /// </summary>
        FD_ENCODING = 796,
        /// <summary>
        /// M14	AgeVer Version from drv lic 
        /// </summary>
        FD_VERSION = 797,
        /// <summary>
        /// M14	AgeVer Element Id from drv lic  
        /// </summary>
        FD_ELEMENTID = 798,
        /// <summary>
        /// M14	AgeVer IIN Code from drv lic
        /// </summary>
        FD_IINCODE = 799,
        /// <summary>
        /// Car wash flags - M15
        /// </summary>
        FD_CWFLAG = 800,
        /// <summary>
        /// Car wash discount type (PPU, price based on gallons pumped, manual, etc) - M15
        /// </summary>
        FD_DSCTYPE = 801,
        /// <summary>
        /// Car wash manual discount reason code - M15
        /// </summary>
        FD_CWREASON = 802,
        /// <summary>
        /// Generic Prompt echo character (for masked input) - M15
        /// </summary>
        FD_ECHOCHAR = 803,
        /// <summary>
        /// Generic Prompt encrypt flag - M15
        /// </summary>
        FD_ENCRYPT = 804,
        /// <summary>
        /// Generic Prompt error message - M15
        /// </summary>
        FD_ERRORMSG = 805,
        /// <summary>
        /// Generic Prompt help message - M15
        /// </summary>
        FD_HELPMSG = 806,
        /// <summary>
        /// Generic Prompt restricted characters - M15
        /// </summary>
        FD_RESTVAL = 807,
        /// <summary>
        /// Generic Prompt minimum number of characters/digits - M15
        /// </summary>
        FD_MINLEN = 808,
        /// <summary>
        /// Generic Prompt maximum number of characters/digits - M15
        /// </summary>
        FD_MAXLEN = 809,
        /// <summary>
        /// Generic Prompt source; touchsreen, pinpad, or both - M15
        /// </summary>
        FD_SOURCE = 810,
        /// <summary>
        /// Generic Prompt default value - M15
        /// </summary>
        FD_VALUE = 811,
        /// <summary>
        /// Number of vouchers to print (sent by PEPS) - M15
        /// </summary>
        FD_NUMVOUCHERS = 812,
        /// <summary>
        /// Host batch number used by new credit media - M15	
        /// </summary>
        FD_HOSTBATCHNUM = 813,
        /// <summary>
        /// Host invoice number used by new credit media - M15	
        /// </summary>
        FD_HOSTINVNUM = 814,
        /// <summary>
        /// Retailer ID used by new credit media - M15	
        /// </summary>
        FD_RETAILERID = 815,
        /// <summary>
        /// Fuel Carwash Adjust Amount (used similar to FD_MEDIADISC) - M15 
        /// </summary>
        FD_CWDISC = 816,
        /// <summary>
        /// for the command CMD_SCAN_GET_BCP_ICRS - M15
        /// </summary>
        FD_PUMPSCONTROLLED = 817,
        /// <summary>
        /// Receipt Printer on ICR? - M15
        /// </summary>
        FD_RECEIPTPRINTER = 818,
        /// <summary>
        /// Keyboard layout string on ICR - M15
        /// </summary>
        FD_KEYBDLAYOUT_STR = 819,
        /// <summary>
        /// Carwash prompt mode - M15
        /// </summary>
        FD_CWPROMPTMODE = 820,
        /// <summary>
        /// Carwash packages per screen on ICR - M15
        /// </summary>
        FD_CWPKGPERSCREEN = 821,
        /// <summary>
        /// Short ICR carwash prompt timeout - M15 
        /// </summary>
        FD_CWPROMPT_TIMEOUT_SHORT = 822,
        /// <summary>
        /// Long ICR carwash prompt timeout - M15
        /// </summary>
        FD_CWPROMPT_TIMEOUT_LONG = 823,
        /// <summary>
        /// Added to store profile - M15
        /// </summary>
        FD_COMPANYID = 824,
        /// <summary>
        /// Real estate Type - M15
        /// </summary>
        FD_REALESTATE = 825,
        /// <summary>
        /// Primary Card processor - M15
        /// </summary>
        FD_CARDPROCESSOR = 826, 
        /// <summary>
        /// Price Sign status - M15
        /// </summary>
        FD_PRICESIGN_STATUS = 827, 
        /// <summary>
        /// Fuel - Tank Number from SCAN
        /// </summary>
        FD_TANKNUM = 828,
        /// <summary>
        /// Fuel - Primary Tank Indicator
        /// </summary>
        FD_PRIMARYTANKIND = 829,
        /// <summary>
        /// Food type for plu item scan
        /// </summary>
        FD_MEALTAXTYPE = 830,
        /// <summary>
        /// Fixed amount
        /// </summary>
        FD_FIXEDAMT = 831,
        /// <summary>
        /// Min amount
        /// </summary>
        FD_MIN = 832,
        /// <summary>
        /// Max amount
        /// </summary>
        FD_MAX = 833,
	    /// <summary>
	    /// EDHDI - Prepay Completion status
        /// </summary>
        FD_TRANSCOMPLETE = 834,
	    /// <summary>
	    /// EDHDI - Carwash Promo Reason Code
        /// </summary>
        FD_CWREASONCODE = 835,
	    /// <summary>
	    /// EDHDI - EDHInstalled for Storeprofile
        /// </summary>
        FD_EDHINSTALLED = 836,
	    /// <summary>
	    /// EDHDI - Type for FCN_STATUS Configuration Info
        /// </summary>
        FD_TYPE = 837,	
	    /// <summary>
	    /// EDHDI - Status for FCN_STATUS Configuration Info
        /// </summary>
        FD_STATUSINFO = 838,
	    /// <summary>
	    /// EDHDI - 
        /// </summary>
        FD_CWCONTROL = 839,
        /// <summary>
        /// AISP1 - 
        /// </summary>
        FD_OVERRIDE_TAX = 840,
        /// <summary>
        /// AISP1 - 
        /// </summary>
        FD_ISTAXABLE    = 841,
        /// <summary>
        /// AISP1 - 
        /// </summary>
        FD_EXCISETAX_AMT = 842,
        /// <summary>
        /// AISP1 - 
        /// </summary>
        FD_PARENT_LINKED_ITEMID = 843,
        /// <summary>
        /// AISP1 - 
        /// </summary>
        FD_PRIMARY_LINKED_ITEMID = 844,
        /// <summary>
        /// AISP1 - 
        /// </summary>
		FD_MEALCODE = 845,
	
        /// FNS Code - EBT
        /// </summary>
		FD_FNSCODE = 846,
	    /// <summary>
        /// FNS Flag
        /// </summary>
		FD_FNSFLAG = 847,
        /// <summary>
        /// Cash back for CB Cards - EBT
        /// </summary>
		FD_EBT_CB_HALO = 848,
	    /// <summary>
       /// <summary>
        /// PSP ID.
        /// </summary>
        FD_PSPID = 849,
        /// <summary>
        /// AISP1 for 4 digit tax rate
        /// </summary>
        FD_TAXRATE_4 = 850,
		/// <summary>
        /// AISP1 for 4 digit Amount
        /// </summary>
        FD_AMOUNT_2 = 851,
		/// <summary>
        /// EDH Authnum for receipt print
        /// </summary>
        FD_RCPT_AUTHNUM = 852,
		/// <summary>
        /// DGE message sequence number
        /// </summary>
        FD_DGESEQ = 853,
		/// <summary>
        /// DGE message type
        /// </summary>
        FD_RTS_MSGTYPE = 854,
 		/// <summary>
        /// DGE service type
        /// </summary>
        FD_RTS_SVCTYPE = 855,
		/// <summary>
        /// DGE version
        /// </summary>
        FD_RTS_VERSION = 856,
		/// <summary>
        /// DGE Flag (bitfield)
        /// </summary>
        FD_DGEFLAG = 857,
		/// <summary>
        /// DGE Alt ID (phone number)
        /// </summary>
        FD_DGE_ALTID = 858,
		/// <summary>
        /// DGE return code
        /// </summary>
        FD_RTS_RC = 859,
		/// <summary>
        /// DGE Member ID
        /// </summary>
        FD_MEMBERID = 860,
		/// <summary>
        /// Coupon Description; used when repriting fuel prepays with coupon
        /// </summary>
        FD_COUPONDESC = 861,
        /// <summary>
        /// 7Rewards2.0 Rewards list
        /// </summary>
        FD_7REWARDSLIST = 862,
        /// <summary>
        /// 7Rewards2.0 DGE Seq date and time created
        /// </summary>
        FD_DGETRANDATETIME = 863,
        /// <summary>
        /// EDH PINPad Package Version
        /// </summary>
        FD_EDHVERSION = 864,

        /// <summary>
        /// GT Issuance authorization data EMV TAG.
        /// </summary>
        FD_IAD = 865,
        /// <summary>
        /// GT Terminal verification Results EMV TAG.
        /// </summary>
        FD_TVR = 866,

        /*
         * Open range for reuse - FID removed.
         */

        /// <summary>
        /// DGE message time delay (milliseconds)
        /// </summary>
        FD_TIMEDELAY = 869,
        /// <summary>
        /// DGE message sequence
        /// </summary>
        FD_DGETRANSEQ = 870,
 	    /// <summary>
        /// DGE Post Market flag Fid
        /// </summary>
        FD_DGEPOSTFLAG = 871,
    	/// <summary>
        /// WUMOM SA First Name
        /// </summary>
        FD_FIRSTNAME = 872,
    	/// <summary>
        /// WUMOM SA Last Name
        /// </summary>
        FD_LASTNAME = 873,       
        /// M36 AC: 07/19/2013: RCLT: New Fids for RISE-CLT
        /// <summary>
        /// Taxable MIF for Load
        /// </summary>
        FD_HOSTITEMIDSALETAX = 874,
        /// <summary>
        /// Taxable MIF for Load Fee
        /// </summary>
        FD_HOSTITEMIDFEETAX	= 875,
		/// <summary>
        /// Encryption flag from PINpad
        /// </summary>
        FD_P2PENCRYPTED = 876,
        /// <summary>
        /// ETB data from PINpad when encrypted
        /// </summary>
        FD_ETB = 877,
        /// <summary>
        /// Foodstampable amount in EDH request
        /// </summary>
        FD_EBTSNAPAMT = 878,
		/// <summary>
        /// Cash Benefit eligible amount in EDH request
        /// </summary>
        FD_EBTCBAMT = 879,
        /// <summary>
        /// P2P timing metric message type
        /// </summary>
        FD_TXN_MSGTYPE = 880,
        /// <summary>
        /// Restricted Media amount
        /// </summary>
        FD_MEDIAELIGIBLEAMT = 881,
        /// <summary>
        /// Restricted media bitfield sent to CMS
        /// </summary>
        FD_RESTRECTEDMEDIA = 882,
        /// <summary>
        /// Flag from CMS indicating partial auth is due to restricted media
        /// </summary>
        FD_REST_PARTIAL_AUTH = 883,
        /// <summary>
        ///  EMV tag
        /// </summary>
        FD_TAG = 884,
        /// <summary>
        /// EMV data
        /// </summary>
        FD_DATA = 885,
        /// <summary>
        /// Application Identifier (Hex ASCII) (Tag: 9F06 = Application ID Terminal) (Tag: 4F = Application Identifier on card)
        /// </summary>
        FD_AID = 886,
        /// <summary>
        /// Cryptogram Information Data	(Tag: 9F27 Hex ASCII)
        /// </summary>
        FD_CRYPTOGRAM = 887,
        /// <summary>
        /// Application Preferred Name	(Tag: 9F12 ASCII)
        /// </summary>
        FD_APP_PREF_NAME = 888,
        /// <summary>
        /// Name
        /// </summary>
        FD_NAME = 889,
        /// <summary>
        /// EMV block error
        /// </summary>
        FD_EMVFLBKERROR = 890,
        /// <summary>
        /// EMV Pin bypass flag = True or False
        /// </summary>
        FD_PINBYPASS = 891,
        /// <summary>
        /// EMV beep start delay
        /// </summary>
        FD_BEEPSTARTDELAY = 892,
        /// <summary>
        /// EMV Do a real VOID [NOT REFUND] from TM to eCS
        /// </summary>
        FD_EMVVOID = 893,
        /// <summary>
        /// Signature line status
        /// </summary>
        FD_SIGNATURELINESTATUS = 894,
        /// <summary>
        /// PIN pad entry source Supporting MSR swipe for payment
        /// </summary>
        FD_PMTENTRYSRC = 895,
        /// <summary>
        ///  Coupon offer code
        /// </summary>
        FD_COUPON_OFEERCODE = 896,
        /// <summary>
        /// Additional purchase requirement cod
        /// </summary>
        FD_ADDTNLCD = 897,
        /// <summary>
        /// Coupon save value code
        /// </summary>
        FD_COUPON_SAVEVALUECODE = 898,
        /// <summary>
        /// Coupon save value
        /// </summary>
        FD_COUPON_SAVEVALUE = 899,
        /// <summary>
        /// Coupon start date
        /// </summary>
        FD_COUPON_STARTDATE = 900,
        /// <summary>
        /// Coupon expiration date 
        /// </summary>
        FD_COUPON_EXPIRATIONDATE = 901,
        /// <summary>
        /// Coupon retailer id 
        /// </summary>
        FD_COUPON_RETAILERID = 902,
        /// <summary>
        /// Coupon serial number
        /// </summary>
        FD_COUPON_SERIALNUMBER = 903,
        /// <summary>
        /// Discounted coupon item number
        /// </summary>
        FD_COUPON_DISCOUNTITEMCODE = 904,
        /// <summary>
        /// Store coupon code
        /// </summary>
        FD_STORE_COUPONCODE = 905,
        /// <summary>
        /// Don't multiply flag
        /// </summary>
        FD_COUPON_NO_MULTIPLYFLAG = 906,
        /// <summary>
        /// Purchase requirement
        /// </summary>
        FD_PURCHASE_REQ = 907,
        /// <summary>
        /// Purchase requirement code
        /// </summary>
        FD_PURCHASE_REQCODE = 908,
        /// <summary>
        /// Purchase family code
        /// </summary>
        FD_PURCHASE_FAMILYCODE = 909,
        /// <summary>
        /// Item best before date
        /// </summary>
        FD_BESTBEFORE_DATE = 910,
        /// <summary>
        /// Item sell by date
        /// </summary>
        FD_SELLBY_DATE = 911,
        /// <summary>
        /// Item expiration date and time
        /// </summary>
        FD_EXPDATETIME = 912,
        /// <summary>
        /// Rejection reason
        /// </summary>
        FD_REJECTIONREASON = 913,
        /// <summary>
        /// Rejection flag 
        /// </summary>
        FD_REJECTIONFLG = 914,
        /// <summary>
        /// Manufacturer pays tax amount for coupon
        /// </summary>
        FD_COUPON_MANF_PAYS_TAXAMOUNT = 915,
        /// <summary>
        /// GS1 coupon databar
        /// </summary>
        FD_DATABAR = 916,
        /// <summary>
        /// GS1 item application identifier
        /// </summary>
        FD_PRODUCTAI = 917,
        /// <summary>
        /// GS1 item application identifier length
        /// </summary>
        FD_PRODUCTAI_LEN = 918,
        /// <summary>
        /// GS1 item application identifier field length
        /// </summary>
        FD_PRODUCTAI_FIELD_LEN = 919,
        /// <summary>
        /// GS1 item application identifier field length type
        /// </summary>
        FD_PRODUCTAI_FIELD_LEN_TYP = 920,
        /// <summary>
        /// GS1 item application identifier description
        /// </summary>
        FD_PRODUCTAI_FIELD_DESC = 921,
        /// <summary>
        /// Coupon type - manufacturer or store coupon
        /// </summary>
        FD_MANUFACTURER_COUPONFLG = 922,
        /// <summary>
        /// Discounted item flag
        /// </summary>
        FD_DISCOUNTEDFLG = 923,
        /// <summary>
        /// UPC Coupon flag from ESL
        /// </summary>
        FD_UPC_COUPONFLG = 924,
        /// <summary>
        /// GS1 item application identifier description
        /// </summary>
        FD_PRODUCTAI_TOBEPROCESSED = 925,
        /// <summary>
        /// GS1 Metrics
        /// </summary>
        FD_COUPONPLU = 926,
        /// <summary>
        /// GS1 Metrics
        /// </summary>
        FD_ESLSEQ = 927,
        /// <summary>
        /// GS1 Metrics
        /// </summary>
        FD_ESLTRANSEQ = 928,
        /// <summary>
        /// Value Code	M1.
        /// </summary>
        FD_COUPONVALUECODE = 929,
        /// <summary>
        /// 7RP 
        /// </summary>
        FD_CARD_VERSION = 930,
        /// <summary>
        /// 7RP Barcode Type Mobile, Plastic
        /// </summary>
        FD_BARCODE_PARM1 = 931, 
        /// <summary>
        /// 7RP Device Type Android, Apple etc.
        /// </summary>
        FD_BARCODE_PARM2 = 932,
        /// <summary>
        /// 7RP Future Use
        /// </summary>
        FD_BARCODE_PARM3 = 933,
        /// <summary>
        /// 7RP Future Use
        /// </summary>
        FD_BARCODE_PARM4 = 934,
        /// <summary>
        /// 7RP Future Use
        /// </summary>
        FD_BARCODE_PARM5 = 935,
        /// <summary>
        /// 7RP Future Use
        /// </summary>
        FD_BARCODE_PARM6 = 936,
        /// <summary>
        /// 7RP Future Use
        /// </summary>
        FD_OFFLINE_CUST_SUMMARY = 937,
        /// <summary>
        /// 7RP Future Use
        /// </summary>
        FD_OFFLINE_CUST_DETAIL = 938,
        /// <summary>
        /// 7RP 7Rewards1.5 Start Timestamp
        /// </summary>
        FD_DURATION1 = 939,
        /// <summary>
        /// 7RP End Timestamp
        /// </summary>
        FD_DURATION2 = 940,
        /// <summary>
        /// 7RP GetMember YlwMsg
        /// </summary>
        FD_BAD_GETMEMBER_YLW = 941,
        /// <summary>
        /// 7RP GetMember RedMsg
        /// </summary>
        FD_BAD_GETMEMBER_RED = 942,
        /// <summary>
        /// 7RP GetMember PinpadMsg
        /// </summary>
        FD_BAD_GETMEMBER_PINPAD = 943,
        /// <summary>
        /// 7RP RESOLVETRAN YlwMsg
        /// </summary>
        FD_BAD_RESOLVETRAN_YLW = 944,
        /// <summary>
        /// 7RP RESOLVETRAN RedMsg
        /// </summary>
        FD_BAD_RESOLVETRAN_RED = 945,
        /// <summary>
        /// 7RP RESOLVETRAN PinpadMsg
        /// </summary>
        FD_BAD_RESOLVETRAN_PINPAD = 946,
        /// <summary>
        /// 7RP RESOLVETRAN ReceiptMsg
        /// </summary>
        FD_BAD_RESOLVETRAN_RCPT = 947,
        /// <summary>
        /// 7RP AltidCustomerEntryAttempts
        /// </summary>
        FD_ALTID_ENTRYATTEMPT = 948,
        /// <summary>
        /// 7RP RestrictAltIDToPinpadOnly
        /// </summary>
        FD_ALTIDTOPINPADONLY = 949,
        /// <summary>
        /// 7RP PromptForceFinalizeAndPay
        /// </summary>
        FD_PROMPTFINALIZEPAY_FLAG = 950,
        /// <summary>
        /// 7RP PromptForceFinalizeAndPayMsg
        /// </summary>
        FD_PROMPTFINALIZEPAY_MSG = 951,
        /// <summary>
        /// 7RP ForcePrintNonMember
        /// </summary>
        FD_FORCEPRINT_NONMEMBER = 952,
        /// <summary>
        /// 7RP "Member Coupon ID
        /// </summary>
        FD_MEMBERCOUPONID = 953,
        /// <summary>
        /// 7RP VCKEY
        /// </summary>
        FD_VCKEY = 954,
        /// <summary>
        /// 7RP OfferUPC
        /// </summary>
        FD_OFFERUPC = 955,
        /// <summary>
        /// 7RP MarkDownUPC
        /// </summary>
        FD_MARKDOWNUPC = 956,
        /// <summary>
        /// 7RP DefID
        /// </summary>
        FD_DEFID = 957,
        /// <summary>
        /// 7RP MemberRewardID
        /// </summary>
        FD_MEMBERREWARDID = 958,
        /// <summary>
        /// 7RP Is MemberFlag
        /// </summary>
        FD_IS_MEMBERFLAG = 959,
        /// <summary>
        /// POS Function Type
        /// </summary>
        FD_POSFNTYPE = 960,
        /// <summary>
        /// EDH PINPad Config
        /// </summary>
        FD_EDH_POS_TERMINAL_ID = 961,
        /// <summary>
        /// EDH PINPad type
        /// </summary>
        FD_EDH_PIN_PAD_TYPE_ID = 962,
        /// <summary>
        /// EDH PINpad connection type 
        /// </summary>
        FD_EDH_PIN_PAD_CON_TYPE_ID = 963,
        /// <summary>
        /// EDH PINPad com port 
        /// </summary>
        FD_EDH_COM_PORT_NBR = 964,
        /// <summary>
        /// EDH PINPad RF capable flag 
        /// </summary>
        FD_EDH_RF_CAPABLE_FLAG = 965,
        /// <summary>
        /// EDH PINPad EMV capable flag 
        /// </summary>
        FD_EDH_EMV_CAPABLE_FLAG = 966,
        /// <summary>
        /// EDH PINPad config flags 
        /// </summary>
        FD_EDH_PINPAD_CFGFLAGS = 967,
        /// <summary>
        /// ASIP2 
        /// </summary>
        FD_SUB_MENU_FLG = 968,
        /// <summary>
        ///PPHTH project � Prepaid card barcode scan data 
        /// </summary>
        FD_HOT_BRAND_KEYSEQ = 969,
        /// <summary>
        ///PPHTH project � Prepaid card discount data  
        /// </summary>
        FD_DISCTYP = 970,
        /// <summary>
        ///PPHTH project � Prepaid card discount data   
        /// </summary>
        FD_MEDIAMIF = 971,
        /// <summary>
        ///PPHTH project � Prepaid card amount prompt data
        /// </summary>
        FD_MULTIDENOM = 972,
        /// <summary>
        ///PPHTH project � Prepaid card UPC data 
        /// </summary>
        FD_UPC = 973,
        /// <summary>
        /// PPHTH project � Prepaid card Brand data
        /// </summary>
        FD_CARDBRAND = 974,
        /// <summary>
        /// PPHTH project � Prepaid card Customer ID masking char data 
        /// </summary>
        FD_MASKCHAR = 975,
        /// <summary>
        /// PPHTH project � Prepaid card Customer ID length data
        /// </summary>
        FD_CUSTIDLEN = 976,
        /// <summary>
        /// PPHTH project � Prepaid card Customer ID masking position data 
        /// </summary>
        FD_MASKPOS = 977,
        /// <summary>
        /// PPHTH project � Prepaid card category data 
        /// </summary>
        FD_CARDCATEGORY = 978,
        /// <summary>
        /// EDH Change display
        /// </summary>
        FD_CHANGE = 979,
        /// <summary>
        /// PPHTH - Added for Prepaid Phase III
        /// </summary>
        FD_SHELFTAG = 980,
        FD_MULTIPLERFLG = 981,
        /// <summary>
        /// 7Rewards new long (__int64) FID for couponId
        /// </summary>
        FD_SRPCOUPONID = 982,
        /// <summary>
        /// PPHTH project: RTR Custormer ID or POR PIN in Void transactions
        /// </summary>
        FD_CUSTOMERID = 983
    }
}
