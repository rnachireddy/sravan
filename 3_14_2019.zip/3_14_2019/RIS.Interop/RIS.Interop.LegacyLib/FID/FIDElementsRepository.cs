using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Xml;

namespace RIS.Interop.Messages
{
    /// <summary>
    /// Base class that holds the logic of holding FID elements and
    /// super FID elements in a repository.
    /// </summary>
    public abstract class FIDElementsRepository : IDisposable
    {
        #region Fields
        /// <summary>
        /// Repositiry for FID and super FID elements.
        /// </summary>
        protected ArrayList m_FIDElements = new ArrayList();
        /// <summary>
        /// The class was disposed or not.
        /// </summary>
        protected bool m_Disposed = false;
        #endregion

        #region Properties
        /// <summary>
        /// Returnes Array of objects that contains the childrens of the
        /// element. The elements in the array could be SuperFIDElement
        /// and FIDElement. The user will have to use TGetType () to get 
        /// the type of the element in the array.
        /// </summary>
        public object[] Children
        {
            get
            {
                return ((object[])m_FIDElements.ToArray(typeof(object)));
            }
            set
            {
                //clear the existing list and add the new list of fidelements.This new fid elements wil have the old and the new fid elements added
                // to it
                m_FIDElements.Clear();
                m_FIDElements.AddRange(value);
            }

        }
        #endregion

        #region constructors
        /// <summary>
        /// Constructor that get an array of bytes and convert them to FID and super FID elements.
        /// </summary>
        /// <remarks>
        /// If IsSuperFID is true than FIDHeader will be loaded and the process will start at Message[FIDHeader.HeaderLen].
        /// The function will run in a loop and will call to GetNextElement() that will return the next FID \ SuperFID element.
        /// The new element will be added to m_FIDElements by the function AddChild().
        /// The function will check if the Message is corrupted. See FidMsgCheck() for more details.
        /// </remarks>
        /// <param name="Message">Array of bytes that contains the FID element \ message.</param>
        /// <param name="IsSuperFID">In case of Super FID it will be true, so the loading of the elelemts will be without the Super FID header.</param>
        public FIDElementsRepository(byte[] Message, bool IsSuperFID)
        {
            int Offset = 0;
            FIDHeader Header;
            object Element;

            try
            {
                if (Message == null)
                {
                    throw new ArgumentNullException("Message", "constructor of FIDElementsRepository failed because Message parameter is null");
                }

                //if it is a super FID element than we need to parse It's childrens. They exists after the header,
                //so we need to start the buffer processing after the header.
                if (IsSuperFID == true)
                {
                    //load header because we need to know its len.
                    Header = new FIDHeader(Message);
                    Offset = Header.HeaderLen;

                    //check if the buffer is corrupted.
                    if (Header.ElementLen < Message.Length)
                    {
                        string LogMessage;
                        LogMessage = string.Format("constructor of FIDElementsRepository failed because buffer is smaller than expected. Header.ElementLen [{0}] Message.Length [{1}]", Header.ElementLen.ToString(), Message.Length.ToString());
                        throw new FIDElementCorruptedException(LogMessage);
                    }
                }
                else
                {
                    Offset = 0;
                }

                //run in allop and get all the elements from the buffer.
                while ((Element = (GetNextElement(Message, ref Offset))) != null)
                {
                    AddChild(Element);
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }
        
        /// <summary>
        /// Empty constructor.
        /// </summary>
        protected FIDElementsRepository()
        {
        }

        #endregion

        #region Non public function
        /// <summary>
        /// Create from the bytes array the next FID or SuperFID element.
        /// </summary>
        /// <remarks>The function will read the first three bytes and will create a new FIDHeader element. 
        /// Than it will get from FIDHeader the element length and will read it from the buffer. 
        /// If the element is super FID than the function will allocated a new SuperFIDElement. 
        /// Else it will allocate FIDElement.</remarks>
        /// <param name="Bytes">Array of bytes that contains the FID element \ message.</param>
        /// <param name="Offset">offset of the element in the buffer.</param>
        /// <returns>Will be the next element (SuperFIDElement or FIDElement).</returns>
        protected object GetNextElement(Byte[] Bytes, ref int Offset)
        {
            byte[] CurrentBuffer;
            Object Element;
            FIDHeader Header;

            try
            {
                //we are at the end of the buffer, return null.
                if (Bytes.Length <= Offset)
                {
                    return null;
                }

                //Get the first 3 bytes to read the header.
                CurrentBuffer = new byte[3];

                //get the header stream from the buffer and build from it a FIDHeader. If the buffer is corrupted
                //than FIDHeader will throw exception.
                Array.Copy(Bytes, Offset, CurrentBuffer, 0, CurrentBuffer.Length);
                Header = new FIDHeader(CurrentBuffer);

                //after we got the size of the element, we can get it from the array to CurrentBuffer.
                CurrentBuffer = new byte[Header.ElementLen];
                Array.Copy(Bytes, Offset, CurrentBuffer, 0, CurrentBuffer.Length);

                //if the buffer is corrupted than exception will be thrown at SuperFIDElement or FIDElement.
                //Allocates super FID.
                if (Header.IsSuperFID == true)
                {
                    Element = ((object)(new SuperFIDElement(CurrentBuffer)));
                }
                //Allocates FID.
                else
                {
                    Element = ((object)(new FIDElement(CurrentBuffer)));
                }

                //increase Offset to point to the next message.
                Offset += Header.ElementLen;

                return (Element);
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Converts the child element to XmlElement.
        /// </summary>
        /// <remarks>The function will run on m_FIDElements and for each one it will call ToXml() 
        /// and will add the return XmlElement to XmlFather.
        /// </remarks>
        /// <param name="XmlDoc">Will be used by the children to create an Xml Element.</param>
        /// <param name="XmlFather">� father�s Xml Element. The new elements will be added to the father.</param>
        protected void ChildrenToXml(XmlDocument XmlDoc, XmlElement XmlFather)
        {
            int Count;
            XmlElement Element;

            try
            {
                //loop that runs on children and convert them to XML.
                for (Count = 0; Count < m_FIDElements.Count; Count++)
                {
                    //Get child as XML.
                    Element = (((IFIDElement)m_FIDElements[Count]).ToXml(XmlDoc));
                    //Add the child to the father.
                    XmlFather.AppendChild(Element);
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// The function will run on m_FIDElements and will add to the new ArrayList the elements that 
        /// match the critaria (FID ID and IsSuperFID()). ArrayList will be returned.
        /// </summary>
        /// <param name="IsSuperFID">if true than the returned elements will be SuperFID elements, 
        /// else they will be FID elements.</param>
        /// <param name="FIDID">the needed FID ID.
        /// </param>
        /// <returns>ArrayList that contains the founded elements.</returns>
        protected ArrayList GetElements(bool IsSuperFID, FIDInfo FIDID)
        {
            int Count;
            ArrayList Elements;

            try
            {
                Elements = new ArrayList();

                //loop that runs on children and check if they match the needed critaria.
                for (Count = 0; Count < m_FIDElements.Count; Count++)
                {
                    //if the element match the critaria than add it to Elements.
                    if ((((IFIDElement)m_FIDElements[Count]).FIDID) == FIDID)
                    {
                        if ((((IFIDElement)m_FIDElements[Count]).IsSuperFID) == IsSuperFID)
                        {
                            Elements.Add(m_FIDElements[Count]);
                        }
                    }
                }
                
                return (Elements);
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Returnes the childrens converted to bytes.
        /// </summary>
        /// <remarks>
        /// The function will allocate an ArrayList. It will run in a loop on m_FIDElements and will cast 
        /// each element to IFIDElement and will call to ToBytes[]. 
        /// It will add the resauls to ListArray and will call to ListArray.Copy() to return the resaults. 
        /// It will call also to ListArray.Clear() to clean the list array. 
        /// Here we will not have a length check because FIDMessage does not have any limit. 
        /// The length check will be in FIDElement and SuperFIDElement.
        /// If there are no children the function will throw exception.
        /// </remarks>
        protected byte[] ChildrenToBytes()
        {
            int Count;
            ArrayList Elements = null;
            byte[] Bytes;

            try
            {
                if (m_FIDElements.Count < 1)
                {
                    throw new FIDMessageEmptyException("ChildrenToBytes() failed because FID message \\ super FID does not have childrens");
                }

                Elements = new ArrayList();

                //loop that runs on children and convert them to byte[].
                for (Count = 0; Count < m_FIDElements.Count; Count++)
                {
                    //convert the child to byte[].
                    Bytes = ((IFIDElement)m_FIDElements[Count]).ToBytes();
                    //add the child to Elements.
                    Elements.AddRange(((ICollection)Bytes));
                }

                //convert Elements to array of bytes and return it.
                Bytes = ((byte[])Elements.ToArray(typeof(byte)));
                return (Bytes);
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (Elements != null)
                {
                    Elements.Clear();
                }
            }
        }
        #endregion

        #region Public functions
        /// <summary>
        /// Adds a FID element or Super FID element to m_FIDElements.
        /// </summary>
        /// <param name="Element">A FID element or Super FID element object.</param>
        public void AddChild(object Element)
        {
            try
            {
                if (Element == null)
                {
                    throw new ArgumentNullException("Element", "AddChild() failed because Element parameter is null");
                }

                if (((Element is FIDElement) != true) && ((Element is SuperFIDElement) != true))
                {
                    string LogMessage;
                    LogMessage = string.Format("AddChild() failed because Element parameter is not the right type. Its type is [{0}].", Element.GetType().FullName);
                    throw new ArgumentException(LogMessage, "Element");
                }
                //if object already exists than need to throw exception because if we will have the same object 
                //twice in m_FIDElements we will have problems when we will call to Delete().
                if ((m_FIDElements.Contains(Element)) == true)
                {
                    throw new FIDElementAlreadyExist("AddChild() failed because Element parameter already exists as  child.", (((IFIDElement)Element).FIDID));
                }
                else
                {
                    m_FIDElements.Add(Element);
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// updates a FID element or Super FID element with the value passed.
        /// </summary>
        /// <param name="Element">A FID element or Super FID element object.</param>
        public void UpdateChild(object Element, int value)
        {
            try
            {
                if (Element == null)
                {
                    throw new ArgumentNullException("Element", "UpdateChild() failed because Element parameter is null");
                }
                if (string.IsNullOrEmpty(value.ToString()))
                {
                    throw new ArgumentNullException("Value", "UpdateChild() failed because Element value is null");
                }
                if (((Element is FIDElement) != true) && ((Element is SuperFIDElement) != true))
                {
                    string LogMessage;
                    LogMessage = string.Format("UpdateChild() failed because Element parameter is not the right type. Its type is [{0}].", Element.GetType().FullName);
                    throw new ArgumentException(LogMessage, "Element");
                }
                
                FIDElement element = Element as FIDElement;
                element.IntValue = value;
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// updates a FID element or Super FID element with the value passed.
        /// </summary>
        /// <param name="Element">A FID element or Super FID element object.</param>
        public void UpdateChild(object Element, string value)
        {
            try
            {
                if (Element == null)
                {
                    throw new ArgumentNullException("Element", "UpdateChild() failed because Element parameter is null");
                }
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("Value", "UpdateChild() failed because Element value is null");
                }
                if (((Element is FIDElement) != true) && ((Element is SuperFIDElement) != true))
                {
                    string LogMessage;
                    LogMessage = string.Format("UpdateChild() failed because Element parameter is not the right type. Its type is [{0}].", Element.GetType().FullName);
                    throw new ArgumentException(LogMessage, "Element");
                }

                FIDElement element = Element as FIDElement;
                element.StringValue = value;
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }
        /// <summary>
        /// Delete a child.
        /// </summary>
        /// <remarks>
        /// The function will run in a loop and will call to m_FIDElements.Contains() 
        /// and m_FIDElements.Remove() untill all the needed elements will be deleted from m_FIDElements.
        /// To delete the children of this element (if it is a super fid) 
        /// The function will try to convert Element to IDispose (by using as casting) 
        /// if  the element has an IDispose interface it will call to Dispose();
        /// </remarks>
        /// <param name="Element">element to be delete from m_FIDElements.</param>
        public void DeleteChild(object Element)
        {
            IDisposable Dispose;
            int Index;

            try
            {
                if (Element == null)
                {
                    throw new ArgumentNullException("Element", "DeleteChild() failed because Element parameter is null.");
                }

                //Check if the object has an IDispose interface. If it has than call to Dispose().
                Dispose = ((IDisposable)(Element as IDisposable));
                if (Dispose != null)
                {
                    Dispose.Dispose();
                }

                //delete all the instances of the specific object from m_FIDElements.
                Index = m_FIDElements.IndexOf(Element);
                while (Index > -1)
                {
                    m_FIDElements.RemoveAt(Index);
                    Index = m_FIDElements.IndexOf(Element);
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Dispose function.
        /// </summary>
        public void Dispose()
        {
            try
            {
                //if we did not dispose yet, than dispose.
                if (m_Disposed != true)
                {
                    if (m_FIDElements != null)
                    {
                        //run in a loop and delete the childes.
                        //Need to remember that DeleteChild() deletes the child from m_FIDElements.
                        //becasue of this we can use for(;;).
                        while (m_FIDElements.Count > 0)
                        {
                            //delete and dispose the child.
                            DeleteChild(m_FIDElements[0]);
                        }
                    }
                    //mark the class as already disposed.
                    m_Disposed = true;
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// The function will return the needed FID Elements.
        /// </summary>
        /// <param name="FIDID">The needed FID ID.</param>
        /// <returns>Array of FIDElement that were found.</returns>
        public FIDElement[] GetFIDElements(FIDInfo FIDID)
        {
            ArrayList Elements = null;
            FIDElement[] FIDElements;

            try
            {
                //get needed FID elements.
                Elements = GetElements(false, FIDID);
                //convert the resaults to FIDElement[].
                FIDElements = ((FIDElement[])Elements.ToArray(typeof(FIDElement)));
                
                return (FIDElements);
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (Elements != null)
                {
                    Elements.Clear();
                }
            }
        }

        /// <summary>
        /// The function will return the needed Super FID Elements.
        /// </summary>
        /// <param name="FIDID">The needed FID ID.</param>
        /// <returns>Array of SuperFIDElement that were found.</returns>
        public SuperFIDElement[] GetSuperFIDElements(FIDInfo FIDID)
        {
            ArrayList Elements = null;
            SuperFIDElement[] SuperFIDElements;

            try
            {
                //get needed Super FID elements.
                Elements = GetElements(true, FIDID);
                //convert the resaults to SuperFIDElemet[].
                SuperFIDElements = ((SuperFIDElement[])Elements.ToArray(typeof(SuperFIDElement)));

                return (SuperFIDElements);
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (Elements != null)
                {
                    Elements.Clear();
                }
            }
        }
        
        /// <summary>
        /// The function will return true if needed SuperFIDElement exists in m_FIDElements.
        /// </summary>
        /// <param name="FIDID">The needed FID ID.</param>
        /// <returns>if needed FID ID exists in m_FIDElements than true will be returned, 
        /// else false will be returned.
        /// </returns>
        public bool SuperFIDElementExists(FIDInfo FIDID)
        {
            SuperFIDElement[] SuperFIDElements = null;
            bool Exists;

            try
            {
                //get the needed element if its exists.
                SuperFIDElements = GetSuperFIDElements(FIDID);

                //if the element exists or not, update Exists.
                if (SuperFIDElements.Length > 0)
                {
                    Exists = true;
                }
                else
                {
                    Exists = false;
                }

                return (Exists);
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (SuperFIDElements != null)
                {
                    Array.Clear(SuperFIDElements, 0, SuperFIDElements.Length);
                }
            }
        }

        /// <summary>
        /// The function will return true if needed FIDElement exists in m_FIDElements.
        /// </summary>
        /// <param name="FIDID">The needed FID ID.</param>
        /// <returns>if needed FID ID exists in m_FIDElements than true will be returned, 
        /// else false will be returned.
        /// </returns>
        public bool FIDElementExists(FIDInfo FIDID)
        {
            FIDElement[] FIDElements = null;
            bool Exists;

            try
            {
                //get the needed element if its exists.
                FIDElements = GetFIDElements(FIDID);

                //if the element exists or not, update Exists.
                if (FIDElements.Length > 0)
                {
                    Exists = true;
                }
                else
                {
                    Exists = false;
                }

                return (Exists);
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (FIDElements != null)
                {
                    Array.Clear(FIDElements, 0, FIDElements.Length);
                }
            }
        }
        #endregion
    }
}
