using System;
using System.Collections.Generic;
using System.Text;

namespace RIS.Interop.Messages
{
    #region FIDException
    /// <summary>
    /// Base class to FID exceptions.
    /// </summary>
    public class FIDException : ApplicationException
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="Message">exception message</param>
        public FIDException(string Message) : base(Message)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="InnerException">Inner exception.</param>
        public FIDException(string Message, Exception InnerException) : base(Message, InnerException)
        {
        }

        /// <summary>
        /// Constructor. We do not need it. We use it to prevent the user to code new FIDException().
        /// </summary>
        protected FIDException()
        {
        }
    }
    #endregion

    #region FIDMessageEmptyException
    /// <summary>
    /// Exception class that represents a FIDMessage without FID elements in it.
    /// </summary>
    public class FIDMessageEmptyException : FIDException
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="Message">exception message</param>
        public FIDMessageEmptyException(string Message)
            : base(Message)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="InnerException">Inner exception.</param>
        public FIDMessageEmptyException(string Message, Exception InnerException)
            : base(Message, InnerException)
        {
        }

        /// <summary>
        /// Constructor. We do not need it. We use it to prevent the user to code new FIDMessageEmptyException().
        /// </summary>
        protected FIDMessageEmptyException()
        {
        }
    }
    #endregion

    #region FIDElementNotValidException
    /// <summary>
    /// Exception class that represents not valid FID element (i.e empty element�s value)
    /// </summary>
    public class FIDElementNotValidException : FIDException
    {
        /// <summary>
        /// Problamatic FID ID.
        /// </summary>
        protected FIDInfo m_FIDID;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="FIDID">Problamatic FID ID.</param>
        public FIDElementNotValidException(string Message, FIDInfo FIDID)
            : base(Message)
        {
            m_FIDID = FIDID;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="FIDID">Problamatic FID ID.</param>
        /// <param name="InnerException">InnerException</param>
        public FIDElementNotValidException(string Message, Exception InnerException, FIDInfo FIDID)
            : base(Message, InnerException)
        {
            m_FIDID = FIDID;
        }

        /// <summary>
        /// Constructor. We do not need it. We use it to prevent the user to code new FIDElementNotValidException().
        /// </summary>
        protected FIDElementNotValidException()
        {
        }
        /// <summary>
        /// FID ID of problamatic element.
        /// </summary>
        public FIDInfo FIDID
        {
            get
            {
                return (m_FIDID);
            }
        }
    }
    #endregion

    #region FIDElementCorruptedException
    /// <summary>
    /// Exception class that represents binary FID element that was corrupted 
    /// (i.e. corrupted header or byte[] too short). 
    /// </summary>
    public class FIDElementCorruptedException : FIDException
    {
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="Message">exception message</param>
        public FIDElementCorruptedException(string Message)
            : base(Message)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="InnerException">Inner exception.</param>
        public FIDElementCorruptedException(string Message, Exception InnerException)
            : base(Message, InnerException)
        {
        }

        /// <summary>
        /// Constructor. We do not need it. We use it to prevent the user to code new FIDElementCorruptedException().
        /// </summary>
        protected FIDElementCorruptedException()
        {
        }
    }
    #endregion

    #region FIDElementTooLongException
    /// <summary>
    /// Exception class that represents FID element�s value that is too long.
    /// </summary>
    public class FIDElementTooLongException : FIDException
    {
        /// <summary>
        /// Problamatic FID ID.
        /// </summary>
        protected FIDInfo m_FIDID;
        /// <summary>
        /// Problamatic FID value (string).
        /// </summary>
        protected string m_StringValue = string.Empty;
        /// <summary>
        /// Problamatic FID value (binary).
        /// </summary>
        protected byte[] m_BinaryValue = null;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="FIDID">Problamatic FID ID.</param>
        public FIDElementTooLongException(string Message, FIDInfo FIDID, string StringValue, byte[] BinaryValue)
            : base(Message)
        {
            m_FIDID = FIDID;
            m_StringValue = StringValue;
            m_BinaryValue = BinaryValue;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="FIDID">Problamatic FID ID.</param>
        /// <param name="InnerException">InnerException</param>
        public FIDElementTooLongException(string Message, Exception InnerException, FIDInfo FIDID, string StringValue, byte[] BinaryValue)
            : base(Message, InnerException)
        {
            m_FIDID = FIDID;
            m_StringValue = StringValue;
            m_BinaryValue = BinaryValue;
        }

        /// <summary>
        /// Constructor. We do not need it. We use it to prevent the user to code new FIDElementTooLongException().
        /// </summary>
        protected FIDElementTooLongException()
        {
        }
        /// <summary>
        /// FID ID of problamatic element.
        /// </summary>
        public FIDInfo FIDID
        {
            get
            {
                return (m_FIDID);
            }
        }

        /// <summary>
        /// Problamatic element value (non binary).
        /// </summary>
        public string StringValue
        {
            get
            {
                return (m_StringValue);
            }
        }

        /// <summary>
        /// Problamatic element value (binary).
        /// </summary>
        public byte[] BinaryValue
        {
            get
            {
                return (m_BinaryValue);
            }
        }
    }
    #endregion

    #region FIDElementAlreadyExist
    /// <summary>
    /// Exception class that represents a FID or Super FID element that already exist at the specific parent. 
    /// </summary>
    public class FIDElementAlreadyExist : FIDException
    {
        /// <summary>
        /// Problamatic FID ID.
        /// </summary>
        protected FIDInfo m_FIDID;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="FIDID">Problamatic FID ID.</param>
        public FIDElementAlreadyExist(string Message, FIDInfo FIDID)
            : base(Message)
        {
            m_FIDID = FIDID;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Message">Exception message.</param>
        /// <param name="FIDID">Problamatic FID ID.</param>
        /// <param name="InnerException">InnerException</param>
        public FIDElementAlreadyExist(string Message, Exception InnerException, FIDInfo FIDID)
            : base(Message, InnerException)
        {
            m_FIDID = FIDID;
        }

        /// <summary>
        /// Constructor. We do not need it. We use it to prevent the user to code new FIDElementAlreadyExist().
        /// </summary>
        protected FIDElementAlreadyExist()
        {
        }
        /// <summary>
        /// FID ID of problamatic element.
        /// </summary>
        public FIDInfo FIDID
        {
            get
            {
                return (m_FIDID);
            }
        }
    }
    #endregion

}
