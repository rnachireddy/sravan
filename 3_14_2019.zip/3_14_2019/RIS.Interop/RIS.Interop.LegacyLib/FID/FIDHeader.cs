using System;
using System.Collections.Generic;
using System.Text;

namespace RIS.Interop.Messages
{
    /// <summary>
    /// Contains FID header properties. 
    /// Build itself from byte[] and knows to convert itself to byte[].
    /// </summary>
    /// <remarks>
    /// Byte0:	
    /// 	bits [0-1]	: flags
    /// 	bits [2-7]	: fidid (low 6)
    /// Byte1:
    /// 	bits [0-5] 	: fidid (high 6)
    /// 	bits [6-7]	: len (low 2)
    /// Byte2:
    /// 	bits [0-7]	: len (high 8)
    /// * FIDIDs are represented on 12 bits, which gives us 4096    unique identifiers.
    /// * valid length 1-1024
    /// </remarks>
    internal class FIDHeader
    {
        #region Consts
        /// <summary>
        /// Short header flag.
        /// </summary>
        protected const byte FLG_FIDMSG_SHORTFID = 2;
        /// <summary>
        /// Super FID flag.
        /// </summary>
        protected const byte FLG_FIDMSG_SUPERFID = 1;
        /// <summary>
        /// short header length.
        /// </summary>
        protected const short SHORT_HEADER_LEN = 2;
        /// <summary>
        /// long header length.
        /// </summary>
        protected const short LONG_HEADER_LEN = 3;
        /// <summary>
        /// Max data len in FID or Super FID element.
        /// </summary>
        protected const short MAX_DATA_LEN = 4096;
        #endregion

        #region fields
        /// <summary>
        /// Is it a header of super fid?
        /// </summary>
        protected bool m_IsSuperFID;
        /// <summary>
        /// Data len (bytes).
        /// </summary>
        protected short m_DataLen;
        /// <summary>
        /// header len (bytes).
        /// </summary>
        protected short m_HeaderLen;
        /// <summary>
        /// FID ID.
        /// </summary>
        protected FIDInfo m_FIDID;
        #endregion

        #region Properties
        /// <summary>
        /// Max data len in FID or Super FID element.
        /// </summary>
        /// <value></value>
        public static short MaxDataLen
        {
            get
            {
                return (MAX_DATA_LEN);
            }
        }
        /// <summary>
        /// Is it a super FID element or FID element?
        /// </summary>
        /// <value></value>
        public bool IsSuperFID
        {
            get
            {
                return (m_IsSuperFID);
            }
        }

        /// <summary>
        /// Returns the FID data length.
        /// </summary>
        public short DataLen
        {
            get
            {
                return (m_DataLen);
            }
        }

        /// <summary>
        /// Returns FID ID.
        /// </summary>
        public FIDInfo FIDID
        {
            get
            {
                return (m_FIDID);
            }
        }

        /// <summary>
        /// Returns Header length
        /// </summary>
        public short HeaderLen
        {
            get
            {
                return (m_HeaderLen);
            }
        }

        /// <summary>
        /// Returns HeaderLen + DataLen.
        /// </summary>
        public short ElementLen
        {
            get
            {
                return ((short)(m_HeaderLen + m_DataLen));
            }
        }
        #endregion

        #region constructors
        /// <summary>
        /// Constructor that builds the class from byte[]. 
        /// It will read the first 2 or 3 bytes of the array and take from them the needed data.
        /// </summary>
        /// <param name="Element">Bytes array that contains at its beginning the FID header.</param>
        public FIDHeader(byte[] Element)
        {
            short DataLen;
            byte ByteValue;

            try
            {
                if (Element == null)
                {
                    throw new ArgumentNullException("Element", "constructor of FIDHeader failed because Element parameter is null");
                }

                if (Element.Length == 0)
                {
                    throw new ArgumentException("constructor of FIDHeader failed because Element parameter is empty", "Element");
                }

                //check if this is super FID or FID.
                if ((Element[0] & FLG_FIDMSG_SUPERFID) == FLG_FIDMSG_SUPERFID)
                {
                    m_IsSuperFID = true;
                }
                else
                {
                    m_IsSuperFID = false;
                }

                //Check if it is short FID header or long FID header.
                if ((Element[0] & FLG_FIDMSG_SHORTFID) == FLG_FIDMSG_SHORTFID)
                {
                    m_HeaderLen = SHORT_HEADER_LEN;

                }
                else
                {
                    m_HeaderLen = LONG_HEADER_LEN;
                }

                if (m_HeaderLen > Element.Length)
                {
                    string LogMessage;
                    LogMessage = string.Format("constructor of FIDHeader failed because header actual size is smaller than expected. m_HeaderLen [{0}] Element.Length [{1}]", m_HeaderLen.ToString(), Element.Length.ToString());
                    throw new FIDElementCorruptedException(LogMessage);
                }

                //Get FID ID.
                ByteValue = ((byte)((Element[0] & 0xfc) >> 2));
                m_FIDID = ((FIDInfo)((int)((((short)Element[1] & 0x3f) << 6) | ((short)ByteValue))));

                //Get data len. if it short header than the length will be taken only from Message[1].
                DataLen = ((short)((Element[1] & 0xc0) >> 6));
                if (m_HeaderLen == LONG_HEADER_LEN)
                {
                    DataLen |= ((short)(((short)Element[2]) << 2));
                }

                //restore data len by increasing it by 1
                m_DataLen = ((short)(DataLen + 1));
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Constructor that inits class members with the parameter.
        /// </summary>
        /// <param name="SuperFID">Is it a super FID?</param>
        /// <param name="DataLen">FID element data length</param>
        /// <param name="FIDID">FID ID</param>
        public FIDHeader(bool SuperFID, short DataLen, FIDInfo FIDID)
        {
            try
            {
                if ((DataLen < 1) || (DataLen > MAX_DATA_LEN))
                {
                    string LogMessage;
                    LogMessage = string.Format("Constructor of FIDHeader failed because DataLen is not valid. DataLen [{0}].", DataLen.ToString());
                    throw new ArgumentException(LogMessage, "DataLen");
                }

                m_IsSuperFID = SuperFID;
                m_DataLen = DataLen;
                m_FIDID = FIDID;

                //If data len is less than 5 than the header len will be 2 because we save the last header
                //byte. Need to rememeber that the len that will be kep in the header is DataLen--.
                if (DataLen < 5)
                {
                    m_HeaderLen = SHORT_HEADER_LEN;
                }
                else
                {
                    m_HeaderLen = LONG_HEADER_LEN;
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Empty constructor. By this way no one can code new FIDHeader().
        /// </summary>
        protected FIDHeader()
        {
        }
        #endregion

        #region Functions
        /// <summary>
        /// Convert the the class members to byte[].
        /// </summary>
        /// <returns>Array of bytes that contains the header.</returns>
        public byte[] ToBytes()
        {
            short DataLen;
            byte[] Bytes;
            byte ByteValue;
            int Count;

            try
            {
                //we keep the data len in the header as (m_DataLen - 1) to save a bit.
                DataLen = ((short)(m_DataLen - 1));
                Bytes = new byte[m_HeaderLen];

                //zero the array.
                for (Count = 0; Count < Bytes.Length; Count++)
                {
                    Bytes[Count] = 0;
                }

                ///////////////////////////////////////////////////////////////////////////////////
                //Format byte 0: flags + low ID.                                                  /
                ///////////////////////////////////////////////////////////////////////////////////

                //init super fid flag.
                if (m_IsSuperFID == true)
                {
                    Bytes[0] |= FLG_FIDMSG_SUPERFID;
                }

                //init short header flag if header len is 2
                if (m_HeaderLen == SHORT_HEADER_LEN)
                {
                    Bytes[0] |= FLG_FIDMSG_SHORTFID;
                }

                //add first 6 bites of FIDID to the array.
                ByteValue = ((byte)((((int)m_FIDID) & 0x03f) << 2));
                Bytes[0] |= ByteValue;

                ////////////////////////////////////////////////////////////////////////////////////
                //Format byte 1: high FIDID + low len.                                             /
                ////////////////////////////////////////////////////////////////////////////////////

                //add high 6 bites of FIDID.
                Bytes[1] = ((byte)((((int)m_FIDID) & 0x0fc0) >> 6));
                //add 2 low bites of data len.
                ByteValue = ((byte)((DataLen & 0x03) << 6));
                Bytes[1] |= ByteValue;

                ////////////////////////////////////////////////////////////////////////////////////
                //Format byte 3: high len if it is long header.                                    /
                ////////////////////////////////////////////////////////////////////////////////////
                if (m_HeaderLen == LONG_HEADER_LEN)
                {
                    Bytes[2] = ((byte)((DataLen & 0x3fc) >> 2));
                }

                return (Bytes);
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }
        #endregion
    }
}
