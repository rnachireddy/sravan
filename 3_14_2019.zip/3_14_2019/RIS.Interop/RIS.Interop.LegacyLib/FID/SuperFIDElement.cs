using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Xml;

namespace RIS.Interop.Messages
{
    /// <remarks>Contains in it a Super FID element and its childrens.</remarks>
    public class SuperFIDElement : FIDElementsRepository, IFIDElement
    {
        #region Fields
        /// <summary>
        /// Super Fid ID
        /// </summary>
        protected FIDInfo m_FIDID;
        #endregion

        #region Properties
        /// <summary>
        /// FID idendifier. Will return m_FIDID.
        /// </summary>
        public FIDInfo FIDID
        {
            get
            {
                return (m_FIDID);
            }
        }

        /// <summary>
        /// Is it super FID element? Will return true.
        /// </summary>
        public bool IsSuperFID
        {
            get
            {
                return (true);
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Constructor. The constructor will init m_FIDID.
        /// </summary>
        /// <param name="FIDID">Super FID ID.</param>
        public SuperFIDElement(FIDInfo FIDID): base()
        {
            m_FIDID = FIDID;
        }

        /// <summary>
        /// Constructor � will build the super FID element from the array
        /// </summary>
        /// <param name="Element">Super FID element as bytes array.</param>
        public SuperFIDElement(byte[] Element)
            : base(Element, true)
        {
            FIDHeader Header;

            try
            {
                //at this stage the childrens already built by the base constructor. We need to get the FIDID
                //from the header.
                Header = new FIDHeader(Element);
                m_FIDID = Header.FIDID;
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Constructor � We do not need it, but it is to prohibit the user to code new SuperFIdElement().
        /// </summary>
        protected SuperFIDElement()
        {
        }
        #endregion

        #region Public functions
        /// <summary>
        /// Converts the Super FID element to array of bytes.
        /// </summary>
        /// <returns>Bytes array that contains the FID element.</returns>
        public byte[] ToBytes()
        {
            ArrayList Element = null;
            FIDHeader Header;

            try
            {
                Element = new ArrayList();

                //Convert the childrens to bytes array.
                Element.AddRange(((ICollection)ChildrenToBytes()));

                //elemnt data is over 1024 bytes!!!!
                if (Element.Count > FIDHeader.MaxDataLen)
                {
                    string LogMessage;
                    LogMessage = string.Format("SuperFIDElement.ToBytes() failed because data len is over 1024. Data len is [{0}]. m_FIDID [{1}].", Element.Count.ToString(), m_FIDID.ToString());
                    throw new FIDElementTooLongException(LogMessage, m_FIDID, "", null);
                }
                //create header.
                Header = new FIDHeader(true, (short)Element.Count, m_FIDID);
                //add header to array at the begining of the array.
                Element.InsertRange(0, ((ICollection)Header.ToBytes()));
                return ((byte[])(Element.ToArray(typeof(byte))));
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (Element != null)
                {
                    Element.Clear();
                }
            }
        }

        /// <summary>
        /// Convert the element to XmlNode.
        /// </summary>
        /// <param name="XmlDoc">used to create the new XmlElement.</param>
        /// <returns>represents the elemet as XML.</returns>
        public XmlElement ToXml(XmlDocument XmlDoc)
        {
            XmlElement Element;

            try
            {
                //create XmlElement that represent the FID element. The element name is the FIDID enum.
                //The element will have an attribute that contains the number of childrens.
                Element = XmlDoc.CreateElement(m_FIDID.ToString());
                Element.SetAttribute("NumberOfChildren", m_FIDElements.Count.ToString());
                ChildrenToXml(XmlDoc, Element);
                return (Element);
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }
        #endregion
    }
}
