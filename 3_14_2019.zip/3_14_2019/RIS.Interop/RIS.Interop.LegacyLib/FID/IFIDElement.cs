using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace RIS.Interop.Messages
{
    /// <summary>
    /// Interface to FID elements basic services.
    /// </summary>
    internal interface IFIDElement
    {
        #region Properties
        /// <summary>
        /// FID idendifier
        /// </summary>
        FIDInfo FIDID
        {
            get;
        }

        /// <summary>
        /// Is it a super FID element?
        /// </summary>
        bool IsSuperFID
        {
            get;
        }
        #endregion

        #region Methodes
        /// <summary>
        /// Convert the element to byte[] (Super FID will include also its childrens).
        /// </summary>
        /// <returns>Bytes array that contains the FID element.</returns>
        byte[] ToBytes();

        /// <summary>
        /// Convert the element to XmlNode (Super FID will include also the XmlNodes of its childrens).
        /// </summary>
        /// <param name="XmlDoc">will be used to create the new element.</param>
        /// <returns>represents the elemet as XML.</returns>
        XmlElement ToXml(XmlDocument XmlDoc);
        #endregion
    }
}
