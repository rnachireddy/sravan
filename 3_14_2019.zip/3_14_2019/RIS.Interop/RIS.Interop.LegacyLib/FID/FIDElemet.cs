using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Xml;

namespace RIS.Interop.Messages
{
    /// <summary>
    /// Exposes FID element services.
    /// </summary>
    public class FIDElement : IFIDElement
    {
        #region fields
        /// <summary>
        /// Fid ID
        /// </summary>
        protected FIDInfo m_FIDID;
        /// <summary>
        /// Element string value.
        /// </summary>
        protected string m_StringValue = string.Empty;
        /// <summary>
        /// Element binary value.
        /// </summary>
        protected byte[] m_BinaryValue = null;
        #endregion

        #region properties
        /// <summary>
        /// FID idendifier. Will return m_FIDID.
        /// </summary>
        public FIDInfo FIDID
        {
            get
            {
                return (m_FIDID);
            }
            set
            {
                m_FIDID = value;
            }
        }

        /// <summary>
        /// Is it super FID element?. Will return false.
        /// </summary>
        public bool IsSuperFID
        {
            get
            {
                return (false);
            }
        }

        /// <summary>
        /// Is it binary element or string element?.
        /// </summary>
        public bool IsBinary
        {
            get
            {
                if (m_BinaryValue == null)
                {
                    return (false);
                }
                else
                {
                    return (true);
                }
            }
        }

        /// <summary>
        /// return m_BinaryValue. Use BitConvertor class to convert array of bytes to type. 
        /// </summary>
        public byte[] BinaryValue
        {
            get
            {
                //if this is not an binary element than throw an exception
                if (IsBinary == false)
                {
                    string LogMessage;
                    LogMessage = string.Format("BinaryValue property failed. The value is string. m_FIDID [{0}] m_StringValue [{1}]", m_FIDID.ToString(), m_StringValue);
                    throw new FIDException(LogMessage);
                }
                return (m_BinaryValue);
            }
        }

        /// <summary>
        /// Will return m_StringValue.
        /// </summary>
        public string StringValue
        {
            get
            {
                //if this is binary element than throw an exception
                if (IsBinary == true)
                {
                    string LogMessage;
                    LogMessage = string.Format("StringValue property failed. The value is binary. m_FIDID [{0}]", m_FIDID.ToString());
                    throw new FIDException(LogMessage);
                }
                return (m_StringValue);
            }
            set
            {
                m_StringValue = value;
            }
        }

        /// <summary>
        /// Will return m_Value converted to int.
        /// </summary>
        public int IntValue
        {
            get
            {
                string LogMessage;

                //if this is binary element than throw an exception.
                if (IsBinary == true)
                {
                    LogMessage = string.Format("IntValue property failed. The value is binary. m_FIDID [{0}]", m_FIDID.ToString());
                    throw new FIDException(LogMessage);
                }

                int IntValue = 0;
                //try to parse the value to int from string.
                if ((int.TryParse(m_StringValue, out IntValue)) == false)
                {
                    LogMessage = string.Format("IntValue property failed. can not convert [{0}] to int. m_FIDID [{1}]", m_StringValue, m_FIDID.ToString());
                    throw new FIDException(LogMessage);
                }
                return (IntValue);
            }
            set
            {
                m_StringValue = value.ToString();
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Constructor. We do not need it. It is only to eliminate the client to code new FIDElement().
        /// </summary>
        protected FIDElement()
        {
            
        }

        /// <summary>
        /// Constructor. Will convert Value to string and will call to Init().
        /// </summary>
        /// <param name="FIDID">Elemet's FID ID</param>
        /// <param name="Value">Elemet's int value.</param>
        public FIDElement(FIDInfo FIDID, int Value)
        {
            Init(FIDID, Value.ToString(), null);
        }

        /// <summary>
        /// Constructor. Will convert Value to string and will call to Init().
        /// </summary>
        /// <param name="FIDID">Elemet's FID ID</param>
        /// <param name="Value">Elemet's long value.</param>
        public FIDElement(FIDInfo FIDID, long Value)
        {
            Init(FIDID, Value.ToString(), null);
        }

        /// <summary>
        /// Constructor. Will call to Init().
        /// </summary>
        /// <param name="FIDID">Elemet's FID ID</param>
        /// <param name="Value">Elemet's string value.</param>
        public FIDElement(FIDInfo FIDID, string Value)
        {
            Init(FIDID, Value, null);
        }

        /// <summary>
        /// Constructor. Will call to Init().
        /// </summary>
        /// <param name="FIDID">Elemet's FID ID</param>
        /// <param name="Value">Elemet's binary value. Use BitConvertor class to convert types to array of bytes</param>
        public FIDElement(FIDInfo FIDID, byte[] Value)
        {
            Init(FIDID, null, Value);
        }

        /// <summary>
        /// Constructor that get array of bytes and build from it the FIDElement object.
        /// </summary>
        /// <param name="Element">array of bytes that contains the FID element.</param>
        public FIDElement(byte[] Element)
        {
            FIDHeader Header;
            string LogMessage;
            byte[] Data;

            try
            {
                if (Element == null)
                {
                    throw new ArgumentNullException("Element", "constructor of FIDElement failed because Element parameter is null");
                }

                Header = new FIDHeader(Element);

                if (Header.ElementLen > Element.Length)
                {
                    LogMessage = string.Format("constructor of FIDElement failed because Element length [{0}] is bigger than actual bufferr size [{1}].", Header.ElementLen.ToString(), Element.Length.ToString());
                    throw new FIDElementCorruptedException(LogMessage);
                }

                if (Header.DataLen < 1)
                {
                    LogMessage = string.Format("constructor of FIDElement failed because data length [{0}] is less than 1.", Header.DataLen.ToString());
                    throw new FIDElementCorruptedException(LogMessage);
                }

                //get data from FID element. Data located after the header.
                Data = new byte[Header.DataLen];
                Array.Copy(Element, Header.HeaderLen, Data, 0, Data.Length);
                
                //if it is a binay fid than init m_BinaryValue
                if ((IsFIDIsBinaryFID(Header.FIDID)) == true)
                {
                    Init(Header.FIDID, null, Data);
                }
                //if it is a non binay fid than init m_StringValue
                else
                {
                    //Get element data and convert it from byte[] to string. The code page is the default OS
                    //code - page. Than call to Init() to init class members.
                    Init(Header.FIDID, System.Text.Encoding.Default.GetString(Data), null);
                }
            }
            catch (Exception Error)
            {
                throw Error;
            }
         }
         #endregion
        
        #region non public functions
         /// <summary>
         /// Prints array of bytes to string.
         /// </summary>
         /// <param name="ByteArray">Array of bytes that will be printed to string.</param>
         /// <returns>string that contains the printed array of bytes.</returns>
        protected static string PrintByteArrayToString(Byte[] ByteArray)
        {
            StringBuilder StrBuilder;
            int Count;
            int ItemsCount;
            string FieldStr;
            string FieldValue;

            try
            {
                if (ByteArray == null)
                {
                    return ("ByteArray is Null");
                }

                if (ByteArray.Length < 1)
                {
                    return ("ByteArray is empty");
                }

                ItemsCount = ByteArray.Length;
                //use StringBuilder to improve performance.
                StrBuilder = new StringBuilder(ItemsCount * 10);

                //loop that runs and print the specific byte to string.
                for (Count = 0; Count < ItemsCount; Count++)
                {
                    FieldValue = Convert.ToString(ByteArray[Count]);
                    FieldStr = string.Format("[{0}][{1}]", Count.ToString(), FieldValue);
                    //add ", " if it is not the last byte.
                    if ((Count + 1) != ItemsCount)
                    {
                        FieldStr += ", ";
                    }
                    StrBuilder.Append(FieldStr);
                }

                return (StrBuilder.ToString());
            }
            catch
            {
                return ("Error - Exception");
            }
        }

        /// <summary>
        /// If the specific FIDID is binary FID or not.
        /// </summary>
        /// <returns>
        /// true - binary FID.
        /// false - Non binary FID.
        /// </returns>
        protected bool IsFIDIsBinaryFID(FIDInfo FIDID)
        {
            try
            {
                switch (FIDID)
                {
                    case FIDInfo.FD_COMMKEY:
                    case FIDInfo.FD_PINBLOCK:
                    case FIDInfo.FD_CSHDRAWER:
                    case FIDInfo.FD_AUDIT:
                    case FIDInfo.FD_EVTDATA:
                    case FIDInfo.FD_PUMPPARMS:
                    case FIDInfo.FD_DEVCTRL:
                    case FIDInfo.FD_ICRINFO:
                    case FIDInfo.FD_ICRDISPMSGS:
                    case FIDInfo.FD_ICRRCPTMSGS:
                        {
                            return (true);
                        }
                    default:
                        {
                            return (false);
                        }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Init class fields with parametrs.
        /// </summary>
        /// <remarks>The function will validate the parametrs. 
        /// If it is non binary FID and the string is empty or null than exception will be thrown. 
        /// If it is binary FID and the array of bytes is empty or null than exception will be thrown. 
        /// The reason for this is that in the FID header we decrease the data len with 1 
        /// to save a bite in the header, so if the data length will be 0 than in the header 
        /// it will be -1 and it can not be represented.
        /// </remarks>
        /// <param name="FIDID">Element�s FID ID</param>
        /// <param name="StringValue">Element�s string value.</param>
        ///<param name="BinaryValue">Element�s Binary value.</param>
        protected void Init(FIDInfo FIDID, string StringValue, byte[] BinaryValue)
        {
            string LogMessage;

            try
            {
                //if StringValue and BinaryValue are null or empty than it is not legal. One of them need to contains data. 
                if (((String.IsNullOrEmpty(StringValue)) == true) && ((BinaryValue == null) || (BinaryValue.Length < 1)))
                {
                    LogMessage = string.Format("FIDElement.Init failed because StringValue and BinaryValue parameters are null or empty. FIDID [{0}]", FIDID.ToString());
                    throw new ArgumentNullException("StringValue and BinaryValue", LogMessage);
                }

                //if StringValue and BinaryValue both of them not null or empty than it is not legal. Only one of them need to contains data.
                if (((String.IsNullOrEmpty(StringValue)) == false) && (BinaryValue != null))
                {
                    LogMessage = string.Format("FIDElement.Init failed because StringValue and BinaryValue parameters contains data. FIDID [{0}] StringValue [{1}]", FIDID.ToString(), StringValue);
                    throw new ArgumentException(LogMessage, "StringValue and BinaryValue");
                }

                //init class members.
                m_StringValue = StringValue;
                m_BinaryValue = BinaryValue;
                m_FIDID = FIDID;
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        #endregion

        #region public function
        /// <summary>
        /// Convert the element to XmlNode.
        /// </summary>
        /// <param name="XmlDoc">used to create the new XmlElement.</param>
        /// <returns>represents the elemet as XML.</returns>
        public XmlElement ToXml(XmlDocument XmlDoc)
        {
            XmlElement Element;
            string Value;
            string FidName;

            try
            {
                //create XmlElement that represent the FID element. The element name is the FIDID enum.
                //The value of the element will be an attribute.
                FidName = m_FIDID.ToString();

                // PRC 05052013 - Handle issue with unknown FID name, return UnknownFIDID
                if (char.IsDigit(FidName[0]))
                {
                    Element = XmlDoc.CreateElement("UnknownFIDID_" + FidName);
                }
                else
                {
                    Element = XmlDoc.CreateElement(m_FIDID.ToString());
                }

                //if it is binary FID element than print the array of bytes to string.
                if (IsBinary == true)
                {
                    Value = PrintByteArrayToString(m_BinaryValue);
                }
                else
                {
                    Value = m_StringValue;
                }

                Element.SetAttribute("Value", Value);
                return (Element);
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Convert the element to byte[].
        /// </summary>
        /// <returns>Bytes array that contains the FID element.</returns>
        public byte[] ToBytes()
        {
            ArrayList Element = null;
            byte[] Bytes;
            byte[] Data;
            FIDHeader Header;

            try
            {
                Element = new ArrayList();

                if (IsBinary == true)
                {
                    Data = m_BinaryValue;
                }
                else
                {
                    //Convert the value of the element to byte[]. The code page is the OS default code page.
                    Data = System.Text.Encoding.Default.GetBytes(m_StringValue);
                }

                //FID element's data can not exceed more than 1024 bytes.
                if (Data.Length > FIDHeader.MaxDataLen)
                {
                    string LogMessage;
                    LogMessage = string.Format("FIDElement.ToBytes() failed because data len is over 1024. Data len is [{0}]. m_FIDID [{1}]", Data.Length.ToString(), m_FIDID.ToString());
                    throw new FIDElementTooLongException(LogMessage, m_FIDID, m_StringValue, m_BinaryValue);
                }

                //create FID header.
                Header = new FIDHeader(false, (short)Data.Length, m_FIDID);
                //Add FID header and FID data to Element.
                Element.AddRange((ICollection)Header.ToBytes());
                Element.AddRange((ICollection)Data);

                //Copy Element to byte[] and return it.
                Bytes = ((byte[])Element.ToArray(typeof(byte)));

                return (Bytes);
            }
            catch (Exception Error)
            {
                throw Error;
            }
            finally
            {
                if (Element != null)
                {
                    Element.Clear();
                }
            }
        }
        #endregion
    }
}
