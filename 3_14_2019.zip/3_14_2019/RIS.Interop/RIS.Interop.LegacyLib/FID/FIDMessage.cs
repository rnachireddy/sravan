using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace RIS.Interop.Messages
{
    /// <summary>
    /// Class that holds in it a FID message. It is the higher element. 
    /// It can contains FIDElement and SuperFIDElement.
    /// </summary>
    public class FIDMessage : FIDElementsRepository
    {
        #region Constructors
        /// <summary>
        /// Constructor. Will call to base(Message, false).
        /// </summary>
        /// <param name="Message">FID message.</param>
        public FIDMessage(byte[] Message) : base(Message, false)
        {
        }

        /// <summary>
        /// Empty constructor.
        /// </summary>
        public FIDMessage()
        {
        }
        #endregion

        #region Public functions
        /// <summary>
        /// Return the FID message as bytes array.
        /// </summary>
        public byte[] ToBytes()
        {
            return (ChildrenToBytes());
        }

        /// <summary>
        /// Returns the FID message as XML.
        /// </summary>
        /// <returns>The FID message in XML format.</returns>
        public override string ToString()
        {
            XmlDocument XmlDoc;

            try
            {
                XmlDoc = new XmlDocument();

                //create the root element.
                XmlDoc.LoadXml("<FIDMessage></FIDMessage>");
                ChildrenToXml(XmlDoc, XmlDoc.DocumentElement);

                string[] maskFidTags = new string[] { "FD_MICR", "FD_TRACK1", "FD_TRACK2", "FD_ACCTNUM", "FD_FULLACCTNUM" };

                object[] objchild = Children;
                XmlElement Element;
                string subSuperFid = string.Empty;
                foreach (object obj in objchild)
                {
                    Element = ((IFIDElement)obj).ToXml(XmlDoc);
                    if (Element.Name.Contains("SFD_"))
                    {
                        XmlElement superElement;
                        foreach(object supobj in ((SuperFIDElement)obj).Children)
                        {
                            superElement = ((IFIDElement)supobj).ToXml(XmlDoc);
                            foreach (string maskFidTag in maskFidTags)
                            {
                                XmlNode node = null;
                                //if(Element.Name.Equals("SFD_PLU", StringComparison.OrdinalIgnoreCase))
                                    //node = XmlDoc.SelectSingleNode("FIDMessage/SFD_PLU/SFD_ICARD/" + maskFidTag);
                                if(superElement.Name.Contains("SFD_"))
                                    node = XmlDoc.SelectSingleNode("FIDMessage/" + Element.Name.Trim() + "/" + superElement.Name.Trim() + "/" + maskFidTag);
                                else
                                    node = XmlDoc.SelectSingleNode("FIDMessage/" + Element.Name.Trim() + "/" + maskFidTag);
                                
                                if (node != null)
                                    node.Attributes[0].Value = "***NOT_LOGGED***";
                            }
                        }
                    }
                }
            
                XmlWriterSettings settings = new XmlWriterSettings();
                //settings.NewLineChars = "\n";
                settings.Indent = true;
                StringBuilder strBuild = new StringBuilder();
                using (XmlWriter writer = XmlWriter.Create(strBuild, settings))
                {
                    XmlDoc.WriteTo(writer);
                }
                string xml = strBuild.ToString().Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n", "");
                //return (XmlDoc.OuterXml);
                return xml;
            }
            catch (Exception Error)
            {
                throw Error;
            }
        }
        #endregion
    }
}
