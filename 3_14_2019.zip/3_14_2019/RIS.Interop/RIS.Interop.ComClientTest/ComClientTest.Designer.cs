namespace RIS.Interop.ComClientTest
{
    partial class ComClientTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_tbSend = new System.Windows.Forms.TextBox();
            this.m_tbRecieve = new System.Windows.Forms.TextBox();
            this.m_tbMessages = new System.Windows.Forms.TextBox();
            this.m_lblSend = new System.Windows.Forms.Label();
            this.m_lblRecieve = new System.Windows.Forms.Label();
            this.m_lblMessages = new System.Windows.Forms.Label();
            this.m_lblMyAdn = new System.Windows.Forms.Label();
            this.m_tbMyAdn = new System.Windows.Forms.TextBox();
            this.m_btnInitTerminate = new System.Windows.Forms.Button();
            this.m_btnSend = new System.Windows.Forms.Button();
            this.m_BtnStressTest = new System.Windows.Forms.Button();
            this.m_lblTargerAdn = new System.Windows.Forms.Label();
            this.m_tbTargetAdn = new System.Windows.Forms.TextBox();
            this.m_lblStressTestSleepTime = new System.Windows.Forms.Label();
            this.m_tbStressTestSleepTime = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_tbSend
            // 
            this.m_tbSend.Location = new System.Drawing.Point(12, 61);
            this.m_tbSend.Multiline = true;
            this.m_tbSend.Name = "m_tbSend";
            this.m_tbSend.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_tbSend.Size = new System.Drawing.Size(362, 142);
            this.m_tbSend.TabIndex = 0;
            // 
            // m_tbRecieve
            // 
            this.m_tbRecieve.Location = new System.Drawing.Point(12, 250);
            this.m_tbRecieve.Multiline = true;
            this.m_tbRecieve.Name = "m_tbRecieve";
            this.m_tbRecieve.ReadOnly = true;
            this.m_tbRecieve.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_tbRecieve.Size = new System.Drawing.Size(362, 288);
            this.m_tbRecieve.TabIndex = 1;
            // 
            // m_tbMessages
            // 
            this.m_tbMessages.Location = new System.Drawing.Point(12, 593);
            this.m_tbMessages.Multiline = true;
            this.m_tbMessages.Name = "m_tbMessages";
            this.m_tbMessages.ReadOnly = true;
            this.m_tbMessages.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.m_tbMessages.Size = new System.Drawing.Size(362, 142);
            this.m_tbMessages.TabIndex = 2;
            // 
            // m_lblSend
            // 
            this.m_lblSend.AutoSize = true;
            this.m_lblSend.BackColor = System.Drawing.SystemColors.ControlLight;
            this.m_lblSend.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_lblSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblSend.Location = new System.Drawing.Point(13, 28);
            this.m_lblSend.Name = "m_lblSend";
            this.m_lblSend.Size = new System.Drawing.Size(49, 22);
            this.m_lblSend.TabIndex = 3;
            this.m_lblSend.Text = "Send";
            // 
            // m_lblRecieve
            // 
            this.m_lblRecieve.AutoSize = true;
            this.m_lblRecieve.BackColor = System.Drawing.SystemColors.ControlLight;
            this.m_lblRecieve.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_lblRecieve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblRecieve.Location = new System.Drawing.Point(12, 215);
            this.m_lblRecieve.Name = "m_lblRecieve";
            this.m_lblRecieve.Size = new System.Drawing.Size(68, 22);
            this.m_lblRecieve.TabIndex = 4;
            this.m_lblRecieve.Text = "Recieve";
            // 
            // m_lblMessages
            // 
            this.m_lblMessages.AutoSize = true;
            this.m_lblMessages.BackColor = System.Drawing.SystemColors.ControlLight;
            this.m_lblMessages.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_lblMessages.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblMessages.Location = new System.Drawing.Point(12, 558);
            this.m_lblMessages.Name = "m_lblMessages";
            this.m_lblMessages.Size = new System.Drawing.Size(84, 22);
            this.m_lblMessages.TabIndex = 5;
            this.m_lblMessages.Text = "Messages";
            // 
            // m_lblMyAdn
            // 
            this.m_lblMyAdn.AutoSize = true;
            this.m_lblMyAdn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.m_lblMyAdn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_lblMyAdn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblMyAdn.Location = new System.Drawing.Point(71, 30);
            this.m_lblMyAdn.Name = "m_lblMyAdn";
            this.m_lblMyAdn.Size = new System.Drawing.Size(60, 22);
            this.m_lblMyAdn.TabIndex = 6;
            this.m_lblMyAdn.Text = "MyAdn";
            // 
            // m_tbMyAdn
            // 
            this.m_tbMyAdn.Location = new System.Drawing.Point(163, 30);
            this.m_tbMyAdn.Name = "m_tbMyAdn";
            this.m_tbMyAdn.Size = new System.Drawing.Size(41, 20);
            this.m_tbMyAdn.TabIndex = 7;
            // 
            // m_btnInitTerminate
            // 
            this.m_btnInitTerminate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_btnInitTerminate.Location = new System.Drawing.Point(390, 12);
            this.m_btnInitTerminate.Name = "m_btnInitTerminate";
            this.m_btnInitTerminate.Size = new System.Drawing.Size(81, 38);
            this.m_btnInitTerminate.TabIndex = 8;
            this.m_btnInitTerminate.Text = "Init";
            this.m_btnInitTerminate.UseVisualStyleBackColor = true;
            this.m_btnInitTerminate.Click += new System.EventHandler(this.btnInitTerminate_Click);
            // 
            // m_btnSend
            // 
            this.m_btnSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_btnSend.Location = new System.Drawing.Point(390, 61);
            this.m_btnSend.Name = "m_btnSend";
            this.m_btnSend.Size = new System.Drawing.Size(81, 38);
            this.m_btnSend.TabIndex = 9;
            this.m_btnSend.Text = "Send";
            this.m_btnSend.UseVisualStyleBackColor = true;
            this.m_btnSend.Visible = false;
            this.m_btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // m_BtnStressTest
            // 
            this.m_BtnStressTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_BtnStressTest.Location = new System.Drawing.Point(390, 116);
            this.m_BtnStressTest.Name = "m_BtnStressTest";
            this.m_BtnStressTest.Size = new System.Drawing.Size(81, 62);
            this.m_BtnStressTest.TabIndex = 10;
            this.m_BtnStressTest.Text = "Start Stress Test";
            this.m_BtnStressTest.UseVisualStyleBackColor = true;
            this.m_BtnStressTest.Visible = false;
            this.m_BtnStressTest.Click += new System.EventHandler(this.BtnStressTest_Click);
            // 
            // m_lblTargerAdn
            // 
            this.m_lblTargerAdn.AutoSize = true;
            this.m_lblTargerAdn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.m_lblTargerAdn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_lblTargerAdn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblTargerAdn.Location = new System.Drawing.Point(71, 5);
            this.m_lblTargerAdn.Name = "m_lblTargerAdn";
            this.m_lblTargerAdn.Size = new System.Drawing.Size(86, 22);
            this.m_lblTargerAdn.TabIndex = 11;
            this.m_lblTargerAdn.Text = "TargerAdn";
            // 
            // m_tbTargetAdn
            // 
            this.m_tbTargetAdn.Location = new System.Drawing.Point(163, 5);
            this.m_tbTargetAdn.Name = "m_tbTargetAdn";
            this.m_tbTargetAdn.Size = new System.Drawing.Size(41, 20);
            this.m_tbTargetAdn.TabIndex = 12;
            // 
            // m_lblStressTestSleepTime
            // 
            this.m_lblStressTestSleepTime.AutoSize = true;
            this.m_lblStressTestSleepTime.BackColor = System.Drawing.SystemColors.ControlLight;
            this.m_lblStressTestSleepTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_lblStressTestSleepTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m_lblStressTestSleepTime.Location = new System.Drawing.Point(219, 5);
            this.m_lblStressTestSleepTime.Name = "m_lblStressTestSleepTime";
            this.m_lblStressTestSleepTime.Size = new System.Drawing.Size(89, 45);
            this.m_lblStressTestSleepTime.TabIndex = 13;
            this.m_lblStressTestSleepTime.Text = "ST Sleep \r\n(MS)";
            this.m_lblStressTestSleepTime.UseCompatibleTextRendering = true;
            // 
            // m_tbStressTestSleepTime
            // 
            this.m_tbStressTestSleepTime.Location = new System.Drawing.Point(314, 7);
            this.m_tbStressTestSleepTime.Name = "m_tbStressTestSleepTime";
            this.m_tbStressTestSleepTime.Size = new System.Drawing.Size(48, 20);
            this.m_tbStressTestSleepTime.TabIndex = 14;
            this.m_tbStressTestSleepTime.Text = "1000";
            // 
            // ComClientTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 791);
            this.Controls.Add(this.m_tbStressTestSleepTime);
            this.Controls.Add(this.m_lblStressTestSleepTime);
            this.Controls.Add(this.m_tbTargetAdn);
            this.Controls.Add(this.m_lblTargerAdn);
            this.Controls.Add(this.m_BtnStressTest);
            this.Controls.Add(this.m_btnSend);
            this.Controls.Add(this.m_btnInitTerminate);
            this.Controls.Add(this.m_tbMyAdn);
            this.Controls.Add(this.m_lblMyAdn);
            this.Controls.Add(this.m_lblMessages);
            this.Controls.Add(this.m_lblRecieve);
            this.Controls.Add(this.m_lblSend);
            this.Controls.Add(this.m_tbMessages);
            this.Controls.Add(this.m_tbRecieve);
            this.Controls.Add(this.m_tbSend);
            this.Name = "ComClientTest";
            this.Text = "ComClientTest";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_tbSend;
        private System.Windows.Forms.TextBox m_tbRecieve;
        private System.Windows.Forms.TextBox m_tbMessages;
        private System.Windows.Forms.Label m_lblSend;
        private System.Windows.Forms.Label m_lblRecieve;
        private System.Windows.Forms.Label m_lblMessages;
        private System.Windows.Forms.Label m_lblMyAdn;
        private System.Windows.Forms.TextBox m_tbMyAdn;
        private System.Windows.Forms.Button m_btnInitTerminate;
        private System.Windows.Forms.Button m_btnSend;
        private System.Windows.Forms.Button m_BtnStressTest;
        private System.Windows.Forms.Label m_lblTargerAdn;
        private System.Windows.Forms.TextBox m_tbTargetAdn;
        private System.Windows.Forms.Label m_lblStressTestSleepTime;
        private System.Windows.Forms.TextBox m_tbStressTestSleepTime;
    }
}