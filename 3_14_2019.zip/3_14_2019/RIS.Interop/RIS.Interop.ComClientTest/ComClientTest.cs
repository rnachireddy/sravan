using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using RIS.Interop.Communication;

namespace RIS.Interop.ComClientTest
{
    /// <summary>
    /// Com test statuses.
    /// </summary>
    enum TestState
    {
        BeforeInit,
        InitFailed,
        InitSuceeded,
        TerminateSuceeded,
        TerminateFailed
    };

    public partial class ComClientTest : Form
    {
        #region Fields
        /// <summary>
        /// Test state.
        /// </summary>
        TestState m_State = TestState.BeforeInit;
        /// <summary>
        /// My Adn.
        /// </summary>
        Byte m_MyAdn = 0;
        /// <summary>
        /// Target ADN.
        /// </summary>
        Byte m_TargetAdn = 0;
        /// <summary>
        /// Stress test sleep() time in MS.
        /// </summary>
        int m_StressTestSleepTime = 0;
        /// <summary>
        /// Queue that holds messages for sending.
        /// </summary>
        System.Collections.Queue m_SendQueue;
        /// <summary>
        /// thread object to manage send recieve thread.
        /// </summary>
        System.Threading.Thread m_SendRecieveThread;
        /// <summary>
        /// Flag to signal send recive thread if to continue to run or not.
        /// </summary>
        bool m_StopThreads = false;
        /// <summary>
        /// Flag to signal to send recieve that stress test is running.
        /// </summary>
        bool m_StressTestIsRunning = false;
        /// <summary>
        /// Buffer to recieve messages from Com Mgr.
        /// </summary>
        byte[] m_RecieveBuffer;
        /// <summary>
        /// Recieved Message's header that contains message properties.
        /// </summary>
        COMADDR m_RecieveHeader;
        /// <summary>
        /// Path of log file.
        /// </summary>
        const string m_LogFilePath = ".\\ComClientTest.Log";
        #endregion

        #region Constructor and destructor
        /// <summary>
        /// Constructor.
        /// </summary>
        public ComClientTest()
        {
            try
            {
                File.Delete(m_LogFilePath);
                InitializeComponent();
                //when we write to messages text box we write it from send recieve thread that is not the thread of 
                //the control. We get exceptions (Cross-thread operation not valid: Control '' accessed from a thread other than the thread it was created on ). 
                //This is quick and dirty solution.
                //see http://www.thescripts.com/forum/thread611080.html
                Control.CheckForIllegalCrossThreadCalls = false;
                //create thread safe queue.
                m_SendQueue = System.Collections.Queue.Synchronized(new System.Collections.Queue());
                m_RecieveBuffer = new Byte[ComMgrClientProxy.COM_MAX_DATA_SZ];
                m_RecieveHeader = new COMADDR();
            }
            catch (Exception Error)
            {
                TreatException(Error, "Constructor", "", true);
            }
        }

        /// <summary>
        /// Destructor.
        /// </summary>
        ~ComClientTest()
        {
            try
            {
                //clean all not managed resources. We do not need to use IDispose because the user has to press on button 
                //terminate before he close the app. If he did not push the terminate button than we will call to this func.
                if ((m_State != TestState.BeforeInit) && (m_State != TestState.InitFailed) && (m_State != TestState.TerminateSuceeded))
                {
                    Terminate();
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "destructor", "", true);
            }
        }
        #endregion

        #region functions
        /// <summary>
        /// run on exception and its internal exception and get from it errors descriptions.
        /// </summary>
        /// <param name="FailedError">exception that contains description of the file processing failure.</param>
        private string GetErrorDescription(Exception FailedError)
        {
            StringBuilder Builder;
            Exception TempException = null;
            int ExceptionsNumber = 0;

            try
            {
                if (FailedError == null)
                {
                    return ("No Error description, Exception is null");
                }

                Builder = new StringBuilder(500);
                Builder.AppendLine("Errors :");

                //run on exception and get error description from internal exceptions.
                TempException = FailedError;
                while (TempException != null)
                {
                    ExceptionsNumber++;
                    Builder.AppendLine(TempException.Message);
                    Builder.AppendLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                    TempException = TempException.InnerException;
                }

                return (Builder.ToString());
            }
            catch (Exception ex)
            {
                return ("Could not get error message. " + ex.Message);
            }
        }

        /// <summary>
        /// Process exception.
        /// </summary>
        void TreatException(Exception Error, string FuncName, string Message, bool Rethrow)
        {
            try
            {
                string NoteMessage;

                NoteMessage = string.Format("Exception on func [{0}] Error Message [{1}] Message [{2}]", FuncName, GetErrorDescription(Error), Message);
                AddNote(NoteMessage);
            }
            catch (Exception ex)
            {
                AddNote("TreatException() got exception. " + ex.Message);
            }

            //Its out of the try catch to not get caught in the catch.
            if (Rethrow == true)
            {
                throw Error;
            }
        }

        /// <summary>
        /// Terminate the connection to MGR.
        /// </summary>
        private bool Terminate()
        {
            try
            {
                //close communication channel.
                ComTerminate();
                //close send - recieve threads.
                EndThreads();
                return (true);
            }
            catch (Exception Error)
            {
                TreatException(Error, "Terminate", "", true);
                return (false);
            }
        }

        /// <summary>
        /// Init the app and open a connection to communication manager.
        /// </summary>
        private bool Init()
        {
            int Rtc;
            int ErrorCode;

            try
            {
                //open communication channel.
                Rtc = ComInit(m_MyAdn);
                //error, write it to screen.
                if (Rtc != 0)
                {
                    ErrorCode = GetError();
                    AddNote("Init() Failed Rtc [{0}] ErrorCode [{1}]", Convert.ToString(Rtc), Convert.ToString(ErrorCode));
                    return (false);
                }
                //start send recieve thread.
                StartThreads();
                return (true);
            }
            catch (Exception Error)
            {
                TreatException(Error, "Init", "", true);
                return (false);
            }
        }

        /// <summary>
        /// Thread function that send and recieve messages from Com MGR.
        /// </summary>
        private void SendRecieveMessages()
        {
            int StressTestMessagesCounter = 0;
            string Message;

            try
            {
                AddNote("Start SendRecieveMessages thread");

                while (m_StopThreads == false)
                {
                    //if we are in stress test and the queue is empty than add a message to queue.
                    if (m_StressTestIsRunning == true)
                    {
                        if (m_SendQueue.Count < 1)
                        {
                            Message = "Send message # " + Convert.ToString(++StressTestMessagesCounter);
                            m_SendQueue.Enqueue(Message);
                        }
                    }

                    //if the queue has messages, send them.
                    if (m_SendQueue.Count > 0)
                    {
                        SendMessage((string)m_SendQueue.Dequeue());
                    }

                    //see if there are new message and read them.
                    RecieveMessage();

                    //if there are no messages to send than sleep.
                    if (m_SendQueue.Count < 1)
                    {
                        System.Threading.Thread.Sleep(m_StressTestSleepTime);
                    }
                }

                //clear queue so we will not have messages to the next time that the thread will start.
                m_SendQueue.Clear();
                AddNote("Stop SendRecieveMessages thread");
            }
            catch (Exception Error)
            {
                TreatException(Error, "SendRecieveMessages", "", true);
            }
        }

        /// <summary>
        /// Start send recieve messages thread.
        /// </summary>
        private void StartThreads()
        {
            try
            {
                m_StopThreads = false;
                m_SendRecieveThread = new System.Threading.Thread(new System.Threading.ThreadStart(SendRecieveMessages));
                m_SendRecieveThread.IsBackground = true;
                m_SendRecieveThread.Start(); //start send - recieve thread.
                System.Threading.Thread.Sleep(1000);
            }
            catch (Exception Error)
            {
                TreatException(Error, "StartThreads", "", true);
            }
        }

        /// <summary>
        /// Stop send recieve thread.
        /// </summary>
        private void EndThreads()
        {
            try
            {
                m_StopThreads = true; // init flag with true, so send - recive thread will terminate.

                if (m_SendRecieveThread.IsAlive == true)
                {
                    AddNote("Start waiting send recive thread to terminate");
                    m_SendRecieveThread.Join();//wait untill thread terminates.
                    AddNote("Send recive thread terminated");
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "EndThreads", "", true);
            }
        }

        private int ValidateSleepTime(string SleepTime)
        {
            int Resault;

            try
            {
                //Check if ADN is valid byte.
                if ((int.TryParse(SleepTime, out Resault)) != true)
                {
                    return (0);
                }

                //Check if ADN has valid value.
                if ((Resault > 0) || (Resault <= 100000))
                {
                    return (Resault);
                }

                return (0);
            }
            catch (Exception Error)
            {
                TreatException(Error, "ValidateSleepTime", "", true);
                return (0);
            }
        }

        private byte ValidateAdn(string Adn)
        {
            byte Resault;

            try
            {
                //Check if ADN is valid byte.
                if ((byte.TryParse(Adn, out Resault)) != true)
                {
                    return (0);
                }

                //Check if ADN has valid value.
                if ((Resault > 0) || (Resault <= 255))
                {
                    return (Resault);
                }

                return (0);
            }
            catch (Exception Error)
            {
                TreatException(Error, "ValidateAdn", "", true);
                return (0);
            }
        }

        /// <summary>
        /// Add notes to messages text box and log file.
        /// </summary>
        /// <param name="Format">message String format</param>
        /// <param name="Parms">format parametrs</param>
        private void AddNote(string Format, params object[] Parms)
        {
            string Message;

            try
            {
                //If there are parames to string than parse them.
                Message = (Parms != null && Parms.Length > 0) ? String.Format(Format, Parms) : Format;

                //add text to log file.
                File.AppendAllText(m_LogFilePath, Message + Environment.NewLine);

                //send - recieve threads can also write notes, so need to lock it.
                lock (m_tbMessages)
                {
                    m_tbMessages.AppendText(Message + Environment.NewLine);
                    m_tbMessages.ScrollToCaret();
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "AddNote", "", true);
            }
        }

        /// <summary>
        /// Send a message to Com MGR
        /// </summary>
        private void SendMessage(string Message)
        {
            byte[] Bytes;
            int Rtc;
            int ErrorCode;

            try
            {
                //format the message to byte[].
                Bytes = System.Text.Encoding.UTF8.GetBytes(Message);
                //send the message.
                Rtc = Send(Bytes);

                //Clear the array so GC will save memory.
                Array.Clear(Bytes, 0, Bytes.Length);

                //failed to send the message.
                if (Rtc != 0)
                {
                    ErrorCode = GetError();
                    AddNote("Failed to send message. Rtc [{0}] ErrorCode [{1}]", Convert.ToString(Rtc), Convert.ToString(ErrorCode));
                }
                //suceeded to send the message, add it to send message box.
                else
                {
                    m_tbSend.AppendText(Message + Environment.NewLine);
                    m_tbSend.ScrollToCaret();
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "SendMessage", "", true);
            }
        }

        /// <summary>
        /// Recive a message from com client and treat it.
        /// </summary>
        private void RecieveMessage()
        {
            int Rtc;
            Byte[] Bytes;
            string Message;
            int ErrorCode;

            try
            {
                //try to read message from MGR.
                Rtc = Recieve(m_RecieveHeader, m_RecieveBuffer);

                //error or there is no new message.
                if (Rtc < 1)
                {
                    ErrorCode = GetError();
                    //if there is an error than print it.
                    if (ErrorCode != ComMgrClientProxy.E_COM_NOMSG)
                    {
                        AddNote("Failed to Recieve message. Rtc [{0}] ErrorCode [{1}]", Convert.ToString(Rtc), Convert.ToString(ErrorCode));
                    }
                }
                //there is a new message.
                else
                {
                    Bytes = new byte[Rtc];

                    Array.Copy(m_RecieveBuffer, Bytes, Rtc);
                    //convert the message to string.
                    Message = System.Text.Encoding.UTF8.GetString(Bytes);
                    Message = "Adn [" + Convert.ToString(m_RecieveHeader.mSrcAdn) + "] Message: [" + Message + "]";
                    //print message.
                    m_tbRecieve.AppendText(Message + Environment.NewLine);
                    m_tbRecieve.ScrollToCaret();
                    //Clear array so GC will delete the objects and we will not have a memory leak.
                    Array.Clear(m_RecieveBuffer, 0, m_RecieveBuffer.Length);
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "RecieveMessage", "", true);
            }
        }

        /// <summary>
        /// Send a stream of bytes to com MGR.
        /// </summary>
        private int Send(byte[] Bytes)
        {
            try
            {
                return (ComMgrClientProxy.ComReqSend(0, 0, m_TargetAdn, 0, Bytes, Bytes.Length));
            }
            catch (Exception Error)
            {
                TreatException(Error, "Send", "", true);
                return (ComMgrClientProxy.E_COM_FAIL);
            }
        }

        /// <summary>
        /// Recieve array of bytes from com client.
        /// </summary>
        private int Recieve(COMADDR MessageHeader, byte[] Bytes)
        {
            try
            {
                return (ComMgrClientProxy.ComReceive(MessageHeader, Bytes, Bytes.Length, 0));
            }
            catch (Exception Error)
            {
                TreatException(Error, "Recieve", "", true);
                return (ComMgrClientProxy.E_COM_FAIL);
            }
        }

        /// <summary>
        /// Get last com client error.
        /// </summary>
        private int GetError()
        {
            try
            {
                return (ComMgrClientProxy.ComGetError());
            }
            catch (Exception Error)
            {
                TreatException(Error, "GetError", "", true);
                return (ComMgrClientProxy.E_COM_FAIL);
            }
        }

        /// <summary>
        /// Init com client.
        /// </summary>
        /// <param name="MyAdn">My Adn.</param>
        private int ComInit(byte MyAdn)
        {
            try
            {
                return (ComMgrClientProxy.ComInit(0, MyAdn, 1));
            }
            catch (Exception Error)
            {
                TreatException(Error, "ComInit", "", true);
                return (ComMgrClientProxy.E_COM_FAIL);
            }
        }

        /// <summary>
        /// Terminate com client.
        /// </summary>
        private void ComTerminate()
        {
            try
            {
                ComMgrClientProxy.ComExit();
            }
            catch (Exception Error)
            {
                TreatException(Error, "ComTerminate", "", true);
            }
        }
        #endregion

        #region delegates
        /// <summary>
        /// Delegate function that called when init - terminate button is called.
        /// </summary>
        private void btnInitTerminate_Click(object sender, EventArgs e)
        {
            try
            {
                //if we we are before init or init failed or after termination than we can init the connection to MGR.
                if ((m_State == TestState.BeforeInit) || (m_State == TestState.InitFailed) || (m_State == TestState.TerminateSuceeded))
                {
                    //validates my ADN.
                    m_MyAdn = ValidateAdn(m_tbMyAdn.Text);
                    if (m_MyAdn == 0)
                    {
                        AddNote("My Adn is not valid. Legal values are 1 - 255");
                        return;
                    }

                    //validates target ADN.
                    m_TargetAdn = ValidateAdn(m_tbTargetAdn.Text);
                    if (m_TargetAdn == 0)
                    {
                        AddNote("Target Adn is not valid. Legal values are 1 - 255");
                        return;
                    }

                    //validates stress test sleep time.
                    m_StressTestSleepTime = ValidateSleepTime(m_tbStressTestSleepTime.Text);
                    if (m_StressTestSleepTime == 0)
                    {
                        AddNote("Stress test sleep time is not valid. Legal values are 1 - 100000");
                        return;
                    }

                    //clean messages text box if everything is OK.
                    m_tbMessages.Clear();
                    m_tbRecieve.Clear();
                    m_tbSend.Clear();
                    AddNote("Start Init");

                    //init connection with MGR.
                    if (Init() == true)
                    {
                        AddNote("Init Suceeded");
                        m_State = TestState.InitSuceeded; //state is now init suceeded.
                        m_btnInitTerminate.Text = "Terminate";//change init terminate push button text to Terminate.
                        m_btnSend.Visible = true; //send button is now visible.
                        m_BtnStressTest.Visible = true;//stress test button is now visible.
                        m_tbMyAdn.ReadOnly = true;//can not change My Adn.
                        m_tbTargetAdn.ReadOnly = true; //can not change Target Adn.
                        m_tbSend.ReadOnly = false;//can add messages untill stress test starts or termination.
                    }
                    else
                    {
                        AddNote("Init Failed");
                        m_State = TestState.InitFailed; //State is now init failed.
                        m_btnInitTerminate.Text = "Init";//change push button text to Init.
                        m_btnSend.Visible = false;//send button is now not visible. 
                        m_BtnStressTest.Visible = false;//stress test button is now not visible.
                        m_tbMyAdn.ReadOnly = false;//can change My Adn.
                        m_tbTargetAdn.ReadOnly = false;//can change Target Adn. 
                        m_tbSend.ReadOnly = true;//can not add messages untill init suceeded.
                    }
                }
                //if we are in init suceeded or termination failed state than we can terminate the connection to MGR.
                else if ((m_State == TestState.InitSuceeded) || (m_State == TestState.TerminateFailed))
                {
                    if (m_StressTestIsRunning == true)
                    {
                        AddNote("Stress test is running. Can not terminate. Please stop stress test and try again.");
                        return;
                    }

                    //clean messages text box if everything is OK.
                    m_tbMessages.Clear();
                    m_tbRecieve.Clear();
                    m_tbSend.Clear();
                    AddNote("Start Terminate");

                    //terminate connection to MGR.
                    if (Terminate() == true) //terminate suceeded 
                    {
                        AddNote("Terminate Suceeded");
                        m_State = TestState.TerminateSuceeded;//state is now terminate suceeded.
                        m_btnInitTerminate.Text = "Init";//change init terminate push button text to Init.
                        m_btnSend.Visible = false;//send button is now not visible.
                        m_BtnStressTest.Visible = false;//stress test button is now not visible.
                        m_tbMyAdn.ReadOnly = false;//can change Target Adn.
                        m_tbTargetAdn.ReadOnly = false;//can change Target Adn. 
                        m_tbSend.ReadOnly = true;//can not add messages untill init suceeded.
                    }
                    else
                    {
                        AddNote("Terminate Failed");
                        m_State = TestState.TerminateFailed;//state is now terminate failed.
                        m_btnInitTerminate.Text = "Terminate";//change init terminate push button text to Terminate.
                        m_btnSend.Visible = true;//send button is now visible.
                        m_BtnStressTest.Visible = true;//stress test button is now visible.
                        m_tbMyAdn.ReadOnly = true;//can not change My Adn.
                        m_tbTargetAdn.ReadOnly = true; //can not change Target Adn.
                        m_tbSend.ReadOnly = false;//can add messages untill stress test starts or termination.
                    }
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "btnInitTerminate_Click", "", true);
            }
        }

        /// <summary>
        /// Delegate function that called when stress test button is called.
        /// </summary>
        private void BtnStressTest_Click(object sender, EventArgs e)
        {
            try
            {
                //stress test is not running than start it.
                if (m_StressTestIsRunning == false)
                {
                    AddNote("Start stress test");
                    m_StressTestIsRunning = true;//signal thread to start add messages to the queue.
                    m_BtnStressTest.Text = "Stop Stress Test";//change button text.
                    m_btnSend.Visible = false;//can not use send button to send messages.
                    m_tbSend.ReadOnly = true;//can not add messages untill stress test finish.
                }
                else
                {
                    AddNote("Stop stress test");
                    m_StressTestIsRunning = false;//signal thread to stop add messages to the queue.
                    m_BtnStressTest.Text = "Start Stress Test";//change button text.
                    m_btnSend.Visible = true;//can use send button to send messages.
                    m_tbSend.Clear();//clean send text box.
                    m_tbSend.ReadOnly = false;//can add messages untill stress test starts.
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "BtnStressTest_Click", "", true);
            }
        }

        /// <summary>
        /// Delegate function that called when send button is pressed.
        /// </summary>
        private void btnSend_Click(object sender, EventArgs e)
        {
            string Message;

            try
            {
                Message = m_tbSend.Text;//get text to send.
                m_tbSend.Clear();//clean send text box.

                //message is empty
                if (Message.Length < 1)
                {
                    AddNote("Can not send message because it is empty");
                }
                else
                {
                    //add message to queue for sending.
                    m_SendQueue.Enqueue(Message);
                }
            }
            catch (Exception Error)
            {
                TreatException(Error, "btnSend_Click", "", true);
            }
        }
        #endregion
    }
}